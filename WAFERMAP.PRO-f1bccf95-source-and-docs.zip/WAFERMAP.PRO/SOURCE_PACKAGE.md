# WAFERMAP.PRO Source Package

**WAFERMAP.PRO** is a React and Vite wafer-map control room with a Python Flask and Waitress API. It supports a 300 mm wafer, reticle, die, shot, CP, WAT, and KLA workflows. This package contains the complete editable application source, migrations, tests, operational guides, Dockerfile, and lockfile required to reproduce the validated build. It intentionally excludes environment credentials, database URLs, managed-storage credentials, build outputs, dependency folders, browser logs, and Python cache files.

## Included implementation

The `client/` directory contains the React 19 and TypeScript user interface. Its Canvas wafer renderer supports pan, zoom, reticle and die visualization, and high-density CP overlay rendering. The control-room UI also includes Data Criteria, a retained-source library, the CP and YMS analysis studio, CP/WAT/KLA ingestion, reticle design, optimizer, spatial analytics, SEMI export, and inspection workflows.

The `flask_backend/` directory contains the production Flask API, Waitress entrypoint, CSV/XLSX parsers, managed object-storage adapter, and MySQL repository. The API validates upload size, coordinates, source schema, and invalid-row rates before it writes normalized CP die measurements, WAT measurements, KLA defects, import-run audit events, and source lineage to MySQL.

The CP and YMS studio deliberately reports only information available from retained source data. Its Pareto, radial-zone screening, connected failure components, kill-ratio coordinate overlap, WAT process capability, imported CP frequency or leakage summaries, OCAP review evidence, and edge-exclusion sensitivity records are calculated from the selected datasets. Synthetic lot records, invented hardware telemetry, causal root-cause claims, and simulated yield-recovery forecasts are not included.

## Real-data-only package

This source package intentionally contains **no bundled wafer records, samples, mock files, VEDA reference data, or generated manufacturing results**. Use the **Real Data Package Studio** to download empty role-specific CSV templates, populate them with approved CP, WAT, or KLA source extracts, validate every source role, explicitly select one `LOT_ID` + `WAFER_ID` partition, and persist that selected wafer.

The application never adopts a filename, UI preset, or prior reference record as manufacturing truth. `LOT_ID`, `WAFER_ID`, and source `PRODUCT_ID` remain source provenance. Display-geometry templates affect Canvas drawing only and are explicitly non-authoritative.

## Requirements

The validated development environment uses **Node.js 22**, **pnpm**, **Python 3.11**, and a MySQL-compatible database. A `DATABASE_URL` environment variable is required for persistent source storage and ingestion analysis. The application can still present its geometry workspace without persisted records, but CP/WAT/KLA data retention and the analysis library require the database.

| Component | Required version or purpose |
| --- | --- |
| Node.js | 22 or newer for Vite and the development shell |
| pnpm | Uses the included `pnpm-lock.yaml` for deterministic frontend dependencies |
| Python | 3.11 or newer for Flask, Waitress, PyMySQL, and openpyxl |
| MySQL-compatible database | Stores wafer configurations, imports, normalized measurements, and audit records |
| Docker | Optional; uses the supplied multi-runtime `Dockerfile` for production |

## Local development

Install the JavaScript dependencies and Flask requirements from the project root. Set `DATABASE_URL` before starting either service. Never add a real database URL or API key to source control.

```bash
pnpm install --frozen-lockfile
python3 -m pip install -r flask_backend/requirements.txt
export DATABASE_URL='mysql://USER:PASSWORD@HOST:3306/wafermap'
```

Start the Flask API on the port used by the development proxy, then start the Vite/Express development shell in a second terminal.

```bash
waitress-serve --host=127.0.0.1 --port=5501 --call flask_backend.app:create_app
pnpm dev
```

Open the local address printed by `pnpm dev`. Use **Real Data** to upload role-keyed CP, WAT, or KLA **CSV** packages. Then use **Data Library** to reopen an owner-scoped retained dataset or **CP Analysis** to open the CP and YMS studio. WAT and KLA datasets must share the selected CP lot and wafer identity before a combined aggregate is permitted; identity equality alone never proves coordinate alignment, product provenance, or causality.

## Validation

Run the following commands after installing dependencies and configuring the database environment. The browser regression requires Chromium, which is available in the validated Linux environment.

```bash
pnpm check
pnpm test
python3 -m unittest flask_backend.test_app
pnpm run build
node scripts/canvas-e2e.mjs
node scripts/ingestion-e2e.mjs
```

The browser ingestion regression uses empty role templates and validates the no-source-data states, explicit persistence gate, owner-safe history state, Canvas stability, and source-contract UI without injecting any manufactured observations.

## Production container

The included `Dockerfile` builds the Vite application and starts Flask through Waitress. Provide runtime secrets through the deployment platform rather than a Dockerfile, source file, or archive. At a minimum, production needs `DATABASE_URL`. The existing managed deployment also provides storage and platform environment variables.

```bash
docker build -t wafermap-pro .
docker run --rm -p 5050:5050 \
  -e PORT=5050 \
  -e DATABASE_URL='mysql://USER:PASSWORD@HOST:3306/wafermap' \
  wafermap-pro
```

## Package boundaries

This archive is intentionally source-only. It excludes `node_modules/`, `dist/`, `.git/`, `.manus-logs/`, `__pycache__/`, project configuration containing managed credentials, downloaded source archives, sample/mock data, test-result output, and all environment files. Install dependencies from the lockfile and requirements file after extraction.

## Operational documents

Read `OPERATIONS.md` for deployment and service operation, `INGESTION_OPERATIONS.md` for supported schemas and limits, `flask_backend/ANALYSIS_QUEUE_OPERATIONS.md` for job/report execution semantics, and `VALIDATION_REPORT.md` for historical validation evidence. The Drizzle SQL migrations in `drizzle/` must be applied to the target MySQL-compatible database before persistent operation.

## References

[1]: https://vite.dev/guide/ "Vite Guide"
[2]: https://flask.palletsprojects.com/ "Flask Documentation"
[3]: https://docs.docker.com/build/ "Docker Build Documentation"
