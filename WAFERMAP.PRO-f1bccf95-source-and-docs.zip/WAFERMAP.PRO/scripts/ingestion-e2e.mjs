import assert from "node:assert/strict";
import { chromium } from "@playwright/test";

const baseUrl = process.env.WAFERMAP_E2E_URL || "http://127.0.0.1:3000";
const browser = await chromium.launch({ executablePath: "/usr/bin/chromium", headless: true });

try {
  const page = await browser.newPage({ viewport: { width: 1600, height: 980 } });
  await page.goto(baseUrl, { waitUntil: "networkidle" });

  assert.equal(await page.getByRole("button", { name: "Sign in" }).count(), 1, "the owner-scoped data workflow must expose its production sign-in entrypoint");
  await page.locator("#btn-open-ingestion").click();
  await page.getByRole("dialog", { name: "Fab metrology and defect ingestion studio" }).waitFor({ state: "visible" });
  assert.equal(await page.getByText("REAL DATA PACKAGE STUDIO").count(), 1, "ingestion studio must open");
  assert.equal(await page.getByRole("button", { name: /mock/i }).count(), 0, "the package studio must not expose a mocked ingestion control");
  assert.ok(await page.getByText("Die-level primary").count(), "CP package roles must be shown");
  assert.equal(await page.getByRole("button", { name: "Template CSV" }).count(), 4, "each CP role must offer its CSV template");
  assert.ok(await page.getByRole("button", { name: "Validate package schema" }).count(), "package schema validation action must be available");
  assert.equal(await page.getByRole("button", { name: "Persist selected wafer" }).isDisabled(), true, "persistence must remain disabled before a valid package and explicit partition selection");
  await page.getByRole("button", { name: "Validate package schema" }).click();
  await page.getByText("Package incomplete: attach Die-level primary.").waitFor({ state: "visible" });

  await page.getByRole("button", { name: "WAT Metrology" }).first().click();
  assert.ok(await page.getByText("Site-level long primary").count(), "WAT long primary role must be shown");
  assert.ok(await page.getByText("Site-level wide primary").count(), "WAT wide primary role must be shown");
  assert.equal(await page.getByRole("button", { name: "Template CSV" }).count(), 4, "each WAT role must offer its CSV template");
  await page.getByRole("button", { name: "Validate package schema" }).click();
  await page.getByText("Package incomplete: attach one WAT site-level primary (long or wide).").waitFor({ state: "visible" });

  await page.getByRole("button", { name: "KLA Defect Inspection" }).first().click();
  assert.ok(await page.getByText("Defect-detail primary").count(), "KLA package roles must be shown");
  assert.equal(await page.getByRole("button", { name: "Template CSV" }).count(), 3, "each KLA role must offer its CSV template");
  await page.getByRole("button", { name: "Validate package schema" }).click();
  await page.getByText("Package incomplete: attach Defect-detail primary.").waitFor({ state: "visible" });
  await page.getByRole("button", { name: "Close data ingestion studio" }).click();
  await page.route("**/api/analysis/jobs", route => route.fulfill({ status: 404, contentType: "application/json", body: JSON.stringify({ message: "Not available" }) }));
  await page.route("**/api/analysis/reports", route => route.fulfill({ status: 404, contentType: "application/json", body: JSON.stringify({ message: "Not available" }) }));
  await page.getByRole("button", { name: "Open analysis job and report history" }).click();
  await page.getByRole("dialog", { name: "Analysis job and report history" }).waitFor({ state: "visible" });
  await page.getByText("Analysis history service unavailable").waitFor({ state: "visible" });
  assert.ok(await page.getByRole("button", { name: "Refresh" }).count(), "history refresh must be manual");
  await page.getByRole("button", { name: "Close analysis history" }).click();
  await page.route("**/api/ingestion/import-runs**", route => route.fulfill({
    status: 200,
    contentType: "application/json",
    body: JSON.stringify({
      persistence_available: true,
      import_runs: [{
        id: 701,
        source_type: "CP",
        status: "COMPLETED",
        original_filename: "cp_wafer.csv",
        source_hash: "a".repeat(64),
        started_at: "2026-09-29T00:00:00Z",
        completed_at: "2026-09-29T00:01:00Z",
        operation: "PACKAGE_PARTITION_PERSIST",
        selected_partition: { lot_id: "LOT-701", wafer_id: "WAFER-701" },
        source_roles: ["cp_die"],
        counts: { valid_rows: 10, error_rows: 0 },
        diagnostic_codes: [],
        error_type: null,
        has_error: false,
        dataset: { id: 701, lot_id: "LOT-701", wafer_id: "WAFER-701", product_id: "SOURCE-PRODUCT", total_rows: 10, valid_rows: 10, error_rows: 0, byte_size: 1024 },
      }],
    }),
  }));
  await page.getByRole("button", { name: "Open authenticated import-run history" }).click();
  await page.getByRole("dialog", { name: "Authenticated import history" }).waitFor({ state: "visible" });
  await page.getByText("OWNER-SCOPED IMPORT HISTORY").waitFor({ state: "visible" });
  assert.ok(await page.getByText("cp_wafer.csv").count(), "safe import metadata must be visible");
  assert.ok(await page.getByRole("button", { name: "Reopen dataset" }).count(), "only successful retained runs may offer reopen");
  assert.equal(await page.getByText(/No source rows, object locations, or other-user records are displayed/).count(), 1, "history must describe its safe field boundary");
  await page.route("**/api/ingestion/datasets/701/overlay", route => route.fulfill({
    status: 200,
    contentType: "application/json",
    body: JSON.stringify({
      dataset: {
        id: 701,
        source_type: "CP",
        wafer_id: "WAFER-701",
        lot_id: "LOT-701",
        product_id: "SOURCE-PRODUCT",
        summary: {
          source_filename: "cp_wafer.csv",
          lot_id: "LOT-701",
          wafer_id: "WAFER-701",
          product_name: "SOURCE-PRODUCT",
          stats: { gross_items: 1, pass_count: 1, fail_count: 0, yield_pct: 100 },
        },
      },
      columns: ["die_x", "die_y", "x_mm", "y_mm", "bin_code", "bin_quality"],
      rows: [[0, 0, 0, 0, 1, "PASS"]],
    }),
  }));
  await page.getByRole("button", { name: "Reopen dataset" }).click();
  await page.getByRole("dialog", { name: "Authenticated import history" }).waitFor({ state: "hidden" });
  assert.equal(await page.locator("#btn-view-bin_category").isDisabled(), false, "reopened CP dataset must activate the existing overlay without re-uploading");
  assert.ok(await page.getByText("Dataset #701").count(), "reopened dataset identity must reach the control-room header");
  console.log("Ingestion E2E passed: real CSV package roles, safe no-file validation, explicit persistence gating, owner-scoped import history, and honest analysis-history unavailable UX operate without mocked production records.");
} finally {
  await browser.close();
}
