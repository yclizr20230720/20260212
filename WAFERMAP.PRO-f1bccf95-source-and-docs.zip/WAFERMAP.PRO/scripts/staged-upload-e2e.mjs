import assert from 'node:assert/strict';
import { chromium } from '@playwright/test';

const baseUrl = process.env.WAFERMAP_E2E_URL || 'http://127.0.0.1:3000';
const cpFixture = [
  'LOT_ID,WAFER_ID,WAFER_NO,PRODUCT_ID,DIE_X,DIE_Y,DIE_CENTER_X_MM,DIE_CENTER_Y_MM,WAFER_SIZE_MM,HARD_BIN,SOFT_BIN,BIN_NAME,PASS_FAIL,VTH_NMOS_V,VTH_PMOS_V,IDDQ_UA,RON_OHM,FMAX_MHZ,VDD_MIN_V,CONT_RES_OHM,ICC_ACTIVE_MA',
  'LOT-REAL,WAFER-001,1,PROD-REAL,0,0,0,0,300,1,1,PASS,P,0.41,-0.40,3.0,150,1200,0.78,0.9,45',
].join('\n');

const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  await page.goto(baseUrl, { waitUntil: 'networkidle' });
  await page.locator('#btn-open-ingestion').click();
  await page.locator('#package-file-cp-die-primary').setInputFiles({
    name: 'real_cp_fixture.csv',
    mimeType: 'text/csv',
    buffer: Buffer.from(cpFixture),
  });
  await page.locator('#btn-validate-package').click();
  await page.getByText('Server package-validation result').waitFor({ state: 'visible', timeout: 30_000 });
  assert.equal(await page.getByText('The package validation service rejected the request.').count(), 0);
  assert.equal(await page.getByText('Selection required').count(), 1, 'staged validation must preserve explicit partition selection');
  assert.equal(await page.getByRole('button', { name: 'Persist selected wafer' }).isDisabled(), true, 'staged validation must not persist without selected partition and geometry');
  assert.ok(await page.getByText('Gateway-safe staged upload').count(), 'upload progress provenance must remain visible');
  console.log('Staged upload E2E passed: bounded chunks validate a real-contract CP CSV without automatic persistence.');
} finally {
  await browser.close();
}
