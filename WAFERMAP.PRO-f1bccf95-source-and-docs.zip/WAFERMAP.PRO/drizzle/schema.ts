import { bigint, boolean, double, foreignKey, index, int, json, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const waferConfigurations = mysqlTable(
  "wafer_configurations",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId"),
    waferId: varchar("waferId", { length: 128 }).notNull(),
    lotId: varchar("lotId", { length: 128 }).notNull(),
    productId: varchar("productId", { length: 128 }).notNull(),
    configuration: json("configuration").$type<Record<string, unknown>>().notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [
    index("wafer_configurations_owner_created_idx").on(table.ownerId, table.createdAt),
    foreignKey({ columns: [table.ownerId], foreignColumns: [users.id], name: "wafer_owner_fk" }).onDelete("cascade"),
  ]
);

export const reticleLayouts = mysqlTable(
  "reticle_layouts",
  {
    id: int("id").autoincrement().primaryKey(),
    waferConfigurationId: int("waferConfigurationId").notNull(),
    revision: int("revision").notNull(),
    columns: int("columns").notNull(),
    rows: int("rows").notNull(),
    dieTypeMatrix: json("dieTypeMatrix").$type<string[][]>().notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    index("reticle_layouts_configuration_revision_idx").on(table.waferConfigurationId, table.revision),
    foreignKey({ columns: [table.waferConfigurationId], foreignColumns: [waferConfigurations.id], name: "reticle_wafer_fk" }).onDelete("cascade"),
  ]
);

export const analysisSessions = mysqlTable(
  "analysis_sessions",
  {
    id: int("id").autoincrement().primaryKey(),
    waferConfigurationId: int("waferConfigurationId").notNull(),
    reticleLayoutId: int("reticleLayoutId"),
    viewMode: mysqlEnum("viewMode", ["bin_category", "parametric_heatmap", "shot_yield", "defect_markers"])
      .notNull()
      .default("bin_category"),
    defectPattern: varchar("defectPattern", { length: 64 }).notNull(),
    layoutSnapshot: json("layoutSnapshot").$type<Record<string, unknown>>().notNull(),
    spatialSnapshot: json("spatialSnapshot").$type<Record<string, unknown>>(),
    optimizationSnapshot: json("optimizationSnapshot").$type<Record<string, unknown>>(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    index("analysis_sessions_configuration_created_idx").on(table.waferConfigurationId, table.createdAt),
    foreignKey({ columns: [table.waferConfigurationId], foreignColumns: [waferConfigurations.id], name: "analysis_wafer_fk" }).onDelete("cascade"),
    foreignKey({ columns: [table.reticleLayoutId], foreignColumns: [reticleLayouts.id], name: "analysis_reticle_fk" }).onDelete("set null"),
  ]
);

export const exportRecords = mysqlTable(
  "export_records",
  {
    id: int("id").autoincrement().primaryKey(),
    analysisSessionId: int("analysisSessionId"),
    format: mysqlEnum("format", ["semi_e142", "semi_g85", "csv", "png"]).notNull(),
    contentHash: varchar("contentHash", { length: 128 }).notNull(),
    byteSize: int("byteSize").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    index("export_records_session_created_idx").on(table.analysisSessionId, table.createdAt),
    foreignKey({ columns: [table.analysisSessionId], foreignColumns: [analysisSessions.id], name: "export_session_fk" }).onDelete("set null"),
  ]
);

export const importRuns = mysqlTable(
  "import_runs",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId"),
    sourceType: mysqlEnum("sourceType", ["CP", "WAT", "KLA"]).notNull(),
    originalFilename: varchar("originalFilename", { length: 255 }).notNull(),
    sourceHash: varchar("sourceHash", { length: 64 }).notNull(),
    status: mysqlEnum("status", ["PROCESSING", "COMPLETED", "REJECTED"]).notNull().default("PROCESSING"),
    diagnostics: json("diagnostics").$type<Record<string, unknown>>(),
    startedAt: timestamp("startedAt").defaultNow().notNull(),
    completedAt: timestamp("completedAt"),
  },
  table => [
    index("import_runs_status_started_idx").on(table.status, table.startedAt),
    foreignKey({ columns: [table.ownerId], foreignColumns: [users.id], name: "import_owner_fk" }).onDelete("cascade"),
  ]
);

export const ingestionDatasets = mysqlTable(
  "ingestion_datasets",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId"),
    importRunId: int("importRunId"),
    sourceType: mysqlEnum("sourceType", ["CP", "WAT", "KLA"]).notNull(),
    waferId: varchar("waferId", { length: 128 }).notNull(),
    lotId: varchar("lotId", { length: 128 }).notNull(),
    productId: varchar("productId", { length: 128 }).notNull(),
    originalFilename: varchar("originalFilename", { length: 255 }).notNull(),
    storageKey: varchar("storageKey", { length: 512 }).notNull(),
    storageUrl: varchar("storageUrl", { length: 640 }).notNull(),
    sourceHash: varchar("sourceHash", { length: 64 }).notNull(),
    sourceRole: varchar("sourceRole", { length: 64 }),
    parserMappingVersion: varchar("parserMappingVersion", { length: 64 }),
    packageDiagnostics: json("packageDiagnostics").$type<Record<string, unknown>>(),
    productProvenance: mysqlEnum("productProvenance", ["SOURCE", "UNAVAILABLE", "HETEROGENEOUS"])
      .notNull()
      .default("UNAVAILABLE"),
    byteSize: int("byteSize").notNull(),
    totalRows: int("totalRows").notNull(),
    validRows: int("validRows").notNull(),
    errorRows: int("errorRows").notNull(),
    columnMapping: json("columnMapping").$type<Record<string, string>>().notNull(),
    summary: json("summary").$type<Record<string, unknown>>().notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    index("ingest_wafer_created_idx").on(table.waferId, table.createdAt),
    index("ingest_source_created_idx").on(table.sourceType, table.createdAt),
    foreignKey({ columns: [table.ownerId], foreignColumns: [users.id], name: "ingest_owner_fk" }).onDelete("cascade"),
    foreignKey({ columns: [table.importRunId], foreignColumns: [importRuns.id], name: "ingest_run_fk" }).onDelete("set null"),
  ]
);

export const analysisJobs = mysqlTable(
  "analysis_jobs",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerOpenId: varchar("ownerOpenId", { length: 191 }).notNull(),
    ownerName: varchar("ownerName", { length: 255 }).notNull(),
    cpDatasetId: int("cpDatasetId").notNull(),
    watDatasetId: int("watDatasetId"),
    klaDatasetId: int("klaDatasetId"),
    status: mysqlEnum("status", ["QUEUED", "RUNNING", "COMPLETED", "FAILED"])
      .notNull()
      .default("QUEUED"),
    queueSequence: bigint("queueSequence", { mode: "number", unsigned: true }).notNull(),
    attempts: int("attempts").notNull().default(0),
    error: varchar("error", { length: 512 }),
    requestManifest: json("requestManifest").$type<Record<string, unknown>>().notNull(),
    requestVersion: varchar("requestVersion", { length: 64 }).notNull(),
    submittedAt: timestamp("submittedAt").defaultNow().notNull(),
    startedAt: timestamp("startedAt"),
    completedAt: timestamp("completedAt"),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [
    uniqueIndex("analysis_jobs_queue_sequence_uidx").on(table.queueSequence),
    index("analysis_jobs_owner_created_status_idx").on(table.ownerOpenId, table.submittedAt, table.status),
    index("analysis_jobs_status_queue_idx").on(table.status, table.queueSequence),
    index("analysis_jobs_cp_dataset_idx").on(table.cpDatasetId),
  ]
);

export const analysisReports = mysqlTable(
  "analysis_reports",
  {
    id: int("id").autoincrement().primaryKey(),
    jobId: int("jobId").notNull(),
    ownerOpenId: varchar("ownerOpenId", { length: 191 }).notNull(),
    filename: varchar("filename", { length: 255 }).notNull(),
    storageKey: varchar("storageKey", { length: 512 }).notNull(),
    storageUrl: varchar("storageUrl", { length: 640 }).notNull(),
    payloadHash: varchar("payloadHash", { length: 64 }).notNull(),
    byteSize: int("byteSize").notNull(),
    reportPayload: json("reportPayload").$type<Record<string, unknown>>().notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    uniqueIndex("analysis_reports_job_uidx").on(table.jobId),
    index("analysis_reports_owner_created_idx").on(table.ownerOpenId, table.createdAt),
    index("analysis_reports_job_idx").on(table.jobId),
    foreignKey({ columns: [table.jobId], foreignColumns: [analysisJobs.id], name: "analysis_report_job_fk" }).onDelete("cascade"),
  ]
);

export const cpDieMeasurements = mysqlTable(
  "cp_die_measurements",
  {
    id: int("id").autoincrement().primaryKey(),
    datasetId: int("datasetId").notNull(),
    dieX: int("dieX").notNull(),
    dieY: int("dieY").notNull(),
    xMm: double("xMm").notNull(),
    yMm: double("yMm").notNull(),
    hardBin: int("hardBin"),
    binCode: int("binCode").notNull(),
    binName: varchar("binName", { length: 256 }).notNull(),
    binQuality: mysqlEnum("binQuality", ["PASS", "FAIL", "NULL"]).notNull(),
    paramName: varchar("paramName", { length: 128 }),
    paramValue: double("paramValue"),
    paramUnit: varchar("paramUnit", { length: 32 }),
    testFreqGhz: double("testFreqGhz"),
    leakageUa: double("leakageUa"),
  },
  table => [
    index("cp_dataset_die_idx").on(table.datasetId, table.dieX, table.dieY),
    foreignKey({ columns: [table.datasetId], foreignColumns: [ingestionDatasets.id], name: "cp_dataset_fk" }).onDelete("cascade"),
  ]
);

export const watMeasurements = mysqlTable(
  "wat_measurements",
  {
    id: int("id").autoincrement().primaryKey(),
    datasetId: int("datasetId").notNull(),
    siteId: varchar("siteId", { length: 128 }).notNull(),
    dieX: int("dieX").notNull(),
    dieY: int("dieY").notNull(),
    xMm: double("xMm").notNull(),
    yMm: double("yMm").notNull(),
    paramName: varchar("paramName", { length: 128 }).notNull(),
    paramId: varchar("paramId", { length: 128 }),
    value: double("value").notNull(),
    unit: varchar("unit", { length: 32 }).notNull(),
    specLow: double("specLow"),
    specTarget: double("specTarget"),
    specHigh: double("specHigh"),
    status: mysqlEnum("status", ["PASS", "WARN", "FAIL"]).notNull(),
    sourceStatus: varchar("sourceStatus", { length: 32 }),
    module: varchar("module", { length: 128 }),
    paramGroup: varchar("paramGroup", { length: 128 }),
    testStructure: varchar("testStructure", { length: 128 }),
    criticality: varchar("criticality", { length: 64 }),
  },
  table => [
    index("wat_dataset_parameter_idx").on(table.datasetId, table.paramName),
    foreignKey({ columns: [table.datasetId], foreignColumns: [ingestionDatasets.id], name: "wat_dataset_fk" }).onDelete("cascade"),
  ]
);

export const klaDefects = mysqlTable(
  "kla_defects",
  {
    id: int("id").autoincrement().primaryKey(),
    datasetId: int("datasetId").notNull(),
    defectId: varchar("defectId", { length: 128 }).notNull(),
    dieX: int("dieX").notNull(),
    dieY: int("dieY").notNull(),
    xMm: double("xMm").notNull(),
    yMm: double("yMm").notNull(),
    xRelUm: double("xRelUm"),
    yRelUm: double("yRelUm"),
    reticleLocalXmm: double("reticleLocalXmm"),
    reticleLocalYmm: double("reticleLocalYmm"),
    sizeUm: double("sizeUm").notNull(),
    defectClass: varchar("defectClass", { length: 128 }).notNull(),
    classCode: varchar("classCode", { length: 64 }),
    classGroup: varchar("classGroup", { length: 128 }),
    killerFlag: boolean("killerFlag").notNull().default(false),
    layer: varchar("layer", { length: 128 }),
    inspectionTool: varchar("inspectionTool", { length: 128 }),
    inspectionRecipe: varchar("inspectionRecipe", { length: 128 }),
    inspectionStep: varchar("inspectionStep", { length: 128 }),
    reticleShotId: varchar("reticleShotId", { length: 128 }),
    clusterId: int("clusterId").notNull().default(0),
    isRepeater: boolean("isRepeater").notNull().default(false),
  },
  table => [
    index("kla_dataset_coordinate_idx").on(table.datasetId, table.xMm, table.yMm),
    index("kla_dataset_repeater_idx").on(table.datasetId, table.isRepeater),
    foreignKey({ columns: [table.datasetId], foreignColumns: [ingestionDatasets.id], name: "kla_dataset_fk" }).onDelete("cascade"),
  ]
);

export const cpParametricMeasurements = mysqlTable(
  "cp_parametric_measurements",
  {
    id: int("id").autoincrement().primaryKey(),
    datasetId: int("datasetId").notNull(),
    dieX: int("dieX").notNull(),
    dieY: int("dieY").notNull(),
    paramName: varchar("paramName", { length: 128 }).notNull(),
    value: double("value").notNull(),
    unit: varchar("unit", { length: 32 }).notNull(),
    specLow: double("specLow"),
    specHigh: double("specHigh"),
    isOos: boolean("isOos"),
  },
  table => [
    index("cp_parametric_dataset_parameter_idx").on(table.datasetId, table.paramName),
    foreignKey({ columns: [table.datasetId], foreignColumns: [ingestionDatasets.id], name: "cp_parametric_dataset_fk" }).onDelete("cascade"),
  ]
);

export type WaferConfiguration = typeof waferConfigurations.$inferSelect;
export type ReticleLayout = typeof reticleLayouts.$inferSelect;
export type AnalysisSession = typeof analysisSessions.$inferSelect;
export type ExportRecord = typeof exportRecords.$inferSelect;
export type ImportRun = typeof importRuns.$inferSelect;
export type IngestionDataset = typeof ingestionDatasets.$inferSelect;
export type AnalysisJob = typeof analysisJobs.$inferSelect;
export type AnalysisReport = typeof analysisReports.$inferSelect;
export type CpDieMeasurement = typeof cpDieMeasurements.$inferSelect;
export type CpParametricMeasurement = typeof cpParametricMeasurements.$inferSelect;
export type WatMeasurement = typeof watMeasurements.$inferSelect;
export type KlaDefect = typeof klaDefects.$inferSelect;
