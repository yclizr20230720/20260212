CREATE TABLE `cp_parametric_measurements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`datasetId` int NOT NULL,
	`dieX` int NOT NULL,
	`dieY` int NOT NULL,
	`paramName` varchar(128) NOT NULL,
	`value` double NOT NULL,
	`unit` varchar(32) NOT NULL,
	`specLow` double,
	`specHigh` double,
	`isOos` boolean,
	CONSTRAINT `cp_parametric_measurements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `cp_die_measurements` ADD `hardBin` int;--> statement-breakpoint
ALTER TABLE `ingestion_datasets` ADD `sourceRole` varchar(64);--> statement-breakpoint
ALTER TABLE `ingestion_datasets` ADD `parserMappingVersion` varchar(64);--> statement-breakpoint
ALTER TABLE `ingestion_datasets` ADD `packageDiagnostics` json;--> statement-breakpoint
ALTER TABLE `ingestion_datasets` ADD `productProvenance` enum('SOURCE','UNAVAILABLE','HETEROGENEOUS') DEFAULT 'UNAVAILABLE' NOT NULL;--> statement-breakpoint
ALTER TABLE `kla_defects` ADD `xRelUm` double;--> statement-breakpoint
ALTER TABLE `kla_defects` ADD `yRelUm` double;--> statement-breakpoint
ALTER TABLE `kla_defects` ADD `classCode` varchar(64);--> statement-breakpoint
ALTER TABLE `kla_defects` ADD `classGroup` varchar(128);--> statement-breakpoint
ALTER TABLE `kla_defects` ADD `killerFlag` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `kla_defects` ADD `inspectionTool` varchar(128);--> statement-breakpoint
ALTER TABLE `kla_defects` ADD `inspectionRecipe` varchar(128);--> statement-breakpoint
ALTER TABLE `kla_defects` ADD `inspectionStep` varchar(128);--> statement-breakpoint
ALTER TABLE `kla_defects` ADD `reticleShotId` varchar(128);--> statement-breakpoint
ALTER TABLE `wat_measurements` ADD `paramId` varchar(128);--> statement-breakpoint
ALTER TABLE `wat_measurements` ADD `sourceStatus` varchar(32);--> statement-breakpoint
ALTER TABLE `wat_measurements` ADD `module` varchar(128);--> statement-breakpoint
ALTER TABLE `wat_measurements` ADD `paramGroup` varchar(128);--> statement-breakpoint
ALTER TABLE `wat_measurements` ADD `testStructure` varchar(128);--> statement-breakpoint
ALTER TABLE `wat_measurements` ADD `criticality` varchar(64);--> statement-breakpoint
ALTER TABLE `cp_parametric_measurements` ADD CONSTRAINT `cp_parametric_dataset_fk` FOREIGN KEY (`datasetId`) REFERENCES `ingestion_datasets`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `cp_parametric_dataset_parameter_idx` ON `cp_parametric_measurements` (`datasetId`,`paramName`);