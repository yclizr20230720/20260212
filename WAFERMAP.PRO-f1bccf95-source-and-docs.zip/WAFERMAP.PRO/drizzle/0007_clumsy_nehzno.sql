CREATE TABLE `analysis_jobs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerOpenId` varchar(191) NOT NULL,
	`ownerName` varchar(255) NOT NULL,
	`cpDatasetId` int NOT NULL,
	`watDatasetId` int,
	`klaDatasetId` int,
	`status` enum('QUEUED','RUNNING','COMPLETED','FAILED') NOT NULL DEFAULT 'QUEUED',
	`queueSequence` bigint unsigned NOT NULL,
	`attempts` int NOT NULL DEFAULT 0,
	`error` varchar(512),
	`requestManifest` json NOT NULL,
	`requestVersion` varchar(64) NOT NULL,
	`submittedAt` timestamp NOT NULL DEFAULT (now()),
	`startedAt` timestamp,
	`completedAt` timestamp,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `analysis_jobs_id` PRIMARY KEY(`id`),
	CONSTRAINT `analysis_jobs_queue_sequence_uidx` UNIQUE(`queueSequence`)
);
--> statement-breakpoint
CREATE TABLE `analysis_reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`jobId` int NOT NULL,
	`ownerOpenId` varchar(191) NOT NULL,
	`filename` varchar(255) NOT NULL,
	`storageKey` varchar(512) NOT NULL,
	`storageUrl` varchar(640) NOT NULL,
	`payloadHash` varchar(64) NOT NULL,
	`byteSize` int NOT NULL,
	`reportPayload` json NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `analysis_reports_id` PRIMARY KEY(`id`),
	CONSTRAINT `analysis_reports_job_uidx` UNIQUE(`jobId`)
);
--> statement-breakpoint
ALTER TABLE `analysis_reports` ADD CONSTRAINT `analysis_report_job_fk` FOREIGN KEY (`jobId`) REFERENCES `analysis_jobs`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `analysis_jobs_owner_created_status_idx` ON `analysis_jobs` (`ownerOpenId`,`submittedAt`,`status`);--> statement-breakpoint
CREATE INDEX `analysis_jobs_status_queue_idx` ON `analysis_jobs` (`status`,`queueSequence`);--> statement-breakpoint
CREATE INDEX `analysis_jobs_cp_dataset_idx` ON `analysis_jobs` (`cpDatasetId`);--> statement-breakpoint
CREATE INDEX `analysis_reports_owner_created_idx` ON `analysis_reports` (`ownerOpenId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `analysis_reports_job_idx` ON `analysis_reports` (`jobId`);