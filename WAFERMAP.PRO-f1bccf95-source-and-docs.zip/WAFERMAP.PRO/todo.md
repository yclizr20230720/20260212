# Project TODO

- [x] Establish the retained-feature baseline for the uploaded WaferMap reference implementation.
- [x] Define and apply durable tables for wafer configurations, reticle layouts, analysis sessions, and export records.
- [x] Migrate the dark industrial control-room shell, header KPIs, and primary wafer workspace.
- [x] Migrate the control panel, presets, wafer geometry controls, and die/reticle configuration flows.
- [x] Migrate the Canvas wafer renderer with pan, zoom, selection, and Bin Map, Parametric, Shot Grid, and Defects modes.
- [x] Migrate Reticle Studio, Shot Optimizer, Spatial Analytics, Export, and Die Inspector flows without visual regression.
- [x] Add the Flask wafer calculation service with validated layout, optimizer, and SEMI E142/G85 export operations.
- [x] Integrate the managed website backend with the Flask service using deploy-safe request contracts and error states.
- [x] Persist wafer configuration snapshots, reticle-layout revisions, analysis sessions, and export audit records.
- [x] Add and pass unit tests for geometry, API contracts, persistence, and retained UI state transitions.
- [x] Run type checking, production build, health checks, and browser verification for core user workflows.
- [x] Write the deployment and operating guide for the long-term WAFERMAP.PRO website.
- [x] Create a release checkpoint and provide publishing instructions.
- [x] Fix wafer Canvas measurement initialization so wide layouts never render at an invalid position or show Infinity coordinates.
- [x] Restore reliable drag-to-pan behavior across mouse and touch pointer interactions.
- [x] Verify Canvas layout, finite telemetry, zoom, and panning on the reported ultra-wide viewport.
- [x] Audit the supplied CP, WAT, and KLA reference implementation and mock data schemas without executing untrusted code.
- [x] Define durable dataset, import-run, CP-die measurement, WAT-site measurement, and KLA-defect persistence entities.
- [x] Implement source-safe CP, WAT, and KLA upload APIs with file type, size, schema, and coordinate validation.
- [x] Parse supported source files into normalized wafer coordinates and record import status, diagnostics, and data lineage.
- [x] Add a non-disruptive Data Ingestion workspace for upload, data-source status, validation errors, and mock-data loading.
- [x] Render CP die bins, WAT parametric sites, and KLA defects as performant wafer-map overlays.
- [x] Add unit and end-to-end coverage using the supplied mock files for valid imports, invalid files, persistence, and overlays.
- [x] Document production data limits, supported schemas, retention, and operator workflow for CP, WAT, and KLA imports.
- [x] Create a release checkpoint and provide production publishing guidance for the data-ingestion update.
- [x] Match the supplied FAB Metrology & Defect Ingestion Studio workflow: CP, WAT, and KLA tabs; source-specific mock downloads; perspective cards; target-product selection; and an explicit ingest-and-generate action.
- [x] Add and migrate a distinct import-run audit entity linked to each persisted ingestion dataset, including lifecycle status and diagnostics.
- [x] Audit the supplied WaferMap-main(4) reference release and map its CP-analysis, VEDA, and manufacturing-data additions to the current Flask/React architecture.
- [x] Integrate production-safe CP analysis capabilities and source-aligned data workflow improvements without regressing CP/WAT/KLA ingestion or Canvas performance.
- [x] Add backend contract validation and automated coverage for the merged analysis workflow.
- [x] Run type, unit, API, browser, and production-build validation; save a checkpoint and publish the updated permanent site.
- [x] Audit WaferMap-main(6) and preserve only source-backed, production-safe capabilities.
- [x] Add a bounded persisted-dataset criteria API and source-backed CP parametric aggregates.
- [x] Merge VEDA-style criteria, CP/YMS quick actions, and active source status into the control-room UI.
- [x] Add and run API, type, unit, Canvas, ingestion, and browser coverage for the merged workflows.
- [x] Save a release checkpoint and make the updated WAFERMAP.PRO website available for review.
- [x] Publish checkpoint 344da22d to the permanent WAFERMAP.PRO domain and verify the live Data Criteria explorer.
- [x] Audit the reference CP and YMS studio tabs and map each capability to trustworthy persisted-source inputs.
- [x] Add server-side CP spatial screening, OCAP triage, and observed edge-exclusion what-if aggregates.
- [x] Build the complete CP and YMS studio with governed data-availability states and structured JSON export.
- [x] Run API, type, unit, Canvas, ingestion, and browser regression coverage for the expanded studio.
- [x] Save a release checkpoint and expose a verified public CP and YMS workflow while managed-domain propagation remains pending.
- [x] Verify the public CP and YMS source-selection and API result path; record that the temporary sandbox service is not persistent across user session transitions.
- [x] Verify the managed-domain health response; record that it remains on an older build because no managed publish control is exposed in this session.
- [x] Create a complete source-only archive without generated artifacts, caches, or credentials.
- [x] Verify archive integrity, file inventory, and package boundaries before delivery.
- [x] Bundle the user-provided CP, WAT, KLA, and VEDA sample data for standalone upload testing.
- [x] Rebuild and validate the final source archive with the complete sample-data directory.

## Next Production Hardening

- [x] Implement persisted import-run history and safe upload diagnostics.
- [x] Validate import history API, UI, reopen flow, and regression suite.
- [x] Save and verify the import-history release.
- [x] Prepare an authenticated ownership and RBAC design decision.
- [x] Prepare tiled Canvas and WebGL performance rollout design.

## Real Data Analytics Revamp

- [x] Audit supplied CP, WAT, and KLA production CSV schemas and remove mock-data dependencies.
- [x] Build robust real-data templates, uploads, validation, and normalized source contracts.
- [x] Drive wafer KPIs, charts, spatial map, and same-LotID/WaferID coordinate-overlap screening from real data.
- [x] Add persistent queued analysis jobs with resource-safe processing and JSON report history.
- [x] Validate real-data workflows, package source, and release the revamp.

## Production Access Completion

- [x] Route public OAuth and static assets through the Node host while retaining Flask as a private source-data API.
- [x] Validate authenticated ownership, selected-wafer persistence, queued source analysis, and per-user JSON report history with supplied real CSV partitions.
- [x] Remove bundled mock/reference data and update source-package documentation for a real-data-only distribution.
- [x] Run complete regression, migration, browser, container-topology, and real-data end-to-end validation before checkpointing and publishing.

## Release Completion

- [x] Save a checkpoint for the real-data, OAuth, correlation, and queue release.
- [x] Publish the checkpoint to the permanent domain and verify the live runtime.

## Package Validation Repair

- [x] Reproduce the real package validation rejection and identify its cause.
- [x] Fix validation request handling and user-facing diagnostics.
- [x] Run real-package and browser regressions, then publish the repair.
