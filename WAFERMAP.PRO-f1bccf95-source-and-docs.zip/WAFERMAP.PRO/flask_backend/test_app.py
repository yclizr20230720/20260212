"""Flask API regression tests for WAFERMAP.PRO."""

from __future__ import annotations

import unittest
from datetime import datetime, timezone
from io import BytesIO

from flask_backend.analysis_queue import REQUEST_MANIFEST_VERSION
from flask_backend.app import create_app
from flask_backend.auth import verify_hs256_session
from flask_backend.ingestion import IngestionValidationError, parse_ingestion_file
from flask_backend.repository import OwnedDatasetNotFound, QueueCapacityError, WaferRepository


VALID_PAYLOAD = {
    "wafer_id": "TEST-W300-001",
    "lot_id": "LOT-TEST",
    "product_id": "PRODUCT-TEST",
    "diameter_mm": 300,
    "edge_exclusion_mm": 3,
    "notch_angle_deg": 270,
    "center_offset_x_mm": 0,
    "center_offset_y_mm": 0,
    "die_width_mm": 8.5,
    "die_height_mm": 10.2,
    "scribe_x_mm": 0.08,
    "scribe_y_mm": 0.08,
    "reticle_cols": 3,
    "reticle_rows": 2,
    "die_type_matrix": [["DIE", "DIE", "REFERENCE_DIE"], ["DIE", "TEST_DIE", "DIE"]],
}

FORBIDDEN_GEOMETRY_KEYS = {
    "bin_code",
    "bin_name",
    "bin_quality",
    "defect_count",
    "defect_pattern",
    "fail_die_count",
    "fail_dies",
    "leakage_ua",
    "moran_i",
    "parametric_val",
    "pass_die_count",
    "pass_dies",
    "test_freq_ghz",
    "yield_pct",
}


class FakeRepository:
    def __init__(self) -> None:
        self.import_runs: list[dict] = []
        self.jobs: list[dict] = []
        self.reports: list[dict] = []
        self.users = {
            "owner-a": {"id": 1, "open_id": "owner-a", "name": "Test User", "role": "user"},
            "owner-b": {"id": 2, "open_id": "owner-b", "name": "Other User", "role": "user"},
        }
        self.datasets = {
            31: {"id": 31, "owner_open_id": "owner-a", "source_type": "CP", "wafer_id": "W300-CP-01", "lot_id": "LOT-CP", "product_id": "CP-PRODUCT", "product_provenance": "SOURCE", "measurement_rows": 2},
            32: {"id": 32, "owner_open_id": "owner-a", "source_type": "WAT", "wafer_id": "W300-CP-01", "lot_id": "LOT-CP", "product_id": "UNAVAILABLE", "product_provenance": "UNAVAILABLE", "measurement_rows": 4},
            33: {"id": 33, "owner_open_id": "owner-a", "source_type": "KLA", "wafer_id": "W300-CP-01", "lot_id": "LOT-CP", "product_id": "UNAVAILABLE", "product_provenance": "UNAVAILABLE", "measurement_rows": 3},
            41: {"id": 41, "owner_open_id": "owner-b", "source_type": "CP", "wafer_id": "W300-B-01", "lot_id": "LOT-B", "product_id": "B-PRODUCT", "product_provenance": "SOURCE", "measurement_rows": 2},
            42: {"id": 42, "owner_open_id": "owner-b", "source_type": "WAT", "wafer_id": "W300-B-01", "lot_id": "LOT-B", "product_id": "UNAVAILABLE", "product_provenance": "UNAVAILABLE", "measurement_rows": 1},
            98: {"id": 98, "owner_open_id": None, "source_type": "CP", "wafer_id": "LEGACY", "lot_id": "LEGACY", "product_id": "LEGACY", "product_provenance": "SOURCE", "measurement_rows": 1},
            99: {"id": 99, "owner_open_id": "owner-a", "source_type": "WAT", "wafer_id": "OTHER", "lot_id": "OTHER", "product_id": "UNAVAILABLE", "product_provenance": "UNAVAILABLE", "measurement_rows": 1},
        }
        self.fail_analysis = False
        self.hold_claims = False
        self.claim_calls = 0

    def recent_sessions(self, limit):
        return []

    def ensure_owner(self, open_id, name):
        owner = self.users.get(open_id)
        if owner is None:
            owner = {"id": len(self.users) + 1, "open_id": open_id, "name": name, "role": "user"}
            self.users[open_id] = owner
        else:
            owner["name"] = name
        return owner["id"]

    def start_import_run(self, source_type, filename, source_hash, *, owner_id):
        import_run_id = 41 + len(self.import_runs)
        self.import_runs.append({"id": import_run_id, "owner_id": owner_id, "source_type": source_type, "filename": filename, "source_hash": source_hash, "status": "PROCESSING"})
        return import_run_id

    def finish_import_run(self, import_run_id, status, diagnostics):
        self.import_runs[-1].update({"id": import_run_id, "status": status, "diagnostics": diagnostics})

    def import_runs_for_owner(self, owner_open_id, limit):
        self.import_history_request = {"owner_open_id": owner_open_id, "limit": limit}
        owner = self.users.get(owner_open_id)
        if owner is None:
            return []
        history = []
        for run in reversed(self.import_runs):
            if run["owner_id"] != owner["id"]:
                continue
            diagnostics = run.get("diagnostics") or {}
            dataset_id = diagnostics.get("dataset_id") if isinstance(diagnostics, dict) else None
            dataset_record = self.datasets.get(dataset_id) if isinstance(dataset_id, int) else None
            dataset = None
            if dataset_record and dataset_record["owner_open_id"] == owner_open_id:
                dataset = {
                    "id": dataset_record["id"],
                    "lot_id": dataset_record["lot_id"],
                    "wafer_id": dataset_record["wafer_id"],
                    "product_id": dataset_record["product_id"],
                    "total_rows": dataset_record["measurement_rows"],
                    "valid_rows": dataset_record["measurement_rows"],
                    "error_rows": 0,
                    "byte_size": 1234,
                }
            selected = diagnostics.get("selected_partition") if isinstance(diagnostics, dict) else None
            history.append({
                "id": run["id"],
                "source_type": run["source_type"],
                "status": run["status"],
                "original_filename": run["filename"],
                "source_hash": run["source_hash"],
                "started_at": "2026-09-29T00:00:00Z",
                "completed_at": "2026-09-29T00:01:00Z" if run["status"] != "PROCESSING" else None,
                "operation": diagnostics.get("operation", "SINGLE_SOURCE_IMPORT") if isinstance(diagnostics, dict) else "SINGLE_SOURCE_IMPORT",
                "selected_partition": selected if isinstance(selected, dict) else None,
                "source_roles": diagnostics.get("retained_roles", []) if isinstance(diagnostics, dict) else [],
                "counts": {
                    key: diagnostics[key] for key in ("valid_rows", "error_rows", "total_rows", "source_package_partition_count")
                    if isinstance(diagnostics, dict) and isinstance(diagnostics.get(key), int)
                },
                "diagnostic_codes": [
                    {key: item[key] for key in ("code", "role", "severity") if isinstance(item.get(key), str)}
                    for item in (diagnostics.get("diagnostics", []) if isinstance(diagnostics, dict) and isinstance(diagnostics.get("diagnostics"), list) else [])[:10]
                    if isinstance(item, dict)
                ],
                "error_type": diagnostics.get("error_type") if isinstance(diagnostics, dict) and isinstance(diagnostics.get("error_type"), str) else None,
                "has_error": bool(isinstance(diagnostics, dict) and (diagnostics.get("error") or diagnostics.get("error_type"))),
                "dataset": dataset,
            })
        return history[:limit]

    def save_ingestion_dataset(self, source_type, parsed, storage, source_hash, byte_size, *, import_run_id, owner_id):
        self.ingestion = {"owner_id": owner_id, "source_type": source_type, "parsed": parsed, "storage": storage, "source_hash": source_hash, "byte_size": byte_size, "import_run_id": import_run_id}
        return {"dataset_id": 31, "import_run_id": import_run_id, "source_type": source_type, "summary": parsed["summary"], "storage_url": storage["url"]}

    def ingestion_overlay(self, dataset_id, owner_open_id):
        dataset = self.datasets.get(dataset_id)
        if dataset_id != 31 or not dataset or dataset["owner_open_id"] != owner_open_id:
            return None
        return {"dataset": {"id": 31, "source_type": "CP", "wafer_id": "W300-CP-01", "lot_id": "LOT-CP", "product_id": "CP-PRODUCT", "summary": {}}, "columns": ["die_x", "die_y", "x_mm", "y_mm", "bin_code", "bin_quality"], "rows": [[0, 0, 0, 0, 1, "PASS"]]}

    def recent_ingestion_datasets(self, owner_open_id, limit):
        return [
            {"id": item["id"], "sourceType": item["source_type"], "waferId": item["wafer_id"]}
            for item in self.datasets.values() if item["owner_open_id"] == owner_open_id
        ][:limit]

    def ingestion_analysis(self, cp_dataset_id, *, wat_dataset_id=None, kla_dataset_id=None, owner_open_id=None):
        if self.fail_analysis:
            raise RuntimeError("secret source row=TOP-SECRET https://private.example/object")
        if owner_open_id is None:
            running = next((job for job in self.jobs if job["status"] == "RUNNING" and job["cp_dataset_id"] == cp_dataset_id and job["wat_dataset_id"] == wat_dataset_id and job["kla_dataset_id"] == kla_dataset_id), None)
            owner_open_id = running["owner_open_id"] if running else None
        cp = self.datasets.get(cp_dataset_id)
        if not cp or cp["source_type"] != "CP" or cp["owner_open_id"] != owner_open_id:
            raise OwnedDatasetNotFound("Ingestion dataset was not found.")
        for dataset_id, source_type in ((wat_dataset_id, "WAT"), (kla_dataset_id, "KLA")):
            if dataset_id is None:
                continue
            selected = self.datasets.get(dataset_id)
            if not selected or selected["source_type"] != source_type or selected["owner_open_id"] != owner_open_id:
                raise OwnedDatasetNotFound("Ingestion dataset was not found.")
        if wat_dataset_id == 99 or kla_dataset_id == 99:
            raise ValueError("Selected datasets do not share the same lot, wafer identity.")
        return {
            "cp": {
                "dataset": {"id": 31, "source_type": "CP", "wafer_id": "W300-CP-01", "lot_id": "LOT-CP", "product_id": "CP-PRODUCT"},
                "total_dies": 2,
                "pass_dies": 1,
                "fail_dies": 1,
                "yield_pct": 50.0,
                "bins": [{"bin_code": 3, "bin_name": "BIN_3", "count": 1, "percent_of_fails": 100.0, "cumulative_percent": 100.0}],
                "parametrics": [{"param_name": "VTH", "param_unit": "V", "measured_rows": 2, "mean": 0.31, "std_dev": 0.02, "min": 0.29, "max": 0.33}],
                "spatial": {"coordinate_note": "Imported coordinates only.", "radial_zones": [{"zone": "Center 0–50 mm", "total_dies": 2, "pass_dies": 1, "fail_dies": 1, "yield_pct": 50.0}], "failure_components": {"component_count": 1, "cluster_count": 0, "clustered_failure_dies": 0, "isolated_failure_dies": 1, "top_clusters": []}},
                "telemetry": [{"name": "Test frequency", "unit": "GHz", "measured_rows": 0, "mean": None, "std_dev": None, "min": None, "max": None}, {"name": "Leakage", "unit": "µA", "measured_rows": 0, "mean": None, "std_dev": None, "min": None, "max": None}],
                "observed_edge_scenarios": [{"edge_exclusion_mm": 3.0, "included_dies": 2, "excluded_dies": 0, "pass_dies": 1, "fail_dies": 1, "yield_pct": 50.0}],
            },
            "wat": {"available": wat_dataset_id is not None, "dataset": None, "compatibility": {"status": "MATCHED" if wat_dataset_id else "NOT_LOADED", "message": None}, "total_measurements": 0, "fail_measurements": 0, "parameters": []},
            "kla": {"available": kla_dataset_id is not None, "dataset": None, "compatibility": {"status": "MATCHED" if kla_dataset_id else "NOT_LOADED", "message": None}, "total_defects": 0, "repeater_defects": 0, "correlations": []},
            "ocap": {"status": "REVIEW", "scope_note": "Observed source aggregates only.", "evidence": [{"category": "CP", "label": "Primary detractor", "value": "1 die", "detail": "BIN_3"}], "recommendations": ["Review the source-backed bin evidence."]},
            "correlation_ready": False,
            "correlation_reasons": ["Coordinate frames have not been proven aligned."],
        }

    def validate_analysis_sources(self, cp_dataset_id, *, wat_dataset_id=None, kla_dataset_id=None, minimum_cp_measurements=1, owner_open_id):
        selections = ((cp_dataset_id, "CP"), (wat_dataset_id, "WAT"), (kla_dataset_id, "KLA"))
        cp = self.datasets.get(cp_dataset_id)
        if not cp or cp["source_type"] != "CP" or cp["owner_open_id"] != owner_open_id:
            raise OwnedDatasetNotFound("Ingestion dataset was not found.")
        if cp["measurement_rows"] < minimum_cp_measurements:
            raise ValueError("CP dataset does not meet the minimum persisted measurement-row requirement.")
        result = []
        for dataset_id, source_type in selections:
            if dataset_id is None:
                continue
            dataset = self.datasets.get(dataset_id)
            if not dataset or dataset["source_type"] != source_type or dataset["owner_open_id"] != owner_open_id:
                raise OwnedDatasetNotFound("Ingestion dataset was not found.")
            if dataset["lot_id"] != cp["lot_id"] or dataset["wafer_id"] != cp["wafer_id"]:
                raise ValueError("Selected datasets do not share the same lot, wafer identity.")
            result.append(dict(dataset))
        return result

    def enqueue_analysis_job(self, owner_open_id, owner_name, cp_dataset_id, *, wat_dataset_id, kla_dataset_id, request_manifest, request_version, owner_active_cap, global_backlog_cap):
        active = [job for job in self.jobs if job["status"] in {"QUEUED", "RUNNING"}]
        if len(active) >= global_backlog_cap:
            raise QueueCapacityError(f"The global analysis backlog limit of {global_backlog_cap} active jobs has been reached.")
        if sum(job["owner_open_id"] == owner_open_id for job in active) >= owner_active_cap:
            raise QueueCapacityError(f"Your active analysis-job limit of {owner_active_cap} has been reached.")
        job = {
            "id": len(self.jobs) + 1,
            "job_id": len(self.jobs) + 1,
            "owner_open_id": owner_open_id,
            "owner_name": owner_name,
            "cp_dataset_id": cp_dataset_id,
            "wat_dataset_id": wat_dataset_id,
            "kla_dataset_id": kla_dataset_id,
            "status": "QUEUED",
            "queue_sequence": len(self.jobs) + 1,
            "attempts": 0,
            "error": None,
            "request_version": request_version,
            "request_manifest": request_manifest,
            "submitted_at": datetime.now(timezone.utc),
            "started_at": None,
            "completed_at": None,
            "updated_at": datetime.now(timezone.utc),
            "report": None,
        }
        self.jobs.append(job)
        return dict(job)

    def claim_next_analysis_job(self, *, stale_after_seconds):
        del stale_after_seconds
        self.claim_calls += 1
        if self.hold_claims or any(job["status"] == "RUNNING" for job in self.jobs):
            return None
        job = next((item for item in self.jobs if item["status"] == "QUEUED"), None)
        if job is None:
            return None
        job.update({"status": "RUNNING", "attempts": job["attempts"] + 1, "started_at": datetime.now(timezone.utc), "updated_at": datetime.now(timezone.utc)})
        return dict(job)

    def complete_analysis_job(self, job_id, owner_open_id, *, filename, storage_key, storage_url, payload_hash, byte_size, payload):
        job = next(job for job in self.jobs if job["id"] == job_id and job["owner_open_id"] == owner_open_id)
        report = {
            "id": len(self.reports) + 1,
            "job_id": job_id,
            "owner_open_id": owner_open_id,
            "filename": filename,
            "storage_key": storage_key,
            "storage_url": storage_url,
            "payload_hash": payload_hash,
            "byte_size": byte_size,
            "payload": payload,
            "created_at": datetime.now(timezone.utc),
            "source_datasets": job["request_manifest"]["sources"],
        }
        self.reports.append(report)
        job.update({
            "status": "COMPLETED",
            "completed_at": datetime.now(timezone.utc),
            "updated_at": datetime.now(timezone.utc),
            "report": {
                "id": report["id"],
                "filename": filename,
                "payload_hash": payload_hash,
                "byte_size": byte_size,
                "created_at": report["created_at"],
            },
        })
        return report["id"]

    def fail_analysis_job(self, job_id, owner_open_id, error):
        job = next(job for job in self.jobs if job["id"] == job_id and job["owner_open_id"] == owner_open_id)
        job.update({"status": "FAILED", "error": error[:512], "completed_at": datetime.now(timezone.utc), "updated_at": datetime.now(timezone.utc)})

    def analysis_job_for_owner(self, job_id, owner_open_id):
        job = next((job for job in self.jobs if job["id"] == job_id and job["owner_open_id"] == owner_open_id), None)
        return dict(job) if job else None

    def analysis_jobs_for_owner(self, owner_open_id, limit=50):
        return [dict(job) for job in reversed(self.jobs) if job["owner_open_id"] == owner_open_id][:limit]

    def analysis_reports_for_owner(self, owner_open_id, limit=50):
        return [
            {key: value for key, value in report.items() if key not in {"owner_open_id", "storage_key", "storage_url", "payload"}}
            for report in reversed(self.reports) if report["owner_open_id"] == owner_open_id
        ][:limit]

    def analysis_report_for_owner(self, report_id, owner_open_id):
        report = next((item for item in self.reports if item["id"] == report_id and item["owner_open_id"] == owner_open_id), None)
        if report is None:
            return None
        return {key: value for key, value in report.items() if key not in {"owner_open_id", "storage_key", "storage_url"}}

    def ingestion_dataset_catalog(self, *, owner_open_id, source_types=None, lot_id=None, wafer_id=None, product_id=None, limit=50):
        self.catalog_request = {"owner_open_id": owner_open_id, "source_types": source_types, "lot_id": lot_id, "wafer_id": wafer_id, "product_id": product_id, "limit": limit}
        datasets = [item for item in self.datasets.values() if item["owner_open_id"] == owner_open_id]
        datasets = [item for item in datasets if not source_types or item["source_type"] in source_types]
        datasets = [item for item in datasets if not lot_id or item["lot_id"] == lot_id]
        datasets = [item for item in datasets if not wafer_id or item["wafer_id"] == wafer_id]
        datasets = [item for item in datasets if not product_id or item["product_id"] == product_id]
        return {
            "datasets": [{"id": item["id"], "sourceType": item["source_type"], "waferId": item["wafer_id"], "lotId": item["lot_id"], "productId": item["product_id"], "originalFilename": "source.csv", "validRows": item["measurement_rows"], "errorRows": 0, "createdAt": None} for item in datasets[:limit]],
            "criteria": {"source_types": ["CP", "WAT", "KLA"], "lot_ids": ["LOT-CP"], "wafer_ids": ["W300-CP-01"], "product_ids": ["CP-PRODUCT"]},
        }


class FakeStorage:
    def __init__(self) -> None:
        self.puts: list[dict] = []
        self.fail_reports = False

    def put(self, filename, content, content_type):
        if self.fail_reports and filename.endswith(".json"):
            from flask_backend.storage import StorageUnavailable
            raise StorageUnavailable("secret storage endpoint failure")
        self.puts.append({"filename": filename, "content": content, "content_type": content_type})
        return {"key": "wafermap/ingestion/test_cp.csv", "url": "/manus-storage/wafermap/ingestion/test_cp.csv"}


class WaferMapApiTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self.repository = FakeRepository()
        self.storage = FakeStorage()
        self.identity = {"open_id": "owner-a", "app_id": "test-app", "name": "Test User"}
        self.app = create_app({"TESTING": True, "WAFER_REPOSITORY": self.repository, "INGESTION_STORAGE": self.storage, "ANALYSIS_TEST_IDENTITY": self.identity})
        self.client = self.app.test_client()

    def _analysis_client(self, identity=None, **config):
        app_config = {
            "TESTING": True,
            "WAFER_REPOSITORY": self.repository,
            "INGESTION_STORAGE": self.storage,
            "ANALYSIS_TEST_IDENTITY": identity,
            **config,
        }
        return create_app(app_config).test_client()

    def test_analysis_queue_authentication_is_required_and_production_test_identity_is_forbidden(self) -> None:
        unauthenticated = self._analysis_client(None)
        response = unauthenticated.get("/api/analysis/jobs")
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json["error"], "authentication_required")
        header_spoof = unauthenticated.get("/api/analysis/jobs", headers={"X-OpenId": "owner-a", "X-User-Name": "Test User"})
        self.assertEqual(header_spoof.status_code, 401)

        invalid_cookie_app = create_app({"TESTING": True, "WAFER_REPOSITORY": self.repository, "INGESTION_STORAGE": self.storage, "JWT_SECRET": "correct-secret"})
        invalid_cookie_app.test_client().set_cookie("app_session_id", "not-a-jwt")
        invalid = invalid_cookie_app.test_client()
        invalid.set_cookie("app_session_id", "not-a-jwt")
        forbidden = invalid.get("/api/analysis/jobs")
        self.assertEqual(forbidden.status_code, 403)
        self.assertEqual(forbidden.json["error"], "invalid_session")

        with self.assertRaises(RuntimeError):
            create_app({"TESTING": False, "WAFER_REPOSITORY": self.repository, "INGESTION_STORAGE": self.storage, "ANALYSIS_TEST_IDENTITY": self.identity})

    def test_stdlib_hs256_verifier_accepts_existing_session_shape_and_rejects_tampering(self) -> None:
        import base64
        import hashlib
        import hmac
        import json
        import time

        def encode(value):
            return base64.urlsafe_b64encode(json.dumps(value, separators=(",", ":")).encode()).rstrip(b"=").decode()

        header = encode({"alg": "HS256", "typ": "JWT"})
        payload = encode({"openId": "owner-a", "appId": "app-1", "name": "Test User", "exp": int(time.time()) + 60})
        signature = base64.urlsafe_b64encode(hmac.new(b"secret", f"{header}.{payload}".encode(), hashlib.sha256).digest()).rstrip(b"=").decode()
        token = f"{header}.{payload}.{signature}"
        identity = verify_hs256_session(token, "secret")
        self.assertEqual(identity.open_id, "owner-a")
        with self.assertRaises(ValueError):
            verify_hs256_session(token + "x", "secret")

        cookie_app = create_app({"TESTING": True, "WAFER_REPOSITORY": self.repository, "INGESTION_STORAGE": self.storage, "JWT_SECRET": "secret"})
        cookie_client = cookie_app.test_client()
        cookie_client.set_cookie("app_session_id", token)
        authenticated = cookie_client.get("/api/analysis/jobs")
        self.assertEqual(authenticated.status_code, 200)
        self.assertEqual(authenticated.json["jobs"], [])

    def test_analysis_submission_rejects_unknown_fields_invalid_ids_and_insufficient_cp_rows(self) -> None:
        unknown = self.client.post("/api/analysis/jobs", json={"cp_dataset_id": 31, "invent_data": True})
        self.assertEqual(unknown.status_code, 400)
        invalid = self.client.post("/api/analysis/jobs", json={"cp_dataset_id": True})
        self.assertEqual(invalid.status_code, 400)
        insufficient = self._analysis_client(self.identity, ANALYSIS_MIN_CP_MEASUREMENTS=3).post(
            "/api/analysis/jobs", json={"cp_dataset_id": 31}
        )
        self.assertEqual(insufficient.status_code, 400)
        self.assertEqual(self.repository.jobs, [])

    def test_analysis_enqueue_claims_and_completes_at_most_one_source_backed_job(self) -> None:
        response = self.client.post("/api/analysis/jobs", json={"cp_dataset_id": 31, "wat_dataset_id": 32, "kla_dataset_id": 33})
        self.assertEqual(response.status_code, 202)
        self.assertEqual(response.json["job"]["job_id"], 1)
        self.assertEqual(response.json["job"]["status"], "COMPLETED")
        self.assertEqual(response.json["job"]["attempts"], 1)
        self.assertEqual(response.json["job"]["report"]["id"], 1)
        self.assertEqual(response.json["execution"]["max_claims_this_request"], 1)
        self.assertEqual(self.repository.claim_calls, 1)
        self.assertEqual(len(self.repository.reports), 1)
        report_payload = self.repository.reports[0]["payload"]
        self.assertTrue(report_payload["sources"]["source_backed"])
        self.assertEqual(report_payload["sources"]["datasets"][0]["id"], 31)
        self.assertEqual(report_payload["aggregate_result"]["cp"]["total_dies"], 2)

    def test_analysis_status_request_drains_only_one_fifo_job(self) -> None:
        self.repository.hold_claims = True
        first = self.client.post("/api/analysis/jobs", json={"cp_dataset_id": 31})
        second = self.client.post("/api/analysis/jobs", json={"cp_dataset_id": 31})
        self.assertEqual(first.json["job"]["status"], "QUEUED")
        self.assertEqual(second.json["job"]["status"], "QUEUED")
        self.repository.hold_claims = False
        calls_before = self.repository.claim_calls
        listing = self.client.get("/api/analysis/jobs")
        self.assertEqual(self.repository.claim_calls, calls_before + 1)
        statuses = {job["id"]: job["status"] for job in listing.json["jobs"]}
        self.assertEqual(statuses, {1: "COMPLETED", 2: "QUEUED"})
        self.assertEqual(len(self.repository.reports), 1)

    def test_analysis_rejects_incompatible_source_identity_before_enqueue(self) -> None:
        response = self.client.post("/api/analysis/jobs", json={"cp_dataset_id": 31, "wat_dataset_id": 99})
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json["error"], "validation_error")
        self.assertIn("same lot", response.json["message"])
        self.assertEqual(self.repository.jobs, [])

    def test_analysis_job_and_report_are_strictly_owner_scoped(self) -> None:
        completed = self.client.post("/api/analysis/jobs", json={"cp_dataset_id": 31})
        self.assertEqual(completed.status_code, 202)
        other = self._analysis_client({"open_id": "owner-b", "app_id": "test-app", "name": "Other User"})
        self.assertEqual(other.get("/api/analysis/jobs/1").status_code, 404)
        self.assertEqual(other.get("/api/analysis/reports/1").status_code, 404)
        self.assertEqual(other.get("/api/analysis/reports/1/download").status_code, 404)
        self.assertEqual(other.get("/api/analysis/jobs").json["jobs"], [])
        self.assertEqual(other.get("/api/analysis/reports").json["reports"], [])

    def test_analysis_failure_is_safe_and_storage_failure_never_completes(self) -> None:
        self.repository.fail_analysis = True
        failed = self.client.post("/api/analysis/jobs", json={"cp_dataset_id": 31})
        self.assertEqual(failed.json["job"]["status"], "FAILED")
        self.assertNotIn("TOP-SECRET", failed.json["job"]["error"])
        self.assertNotIn("private.example", failed.json["job"]["error"])
        self.assertLessEqual(len(failed.json["job"]["error"]), 512)
        self.assertEqual(self.repository.reports, [])

        self.repository.fail_analysis = False
        self.storage.fail_reports = True
        storage_failed = self.client.post("/api/analysis/jobs", json={"cp_dataset_id": 31})
        self.assertEqual(storage_failed.json["job"]["status"], "FAILED")
        self.assertIn("storage failed", storage_failed.json["job"]["error"].lower())
        self.assertEqual(self.repository.reports, [])

    def test_analysis_report_size_cap_fails_before_storage(self) -> None:
        constrained = self._analysis_client(self.identity, ANALYSIS_REPORT_MAX_BYTES=128)
        response = constrained.post("/api/analysis/jobs", json={"cp_dataset_id": 31})
        self.assertEqual(response.status_code, 202)
        self.assertEqual(response.json["job"]["status"], "FAILED")
        self.assertIn("128-byte limit", response.json["job"]["error"])
        self.assertEqual(self.storage.puts, [])
        self.assertEqual(self.repository.reports, [])

    def test_analysis_report_filename_history_detail_and_download_contract(self) -> None:
        completed = self.client.post("/api/analysis/jobs", json={"cp_dataset_id": 31, "wat_dataset_id": 32})
        self.assertEqual(completed.json["job"]["status"], "COMPLETED")
        history = self.client.get("/api/analysis/reports")
        self.assertEqual(history.status_code, 200)
        self.assertEqual(len(history.json["reports"]), 1)
        metadata = history.json["reports"][0]
        self.assertRegex(metadata["filename"], r"^Test_User_\d{8}T\d{6}Z_WAFERMAP_PRO_analysis_1\.json$")
        self.assertEqual([item["id"] for item in metadata["source_datasets"]], [31, 32])
        self.assertNotIn("storage_url", str(history.json).lower())
        self.assertNotIn("storage_key", str(history.json).lower())

        detail = self.client.get("/api/analysis/reports/1")
        self.assertEqual(detail.status_code, 200)
        self.assertEqual(detail.json["report"]["payload"]["job"]["id"], 1)
        self.assertNotIn("storage_url", str(detail.json).lower())
        self.assertNotIn("storage_key", str(detail.json).lower())
        download = self.client.get("/api/analysis/reports/1/download")
        self.assertEqual(download.status_code, 200)
        self.assertTrue(download.content_type.startswith("application/json"))
        self.assertIn("attachment", download.headers["Content-Disposition"])
        self.assertEqual(download.json["job"]["id"], 1)
        import hashlib
        self.assertEqual(len(download.data), metadata["byte_size"])
        self.assertEqual(hashlib.sha256(download.data).hexdigest(), metadata["payload_hash"])

    def test_analysis_owner_and_global_caps_return_429_without_extra_claim(self) -> None:
        owner_limited = self._analysis_client(self.identity, ANALYSIS_OWNER_ACTIVE_CAP=1, ANALYSIS_GLOBAL_BACKLOG_CAP=10)
        self.repository.hold_claims = True
        self.assertEqual(owner_limited.post("/api/analysis/jobs", json={"cp_dataset_id": 31}).status_code, 202)
        calls_before = self.repository.claim_calls
        owner_overflow = owner_limited.post("/api/analysis/jobs", json={"cp_dataset_id": 31})
        self.assertEqual(owner_overflow.status_code, 429)
        self.assertEqual(owner_overflow.json["error"], "analysis_queue_capacity")
        self.assertEqual(self.repository.claim_calls, calls_before)

        self.repository.jobs.clear()
        global_limited = self._analysis_client(self.identity, ANALYSIS_OWNER_ACTIVE_CAP=5, ANALYSIS_GLOBAL_BACKLOG_CAP=1)
        other = self._analysis_client({"open_id": "owner-b", "app_id": "test-app", "name": "Other"}, ANALYSIS_OWNER_ACTIVE_CAP=5, ANALYSIS_GLOBAL_BACKLOG_CAP=1)
        self.assertEqual(global_limited.post("/api/analysis/jobs", json={"cp_dataset_id": 31}).status_code, 202)
        global_overflow = other.post("/api/analysis/jobs", json={"cp_dataset_id": 41})
        self.assertEqual(global_overflow.status_code, 429)
        self.assertIn("global", global_overflow.json["message"].lower())

    def test_other_owner_and_legacy_sources_are_not_disclosed_or_queued(self) -> None:
        other = self._analysis_client({"open_id": "owner-b", "app_id": "test-app", "name": "Other User"})
        self.assertEqual(other.get("/api/ingestion/datasets/31/overlay").status_code, 404)
        self.assertEqual(other.get("/api/ingestion/datasets/31/analysis").status_code, 404)
        self.assertEqual(other.post("/api/analysis/jobs", json={"cp_dataset_id": 31}).status_code, 404)
        self.assertEqual(self.client.post("/api/analysis/jobs", json={"cp_dataset_id": 31, "wat_dataset_id": 42}).status_code, 404)
        self.assertEqual(self.client.post("/api/analysis/jobs", json={"cp_dataset_id": 98}).status_code, 404)
        catalog = other.get("/api/ingestion/catalog")
        self.assertEqual(catalog.status_code, 200)
        self.assertEqual([item["id"] for item in catalog.json["datasets"]], [41, 42])
        self.assertNotIn(31, [item["id"] for item in catalog.json["datasets"]])
        own = other.post("/api/analysis/jobs", json={"cp_dataset_id": 41, "wat_dataset_id": 42})
        self.assertEqual(own.status_code, 202)
        self.assertEqual(own.json["job"]["status"], "COMPLETED")

    def test_health_reports_persistence_availability(self) -> None:
        response = self.client.get("/api/health")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json["status"], "ok")
        self.assertTrue(response.json["persistence_available"])

    def test_default_is_geometry_only_without_fabricated_measurements(self) -> None:
        response = self.client.get("/api/wafer/default")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json["contract"]["mode"], "GEOMETRY_ONLY")
        self.assertEqual(response.json["contract"]["measurement_state"], "NO_SOURCE_DATASET")
        self.assertEqual(response.json["metadata"]["wafer_id"], "UNSPECIFIED")
        self.assertGreater(response.json["metadata"]["gross_die_count"], 0)
        self.assertGreater(response.json["metadata"]["theoretical_gross_die_count"], 0)
        self.assertTrue(response.json["dies"])
        self.assertTrue(response.json["shots"])
        serialized = str(response.json).lower()
        for key in FORBIDDEN_GEOMETRY_KEYS:
            self.assertNotIn(f"'{key}'", serialized)
        self.assertNotIn("'pass'", serialized)
        self.assertNotIn("'fail'", serialized)

    def test_calculate_returns_explicit_no_source_analytics_and_never_persists(self) -> None:
        response = self.client.post("/api/wafer/calculate", json=VALID_PAYLOAD)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json["layout"]["contract"]["mode"], "GEOMETRY_ONLY")
        self.assertFalse(response.json["spatial"]["available"])
        self.assertEqual(response.json["spatial"]["state"], "NO_SOURCE_DATASET")
        self.assertNotIn("persistence", response.json)
        persisted = self.client.post("/api/wafer/calculate", json={**VALID_PAYLOAD, "persist": True})
        self.assertEqual(persisted.status_code, 409)
        self.assertEqual(persisted.json["error"], "source_data_required")

    def test_calculate_rejects_invalid_reticle_matrix(self) -> None:
        response = self.client.post("/api/wafer/calculate", json={**VALID_PAYLOAD, "reticle_rows": 3})
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json["error"], "validation_error")

    def test_deterministic_center_offset_grid_search_is_geometry_only(self) -> None:
        first = self.client.post("/api/wafer/grid-search-center-offset", json={**VALID_PAYLOAD, "grid_steps": 4})
        second = self.client.post("/api/wafer/grid-search-center-offset", json={**VALID_PAYLOAD, "grid_steps": 4})
        self.assertEqual(first.status_code, 200)
        self.assertEqual(first.json, second.json)
        self.assertEqual(first.json["search_method"], "DETERMINISTIC_CENTER_OFFSET_GRID_SEARCH")
        self.assertEqual(first.json["candidate_count"], 16)
        self.assertNotIn("yield", str(first.json).lower())
        legacy = self.client.post("/api/wafer/optimize-shot", json={**VALID_PAYLOAD, "grid_steps": 4})
        self.assertEqual(legacy.status_code, 200)
        self.assertEqual(legacy.headers["Deprecation"], "true")
        self.assertEqual(legacy.json, first.json)

    def test_standards_exports_require_real_source_and_emit_no_fake_records(self) -> None:
        for route in ("/api/wafer/export/semi-g85", "/api/wafer/export/semi-e142"):
            response = self.client.post(route, json=VALID_PAYLOAD)
            self.assertEqual(response.status_code, 409)
            self.assertEqual(response.json["error"], "source_data_required")
            body = response.get_data(as_text=True).lower()
            self.assertNotIn("bin_definitions", body)
            self.assertNotIn("bindefinitions", body)
            self.assertNotIn("pass_good", body)
            self.assertNotIn("fail_", body)
            self.assertNotIn("defectrecords", body)

    def test_recent_sessions_returns_repository_metadata(self) -> None:
        response = self.client.get("/api/sessions/recent?limit=3")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json["persistence_available"])
        self.assertEqual(response.json["sessions"], [])

    def test_configuration_snapshot_separates_reticle_revision_data(self) -> None:
        snapshot = WaferRepository.configuration_snapshot(
            {**VALID_PAYLOAD, "persist": True, "view_mode": "shot_yield"}
        )
        self.assertNotIn("die_type_matrix", snapshot)
        self.assertNotIn("reticle_cols", snapshot)
        self.assertNotIn("reticle_rows", snapshot)
        self.assertNotIn("persist", snapshot)
        self.assertEqual(snapshot["diameter_mm"], 300)

    def test_json_lineage_comparison_detects_reticle_change(self) -> None:
        original = VALID_PAYLOAD["die_type_matrix"]
        changed = [["TEST_DIE", "DIE", "REFERENCE_DIE"], ["DIE", "TEST_DIE", "DIE"]]
        self.assertTrue(WaferRepository._matches_json(WaferRepository._json(original), original))
        self.assertFalse(WaferRepository._matches_json(WaferRepository._json(original), changed))

    def test_import_run_diagnostic_sanitizer_excludes_source_values_and_storage_references(self) -> None:
        safe = WaferRepository._safe_import_run_diagnostics({
            "operation": "PACKAGE_PARTITION_PERSIST",
            "selected_partition": {"lot_id": "LOT-1", "wafer_id": "WAFER-1"},
            "retained_roles": ["cp_die", "cp_test_limits"],
            "valid_rows": 12,
            "error_rows": 1,
            "diagnostics": [{"severity": "ERROR", "code": "CP_LIMITS_MISSING", "role": "cp_test_limits", "message": "TOP-SECRET raw row"}],
            "storage_key": "private-key",
            "storage_url": "https://private.example/object",
            "error": "TOP-SECRET source value",
        })
        self.assertEqual(safe["selected_partition"], {"lot_id": "LOT-1", "wafer_id": "WAFER-1"})
        self.assertEqual(safe["source_roles"], ["cp_die", "cp_test_limits"])
        self.assertEqual(safe["diagnostic_codes"], [{"severity": "ERROR", "code": "CP_LIMITS_MISSING", "role": "cp_test_limits"}])
        safe_text = str(safe).lower()
        for forbidden in ("top-secret", "private-key", "private.example", "storage_key", "storage_url"):
            self.assertNotIn(forbidden, safe_text)

    def test_cp_parser_normalizes_die_bins_and_summary(self) -> None:
        headers = RealDataPackageContractTestCase.CP_HEADER
        helper = RealDataPackageContractTestCase()
        parsed = parse_ingestion_file("CP", "cp.csv", helper.csv_bytes(headers, [helper.cp_row(soft_bin=2, pass_fail="P", die_x=0), helper.cp_row(soft_bin=31, pass_fail="F", die_x=1, x_mm=8.5)]))
        self.assertEqual(parsed["summary"]["valid_rows"], 2)
        self.assertEqual(parsed["summary"]["stats"]["pass_count"], 1)
        self.assertEqual(parsed["records"][1]["bin_quality"], "FAIL")

    def test_wat_and_kla_parser_supports_measurement_and_killer_contracts(self) -> None:
        helper = RealDataPackageContractTestCase()
        wat_row = ["LOT-W", "W300-W-01", "1", "C01", 0, 0, 0, 0, "W1000", "NMOS_VTH", "DEVICE_VT", "FEOL", "NMOS", "KEY", "V", 0.35, 0.35, 0.28, 0.42, "PASS"]
        kla_row = ["DEF-1", "LOT-K", "W300-K-01", 0, 0, 2000, 3000, 1.2, 10, "RETICLE_REPEATER_MASK_DEFECT", "Pattern", "Y", "KLA-1", "R1", "STEP", "M1", "S1"]
        wat = parse_ingestion_file("WAT", "wat.csv", helper.csv_bytes(helper.WAT_HEADER, [wat_row]))
        kla = parse_ingestion_file("KLA", "kla.csv", helper.csv_bytes(helper.KLA_HEADER, [kla_row]))
        self.assertEqual(wat["records"][0]["status"], "PASS")
        self.assertTrue(kla["records"][0]["killer_flag"])
        self.assertEqual(kla["summary"]["stats"]["killer_defect_count"], 1)

    def test_ingestion_upload_persists_normalized_data_and_source_file(self) -> None:
        helper = RealDataPackageContractTestCase()
        self.repository.users["owner-a"]["role"] = "admin"
        response = self.client.post(
            "/api/ingestion/upload",
            data={"source_type": "CP", "product_id": "UI-IGNORED", "owner_id": "2", "owner_open_id": "owner-b", "file": (BytesIO(helper.csv_bytes(helper.CP_HEADER, [helper.cp_row()])), "CP Wafer.csv")},
            content_type="multipart/form-data",
        )
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json["dataset"]["dataset_id"], 31)
        self.assertEqual(response.json["dataset"]["import_run_id"], 41)
        self.assertEqual(self.repository.ingestion["parsed"]["summary"]["wafer_id"], "LOT-1-01")
        self.assertEqual(self.repository.ingestion["parsed"]["summary"]["product_name"], "REAL-PRODUCT")
        self.assertEqual(self.storage.puts[0]["filename"], "CP Wafer.csv")
        self.assertEqual(self.repository.import_runs[0]["status"], "COMPLETED")
        self.assertEqual(self.repository.import_runs[0]["owner_id"], 1)
        self.assertEqual(self.repository.ingestion["owner_id"], 1)
        self.assertEqual(self.repository.users["owner-a"]["role"], "admin")
        self.assertNotIn("owner", str(response.json).lower())

    def test_ingestion_persistence_and_retained_source_reads_require_authentication(self) -> None:
        helper = RealDataPackageContractTestCase()
        unauthenticated = self._analysis_client(None)
        upload = unauthenticated.post(
            "/api/ingestion/upload",
            data={"source_type": "CP", "file": (BytesIO(helper.csv_bytes(helper.CP_HEADER, [helper.cp_row()])), "cp.csv")},
            content_type="multipart/form-data",
        )
        package = unauthenticated.post(
            "/api/ingestion/packages/persist",
            data={
                "source_type": "CP", "selected_lot_id": "LOT-1", "selected_wafer_id": "LOT-1-01",
                "owner_id": "999", "cp_die": (BytesIO(helper.csv_bytes(helper.CP_HEADER, [helper.cp_row()])), "cp.csv"),
            },
            content_type="multipart/form-data",
        )
        header_spoof = unauthenticated.post(
            "/api/ingestion/packages/persist",
            data={
                "source_type": "CP", "selected_lot_id": "LOT-1", "selected_wafer_id": "LOT-1-01",
                "cp_die": (BytesIO(helper.csv_bytes(helper.CP_HEADER, [helper.cp_row()])), "cp.csv"),
            },
            content_type="multipart/form-data",
            headers={"X-OpenId": "owner-a", "X-User-Name": "Test User"},
        )
        self.assertEqual(upload.status_code, 401)
        self.assertEqual(package.status_code, 401)
        self.assertEqual(header_spoof.status_code, 401)
        for path in ("/api/ingestion/recent", "/api/ingestion/catalog", "/api/ingestion/datasets/31/overlay", "/api/ingestion/datasets/31/analysis"):
            self.assertEqual(unauthenticated.get(path).status_code, 401)
        self.assertEqual(self.repository.import_runs, [])

    def test_ingestion_rejects_invalid_coordinates_and_returns_overlay_data(self) -> None:
        with self.assertRaises(IngestionValidationError):
            parse_ingestion_file("KLA", "bad.csv", b"Point_X_mm,Point_Y_mm,DefectID\n999,0,DEF-1\n")
        response = self.client.get("/api/ingestion/datasets/31/overlay")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json["dataset"]["source_type"], "CP")
        self.assertEqual(response.json["columns"][0], "die_x")
        self.assertEqual(self.client.get("/api/ingestion/recent?limit=2").json["datasets"][0]["id"], 31)

    def test_ingestion_analysis_returns_persisted_cp_metrics_and_validates_optional_dataset_ids(self) -> None:
        response = self.client.get("/api/ingestion/datasets/31/analysis?wat_dataset_id=32&kla_dataset_id=33")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json["cp"]["yield_pct"], 50.0)
        self.assertEqual(response.json["cp"]["bins"][0]["bin_code"], 3)
        self.assertEqual(response.json["cp"]["parametrics"][0]["param_name"], "VTH")
        self.assertEqual(response.json["cp"]["spatial"]["radial_zones"][0]["zone"], "Center 0–50 mm")
        self.assertEqual(response.json["ocap"]["status"], "REVIEW")
        invalid = self.client.get("/api/ingestion/datasets/31/analysis?wat_dataset_id=not-a-number")
        self.assertEqual(invalid.status_code, 400)
        self.assertEqual(invalid.json["error"], "validation_error")

    def test_ingestion_analysis_rejects_cross_wafer_source_combinations(self) -> None:
        response = self.client.get("/api/ingestion/datasets/31/analysis?wat_dataset_id=99")
        self.assertEqual(response.status_code, 400)
        self.assertIn("same lot", response.json["message"])

    def test_ingestion_catalog_applies_allowlisted_criteria(self) -> None:
        response = self.client.get("/api/ingestion/catalog?source_types=CP,WAT&lot_id=LOT-CP&wafer_id=W300-CP-01&product_id=CP-PRODUCT&limit=7")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json["persistence_available"])
        self.assertEqual(response.json["datasets"][0]["id"], 31)
        self.assertEqual(self.repository.catalog_request["source_types"], ["CP", "WAT"])
        self.assertEqual(self.repository.catalog_request["limit"], 7)
        invalid = self.client.get("/api/ingestion/catalog?source_types=CP,UNSUPPORTED")
        self.assertEqual(invalid.status_code, 400)

    def test_ingestion_rejects_an_excessively_invalid_source(self) -> None:
        invalid_rows = "\n".join(f"{300 + row},0,DEF-{row}" for row in range(101))
        with self.assertRaises(IngestionValidationError):
            parse_ingestion_file("KLA", "bad-many.csv", f"Point_X_mm,Point_Y_mm,DefectID\n0,0,GOOD\n{invalid_rows}\n".encode())

    def test_rejected_upload_is_retained_as_a_rejected_import_run(self) -> None:
        response = self.client.post(
            "/api/ingestion/upload",
            data={"source_type": "KLA", "file": (BytesIO(b"Point_X_mm,Point_Y_mm,DefectID\n999,0,DEF-1\n"), "bad-kla.csv")},
            content_type="multipart/form-data",
        )
        self.assertEqual(response.status_code, 400)
        self.assertEqual(self.repository.import_runs[0]["status"], "REJECTED")

    def test_import_history_is_authenticated_owner_scoped_and_exposes_only_safe_metadata(self) -> None:
        self.repository.import_runs.extend([
            {
                "id": 501,
                "owner_id": 1,
                "source_type": "CP",
                "filename": "cp_real_data.csv",
                "source_hash": "a" * 64,
                "status": "COMPLETED",
                "diagnostics": {
                    "operation": "PACKAGE_PARTITION_PERSIST",
                    "dataset_id": 31,
                    "selected_partition": {"lot_id": "LOT-CP", "wafer_id": "W300-CP-01"},
                    "retained_roles": ["cp_die", "cp_bin_definition"],
                    "valid_rows": 2,
                    "error_rows": 0,
                    "diagnostics": [{"severity": "WARNING", "code": "CP_LIMITS_MISSING", "role": "cp_test_limits", "message": "TOP-SECRET source row = 7"}],
                    "storage_key": "private/key",
                    "storage_url": "https://private.example/object",
                },
            },
            {
                "id": 502,
                "owner_id": 1,
                "source_type": "KLA",
                "filename": "kla_rejected.csv",
                "source_hash": "b" * 64,
                "status": "REJECTED",
                "diagnostics": {
                    "operation": "PACKAGE_PARTITION_PERSIST",
                    "selected_partition": {"lot_id": "LOT-CP", "wafer_id": "W300-CP-01"},
                    "error_type": "IngestionValidationError",
                    "error": "TOP-SECRET source row = 9",
                    "diagnostics": [{"severity": "ERROR", "code": "KLA_DUPLICATE_DEFECT", "role": "kla_defects", "message": "raw source value"}],
                },
            },
            {
                "id": 503,
                "owner_id": 2,
                "source_type": "WAT",
                "filename": "other_owner.csv",
                "source_hash": "c" * 64,
                "status": "COMPLETED",
                "diagnostics": {"dataset_id": 42},
            },
        ])

        unauthenticated = self._analysis_client(None)
        self.assertEqual(unauthenticated.get("/api/ingestion/import-runs").status_code, 401)

        response = self.client.get("/api/ingestion/import-runs?limit=999")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.repository.import_history_request, {"owner_open_id": "owner-a", "limit": 100})
        self.assertEqual([item["id"] for item in response.json["import_runs"]], [502, 501])
        completed = response.json["import_runs"][1]
        self.assertEqual(completed["dataset"]["id"], 31)
        self.assertEqual(completed["selected_partition"], {"lot_id": "LOT-CP", "wafer_id": "W300-CP-01"})
        self.assertEqual(completed["diagnostic_codes"], [{"severity": "WARNING", "code": "CP_LIMITS_MISSING", "role": "cp_test_limits"}])
        safe_response = str(response.json).lower()
        for forbidden in ("storage_key", "storage_url", "private.example", "top-secret", "raw source", "owner_id", "owner_open"):
            self.assertNotIn(forbidden, safe_response)

        other = self._analysis_client({"open_id": "owner-b", "app_id": "test-app", "name": "Other User"})
        other_response = other.get("/api/ingestion/import-runs?limit=5")
        self.assertEqual([item["id"] for item in other_response.json["import_runs"]], [503])
        self.assertEqual(self.client.get("/api/ingestion/import-runs?limit=not-a-number").status_code, 400)


class RealDataPackageContractTestCase(unittest.TestCase):
    CP_HEADER = [
        "LOT_ID", "WAFER_ID", "WAFER_NO", "PRODUCT_ID", "DIE_X", "DIE_Y",
        "DIE_CENTER_X_MM", "DIE_CENTER_Y_MM", "WAFER_SIZE_MM", "HARD_BIN", "SOFT_BIN",
        "BIN_NAME", "PASS_FAIL", "VTH_NMOS_V", "VTH_PMOS_V", "IDDQ_UA", "RON_OHM",
        "FMAX_MHZ", "VDD_MIN_V", "CONT_RES_OHM", "ICC_ACTIVE_MA",
    ]
    WAT_HEADER = [
        "LOT_ID", "WAFER_ID", "SITE_ID", "SITE_NAME", "SITE_X_MM", "SITE_Y_MM", "DIE_X", "DIE_Y",
        "PARAM_ID", "PARAM_NAME", "PARAM_GROUP", "MODULE", "TEST_STRUCTURE", "CRITICALITY", "UNIT",
        "VALUE", "TARGET", "SPEC_LOW", "SPEC_HIGH", "OOS_FLAG",
    ]
    KLA_HEADER = [
        "DEFECT_ID", "LOT_ID", "WAFER_ID", "DIE_X", "DIE_Y", "XREL_UM", "YREL_UM",
        "DEFECT_SIZE_UM", "CLASS_CODE", "CLASS_NAME", "CLASS_GROUP", "KILLER_FLAG", "INSPECTION_TOOL",
        "INSPECTION_RECIPE", "INSPECTION_STEP", "LAYER", "RETICLE_SHOT_ID",
    ]

    @staticmethod
    def csv_bytes(headers, rows):
        import csv
        import io
        stream = io.StringIO(newline="")
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(headers)
        writer.writerows(rows)
        return stream.getvalue().encode("utf-8")

    def cp_row(self, wafer="LOT-1-01", product="REAL-PRODUCT", soft_bin=2, pass_fail="P", die_x=1, x_mm=0.0):
        return ["LOT-1", wafer, "1", product, die_x, 2, x_mm, 0, 300, 1 if pass_fail == "P" else 2, soft_bin,
                "PASS_FAST_BIN" if pass_fail == "P" else "FAIL_PARAM", pass_fail,
                0.41, -0.40, 3.0, 150, 1200, 0.78, 0.9, 45]

    def test_cp_real_contract_partitions_and_pass_fail_are_authoritative(self):
        from flask_backend.ingestion import validate_ingestion_package
        cp = self.csv_bytes(self.CP_HEADER, [self.cp_row(), self.cp_row(wafer="LOT-1-02", soft_bin=3, die_x=2, x_mm=8)])
        result = validate_ingestion_package("CP", {"cp_die": cp})
        self.assertTrue(result["valid"])
        self.assertEqual(result["partition_count"], 2)
        self.assertEqual(result["persistence"]["mode"], "SELECTED_PARTITION_REQUIRED")
        self.assertEqual([part["pass_count"] for part in result["partitions"]], [1, 1])

    def test_package_endpoint_previews_all_wafer_partitions_without_persistence(self):
        app = create_app({"TESTING": True, "WAFER_REPOSITORY": None, "INGESTION_STORAGE": None})
        cp = self.csv_bytes(self.CP_HEADER, [self.cp_row(), self.cp_row(wafer="LOT-1-02", die_x=2, x_mm=8)])
        response = app.test_client().post(
            "/api/ingestion/packages/validate",
            data={"source_type": "CP", "cp_die": (BytesIO(cp), "cp_die.csv")},
            content_type="multipart/form-data",
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json["partition_count"], 2)
        self.assertFalse(response.json["persistence"]["safe"])

    def _staged_session(self, client, cp: bytes):
        created = client.post("/api/ingestion/package-sessions", json={
            "source_type": "CP",
            "files": [{"role": "cp_die", "filename": "cp_die.csv", "byte_size": len(cp)}],
        })
        self.assertEqual(created.status_code, 201)
        session = created.json
        headers = {"X-WaferMap-Upload-Token": session["upload_token"]}
        chunk = client.post(
            f"/api/ingestion/package-sessions/{session['session_id']}/chunks",
            data={
                "role": "cp_die",
                "chunk_index": "0",
                "total_chunks": "1",
                "chunk": (BytesIO(cp), "cp_die.csv"),
            },
            headers=headers,
            content_type="multipart/form-data",
        )
        self.assertEqual(chunk.status_code, 200)
        self.assertTrue(chunk.json["files"][0]["complete"])
        return session, headers

    def test_staged_package_validation_handles_chunked_real_contract_and_token_errors(self):
        import tempfile
        with tempfile.TemporaryDirectory() as staging_directory:
            app = create_app({
                "TESTING": True,
                "WAFER_REPOSITORY": None,
                "INGESTION_STORAGE": None,
                "PACKAGE_UPLOAD_STAGING_DIR": staging_directory,
                "PACKAGE_UPLOAD_CHUNK_BYTES": 64 * 1024,
            })
            client = app.test_client()
            cp = self.csv_bytes(self.CP_HEADER, [self.cp_row(), self.cp_row(wafer="LOT-1-02", die_x=2, x_mm=8)])
            session, headers = self._staged_session(client, cp)
            unauthorized = client.post(f"/api/ingestion/package-sessions/{session['session_id']}/validate")
            self.assertEqual(unauthorized.status_code, 400)
            response = client.post(f"/api/ingestion/package-sessions/{session['session_id']}/validate", headers=headers)
            self.assertEqual(response.status_code, 200)
            self.assertTrue(response.json["valid"])
            self.assertEqual(response.json["partition_count"], 2)
            abandoned = client.delete(f"/api/ingestion/package-sessions/{session['session_id']}", headers=headers)
            self.assertEqual(abandoned.status_code, 204)
            self.assertEqual(list(__import__("pathlib").Path(staging_directory).iterdir()), [])

    def test_staged_package_persistence_revalidates_then_consumes_private_chunks(self):
        import tempfile
        with tempfile.TemporaryDirectory() as staging_directory:
            repository = FakeRepository()
            storage = FakeStorage()
            app = create_app({
                "TESTING": True,
                "WAFER_REPOSITORY": repository,
                "INGESTION_STORAGE": storage,
                "ANALYSIS_TEST_IDENTITY": {"open_id": "owner-a", "app_id": "test-app", "name": "Test User"},
                "PACKAGE_UPLOAD_STAGING_DIR": staging_directory,
                "PACKAGE_UPLOAD_CHUNK_BYTES": 64 * 1024,
            })
            client = app.test_client()
            cp = self.csv_bytes(self.CP_HEADER, [self.cp_row(product="SOURCE-PRODUCT"), self.cp_row(wafer="LOT-1-02", die_x=2, x_mm=8)])
            session, headers = self._staged_session(client, cp)
            persisted = client.post(
                f"/api/ingestion/package-sessions/{session['session_id']}/persist",
                headers={**headers, "Content-Type": "application/json"},
                json={"selected_lot_id": "LOT-1", "selected_wafer_id": "LOT-1-01"},
            )
            self.assertEqual(persisted.status_code, 201)
            self.assertEqual(persisted.json["status"], "COMPLETED")
            self.assertEqual(repository.ingestion["parsed"]["summary"]["product_name"], "SOURCE-PRODUCT")
            self.assertEqual(len(storage.puts), 1)
            self.assertEqual(repository.import_runs[-1]["status"], "COMPLETED")
            missing = client.get(f"/api/ingestion/package-sessions/{session['session_id']}", headers=headers)
            self.assertEqual(missing.status_code, 400)
            self.assertEqual(list(__import__("pathlib").Path(staging_directory).iterdir()), [])

    def _persist_client(self):
        repository = FakeRepository()
        storage = FakeStorage()
        identity = {"open_id": "owner-a", "app_id": "test-app", "name": "Test User"}
        app = create_app({"TESTING": True, "WAFER_REPOSITORY": repository, "INGESTION_STORAGE": storage, "ANALYSIS_TEST_IDENTITY": identity})
        return app.test_client(), repository, storage

    def test_cp_package_persists_only_selected_partition_and_source_product(self):
        client, repository, storage = self._persist_client()
        cp = self.csv_bytes(self.CP_HEADER, [
            self.cp_row(wafer="LOT-1-01", product="SOURCE-PRODUCT", die_x=1),
            self.cp_row(wafer="LOT-1-02", product="OTHER-PRODUCT", die_x=2, x_mm=8),
        ])
        response = client.post(
            "/api/ingestion/packages/persist",
            data={
                "source_type": "CP", "selected_lot_id": "LOT-1", "selected_wafer_id": "LOT-1-01",
                "product_id": "UI-MUST-NOT-WIN", "owner_id": "2", "owner_open_id": "owner-b",
                "cp_die": (BytesIO(cp), "cp_die.csv"),
            },
            content_type="multipart/form-data",
        )
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json["status"], "COMPLETED")
        self.assertTrue(response.json["persistent"])
        self.assertFalse(response.json["correlation_ready"])
        self.assertNotIn("storage_url", response.json["dataset"])
        parsed = repository.ingestion["parsed"]
        self.assertEqual(parsed["summary"]["product_name"], "SOURCE-PRODUCT")
        self.assertEqual(parsed["summary"]["source_package_partition_count"], 2)
        self.assertEqual({(item["lot_id"], item["wafer_id"]) for item in parsed["records"]}, {("LOT-1", "LOT-1-01")})
        self.assertEqual({(item["lot_id"], item["wafer_id"]) for item in parsed["parametric_records"]}, {("LOT-1", "LOT-1-01")})
        self.assertEqual([item["role"] for item in parsed["summary"]["package_diagnostics"]["role_manifest"]], ["cp_die"])
        self.assertEqual(len(storage.puts), 1)
        self.assertEqual(repository.import_runs[-1]["status"], "COMPLETED")
        self.assertEqual(repository.import_runs[-1]["owner_id"], 1)
        self.assertEqual(repository.ingestion["owner_id"], 1)
        self.assertNotIn("owner", str(response.json).lower())

    def test_wat_and_kla_package_persist_selected_source_records(self):
        wat_client, wat_repository, _ = self._persist_client()
        wat_rows = [
            ["LOT-1", "LOT-1-01", "1", "C01", 0, 0, 0, 0, "W1000", "NMOS_VTH", "DEVICE_VT", "FEOL", "NMOS", "KEY", "V", 0.35, 0.35, 0.28, 0.42, "PASS"],
            ["LOT-1", "LOT-1-02", "1", "C01", 1, 1, 1, 1, "W1000", "NMOS_VTH", "DEVICE_VT", "FEOL", "NMOS", "KEY", "V", 0.50, 0.35, 0.28, 0.42, "OOS"],
        ]
        wat_response = wat_client.post(
            "/api/ingestion/packages/persist",
            data={
                "source_type": "WAT", "selected_lot_id": "LOT-1", "selected_wafer_id": "LOT-1-02",
                "wat_long": (BytesIO(self.csv_bytes(self.WAT_HEADER, wat_rows)), "wat_long.csv"),
            },
            content_type="multipart/form-data",
        )
        self.assertEqual(wat_response.status_code, 201)
        self.assertEqual(wat_repository.ingestion["parsed"]["summary"]["product_name"], "UNAVAILABLE")
        self.assertEqual(wat_repository.ingestion["parsed"]["summary"]["product_provenance"], "UNAVAILABLE")
        self.assertEqual([(item["wafer_id"], item["status"]) for item in wat_repository.ingestion["parsed"]["records"]], [("LOT-1-02", "FAIL")])

        kla_client, kla_repository, _ = self._persist_client()
        kla_rows = [
            ["D-1", "LOT-1", "LOT-1-01", 0, 0, 1000, 2000, 0.8, 10, "PARTICLE", "Particle", "N", "KLA-1", "R1", "STEP", "M1", "S01"],
            ["D-2", "LOT-1", "LOT-1-02", 1, 1, 2000, 3000, 1.2, 20, "SCRATCH", "Pattern", "Y", "KLA-1", "R1", "STEP", "M2", "S02"],
        ]
        kla_response = kla_client.post(
            "/api/ingestion/packages/persist",
            data={
                "source_type": "KLA", "selected_lot_id": "LOT-1", "selected_wafer_id": "LOT-1-02",
                "kla_defects": (BytesIO(self.csv_bytes(self.KLA_HEADER, kla_rows)), "kla_defects.csv"),
            },
            content_type="multipart/form-data",
        )
        self.assertEqual(kla_response.status_code, 201)
        self.assertEqual(kla_repository.ingestion["parsed"]["summary"]["product_provenance"], "UNAVAILABLE")
        self.assertEqual([(item["wafer_id"], item["defect_id"]) for item in kla_repository.ingestion["parsed"]["records"]], [("LOT-1-02", "D-2")])

    def test_package_persistence_rejects_missing_and_cross_role_partitions(self):
        client, repository, storage = self._persist_client()
        cp = self.csv_bytes(self.CP_HEADER, [self.cp_row()])
        missing = client.post(
            "/api/ingestion/packages/persist",
            data={"source_type": "CP", "selected_lot_id": "LOT-1", "selected_wafer_id": "ABSENT", "cp_die": (BytesIO(cp), "cp.csv")},
            content_type="multipart/form-data",
        )
        self.assertEqual(missing.status_code, 400)
        self.assertEqual(repository.import_runs[-1]["status"], "REJECTED")
        self.assertEqual(storage.puts, [])

        cross_source = client.post(
            "/api/ingestion/packages/persist",
            data={
                "source_type": "CP", "selected_lot_id": "LOT-1", "selected_wafer_id": "LOT-1-01",
                "wat_long": (BytesIO(self.csv_bytes(self.WAT_HEADER, [["LOT-1", "LOT-1-01", "1", "C01", 0, 0, 0, 0, "W1000", "NMOS_VTH", "DEVICE_VT", "FEOL", "NMOS", "KEY", "V", 0.35, 0.35, 0.28, 0.42, "PASS"]])), "wat.csv"),
            },
            content_type="multipart/form-data",
        )
        self.assertEqual(cross_source.status_code, 400)
        self.assertIn("Unsupported CP file roles", cross_source.json["message"])
        self.assertEqual(repository.import_runs[-1]["status"], "REJECTED")
        self.assertEqual(storage.puts, [])

        summary = self.csv_bytes(["LOT_ID", "WAFER_ID", "GROSS_DIE", "PASS_DIE", "YIELD_PCT"], [["LOT-1", "OTHER", 1, 1, 100]])
        mismatch = client.post(
            "/api/ingestion/packages/persist",
            data={
                "source_type": "CP", "selected_lot_id": "LOT-1", "selected_wafer_id": "LOT-1-01",
                "cp_die": (BytesIO(cp), "cp.csv"), "cp_summary": (BytesIO(summary), "summary.csv"),
            },
            content_type="multipart/form-data",
        )
        self.assertEqual(mismatch.status_code, 400)
        self.assertIn("CP_SUMMARY_IDENTITY_MISMATCH", {item["code"] for item in mismatch.json["diagnostics"]})
        self.assertEqual(repository.import_runs[-1]["status"], "REJECTED")
        self.assertEqual(storage.puts, [])

        unspecified = client.post(
            "/api/ingestion/packages/persist",
            data={"source_type": "CP", "selected_lot_id": "LOT-1", "cp_die": (BytesIO(cp), "cp.csv")},
            content_type="multipart/form-data",
        )
        self.assertEqual(unspecified.status_code, 400)

    def test_cp_duplicate_die_and_source_product_override_protection(self):
        from flask_backend.ingestion import validate_ingestion_package
        cp = self.csv_bytes(self.CP_HEADER, [self.cp_row(), self.cp_row()])
        result = validate_ingestion_package("CP", {"cp_die": cp})
        self.assertFalse(result["valid"])
        self.assertIn("CP_DUPLICATE_DIE_KEY", {item["code"] for item in result["diagnostics"]["items"]})
        self.assertEqual(result["partitions"][0]["product_id"], "REAL-PRODUCT")

    def test_package_endpoint_rejects_malformed_roles_and_enforces_request_file_limits(self):
        app = create_app({"TESTING": True, "WAFER_REPOSITORY": FakeRepository(), "INGESTION_STORAGE": FakeStorage(), "INGESTION_MAX_FILE_BYTES": 32})
        client = app.test_client()
        malformed = client.post("/api/ingestion/packages/validate", data={"source_type": "CP", "wrong_role": (BytesIO(b"a,b\n1,2\n"), "x.csv")}, content_type="multipart/form-data")
        self.assertEqual(malformed.status_code, 400)
        oversized = client.post("/api/ingestion/packages/validate", data={"source_type": "CP", "cp_die": (BytesIO(b"x" * 33), "cp.csv")}, content_type="multipart/form-data")
        self.assertEqual(oversized.status_code, 400)
        self.assertIn("byte limit", oversized.json["message"])

    def test_row_limit_is_stream_enforced(self):
        from flask_backend.ingestion import IngestionValidationError, validate_ingestion_package
        cp = self.csv_bytes(self.CP_HEADER, [self.cp_row(die_x=1), self.cp_row(die_x=2)])
        with self.assertRaises(IngestionValidationError) as raised:
            validate_ingestion_package("CP", {"cp_die": cp}, max_rows=1)
        self.assertIn("row limit", str(raised.exception))

    def test_wat_real_aliases_and_oos_semantics(self):
        from flask_backend.ingestion import validate_ingestion_package
        row = ["LOT-1", "LOT-1-01", "1", "C01", 1.5, -2.5, 18, 17, "W1000", "VTLIN_NMOS", "DEVICE_VT", "FEOL", "NMOS", "KEY", "V", 0.5, 0.4, 0.3, 0.45, "OOS"]
        result = validate_ingestion_package("WAT", {"wat_long": self.csv_bytes(self.WAT_HEADER, [row])})
        self.assertTrue(result["valid"])
        part = result["partitions"][0]
        self.assertEqual(part["coordinate_frames"], ["SITE_XY_MM"])
        self.assertEqual(part["oos_count"], 1)
        self.assertEqual(part["product_provenance"], "UNAVAILABLE")

    def test_wat_wide_requires_specs(self):
        from flask_backend.ingestion import IngestionValidationError, validate_ingestion_package
        wide = self.csv_bytes(["LOT_ID", "WAFER_ID", "SITE_ID", "SITE_NAME", "SITE_X_MM", "SITE_Y_MM", "DIE_X", "DIE_Y", "VTLIN_NMOS"], [["LOT-1", "LOT-1-01", 1, "C", 0, 0, 1, 1, 0.4]])
        with self.assertRaises(IngestionValidationError) as raised:
            validate_ingestion_package("WAT", {"wat_wide": wide})
        self.assertIn("requires file role 'wat_specs'", str(raised.exception))

    def test_kla_um_conversion_and_event_killer_truth(self):
        from flask_backend.ingestion import validate_ingestion_package
        classes = self.csv_bytes(["CLASS_CODE", "CLASS_NAME", "CLASS_GROUP", "POLARITY", "KILLER_DEFAULT"], [[10, "PARTICLE", "Particle", "BRIGHT", "False"]])
        defect = self.csv_bytes(self.KLA_HEADER, [["D-1", "LOT-1", "LOT-1-01", 2, 3, 1250, -2500, 0.8, 10, "PARTICLE", "Particle", "Y", "KLA-1", "R1", "STEP", "M1", "S01"]])
        result = validate_ingestion_package("KLA", {"kla_defects": defect, "kla_classes": classes}, collect_records=True)
        self.assertTrue(result["valid"])
        self.assertEqual(result["records"][0]["x_mm"], 1.25)
        self.assertEqual(result["records"][0]["y_mm"], -2.5)
        self.assertTrue(result["records"][0]["killer_flag"])
        self.assertEqual(result["partitions"][0]["killer_default_disagreements"], 1)

    def test_kla_class_definition_mismatch_and_missing_primary_are_rejected(self):
        from flask_backend.ingestion import IngestionValidationError, validate_ingestion_package
        classes = self.csv_bytes(["CLASS_CODE", "CLASS_NAME", "CLASS_GROUP", "POLARITY", "KILLER_DEFAULT"], [[10, "EXPECTED", "Particle", "BRIGHT", "False"]])
        defect = self.csv_bytes(self.KLA_HEADER, [["D-1", "LOT-1", "LOT-1-01", 2, 3, 1000, 2000, 0.8, 10, "DIFFERENT", "Particle", "N", "KLA-1", "R1", "STEP", "M1", "S01"]])
        result = validate_ingestion_package("KLA", {"kla_defects": defect, "kla_classes": classes})
        self.assertFalse(result["valid"])
        self.assertIn("INVALID_ROW", {item["code"] for item in result["diagnostics"]["items"]})
        with self.assertRaises(IngestionValidationError) as raised:
            validate_ingestion_package("CP", {"cp_bins": self.csv_bytes(["SOFT_BIN", "BIN_NAME", "HARD_BIN", "PASS_FAIL", "BIN_CATEGORY"], [[1, "PASS", 1, "P", "GOOD"]])})
        self.assertIn("requires cp_die", str(raised.exception))

    def test_companion_identity_mismatch_is_reconciled(self):
        from flask_backend.ingestion import validate_ingestion_package
        cp = self.csv_bytes(self.CP_HEADER, [self.cp_row()])
        summary = self.csv_bytes(["LOT_ID", "WAFER_ID", "GROSS_DIE", "PASS_DIE", "YIELD_PCT"], [["LOT-1", "OTHER", 1, 1, 100]])
        result = validate_ingestion_package("CP", {"cp_die": cp, "cp_summary": summary})
        self.assertFalse(result["valid"])
        self.assertIn("CP_SUMMARY_IDENTITY_MISMATCH", {item["code"] for item in result["diagnostics"]["items"]})

    def test_source_product_cannot_be_overwritten_by_ui_form_value(self):
        repository = FakeRepository()
        storage = FakeStorage()
        app = create_app({
            "TESTING": True,
            "WAFER_REPOSITORY": repository,
            "INGESTION_STORAGE": storage,
            "ANALYSIS_TEST_IDENTITY": {"open_id": "owner-a", "app_id": "test-app", "name": "Test User"},
        })
        response = app.test_client().post(
            "/api/ingestion/upload",
            data={"source_type": "CP", "product_id": "UI-OVERRIDE", "file": (BytesIO(self.csv_bytes(self.CP_HEADER, [self.cp_row()])), "cp.csv")},
            content_type="multipart/form-data",
        )
        self.assertEqual(response.status_code, 201)
        self.assertEqual(repository.ingestion["parsed"]["summary"]["product_name"], "REAL-PRODUCT")

    def test_identity_matcher_denies_lot_or_wafer_mismatch_but_not_unavailable_product(self):
        matched, _ = WaferRepository._matching_dataset_identity(
            {"lotId": "L", "waferId": "W", "productId": "P"},
            {"lotId": "L", "waferId": "W", "productId": "UNAVAILABLE"},
        )
        mismatch, message = WaferRepository._matching_dataset_identity(
            {"lotId": "L", "waferId": "W", "productId": "P"},
            {"lotId": "OTHER", "waferId": "W", "productId": "UNAVAILABLE"},
        )
        self.assertTrue(matched)
        self.assertFalse(mismatch)
        self.assertIn("lot", message)

    def test_coordinate_screening_deduplicates_source_events_and_never_returns_rows(self):
        cp_results = WaferRepository._cp_coordinate_results([
            {"die_x": 0, "die_y": 0, "bin_quality": "PASS"},
            {"die_x": 1, "die_y": 0, "bin_quality": "FAIL"},
            {"die_x": 2, "die_y": 0, "bin_quality": "FAIL"},
        ])
        kla = WaferRepository._kla_coordinate_screening(cp_results, [
            {"defect_class": "PARTICLE", "die_x": 1, "die_y": 0, "is_repeater": True},
            {"defect_class": "PARTICLE", "die_x": 1, "die_y": 0, "is_repeater": False},
            {"defect_class": "PARTICLE", "die_x": 0, "die_y": 0, "is_repeater": False},
            {"defect_class": "SCRATCH", "die_x": 2, "die_y": 0, "is_repeater": True},
            {"defect_class": "SCRATCH", "die_x": 9, "die_y": 9, "is_repeater": False},
        ])
        self.assertEqual(
            kla["rows"],
            [
                {"defect_class": "PARTICLE", "total_defects": 3, "distinct_affected_dies": 2, "affected_dies": 2, "matched_cp_dies": 2, "unmatched_affected_dies": 0, "killed_dies": 1, "kill_ratio_pct": 50.0, "repeater_defects": 1},
                {"defect_class": "SCRATCH", "total_defects": 2, "distinct_affected_dies": 2, "affected_dies": 2, "matched_cp_dies": 1, "unmatched_affected_dies": 1, "killed_dies": 1, "kill_ratio_pct": 50.0, "repeater_defects": 1},
            ],
        )

        wat = WaferRepository._wat_coordinate_screening(cp_results, [
            {"param_name": "VTH", "unit": "V", "die_x": 1, "die_y": 0, "value": 0.40, "status": "PASS", "source_status": "PASS"},
            {"param_name": "VTH", "unit": "V", "die_x": 1, "die_y": 0, "value": 0.44, "status": "FAIL", "source_status": "OOS"},
            {"param_name": "VTH", "unit": "V", "die_x": 0, "die_y": 0, "value": 0.36, "status": "PASS", "source_status": "PASS"},
            {"param_name": "VTH", "unit": "V", "die_x": 9, "die_y": 9, "value": 0.50, "status": "FAIL", "source_status": "OOS"},
        ])
        item = wat["rows"][0]
        self.assertEqual(item["measurement_count"], 4)
        self.assertEqual(item["source_die_count"], 3)
        self.assertEqual(item["matched_die_count"], 2)
        self.assertEqual(item["unmatched_die_count"], 1)
        self.assertEqual(item["cp_fail_die_count"], 1)
        self.assertEqual(item["cp_pass_die_count"], 1)
        self.assertEqual(item["cp_failure_rate_pct"], 50.0)
        self.assertEqual(item["coordinate_coverage_pct"], 66.67)
        self.assertEqual(item["oos_measurement_count"], 2)
        self.assertAlmostEqual(item["mean_wat_value"], 0.425)
        self.assertNotIn("value", item)
        self.assertNotIn("die_x", item)
        self.assertNotIn("die_y", item)

    def test_coordinate_screening_readiness_uses_overlap_despite_unavailable_product(self):
        unavailable = {"productId": "UNAVAILABLE", "productProvenance": "UNAVAILABLE"}
        ready, reasons, caveats = WaferRepository._correlation_status(unavailable, 1, None, 0)
        self.assertTrue(ready)
        self.assertIn("direct DIE_X/DIE_Y overlap", reasons[0])
        self.assertTrue(any("PRODUCT_ID is unavailable" in caveat for caveat in caveats))
        self.assertTrue(any("no physical coordinate-frame transform has been verified" in caveat for caveat in caveats))

        not_ready, zero_reasons, zero_caveats = WaferRepository._correlation_status(unavailable, 0, None, 0)
        self.assertFalse(not_ready)
        self.assertIn("zero direct DIE_X/DIE_Y overlap", zero_reasons[0])
        self.assertTrue(zero_caveats)


if __name__ == "__main__":
    unittest.main(verbosity=2)
