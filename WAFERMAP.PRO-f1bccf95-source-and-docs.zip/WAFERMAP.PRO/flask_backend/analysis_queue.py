"""Request-driven, DB-persisted execution for source-backed analysis jobs.

This module intentionally starts no worker, thread, timer, or detached process. A caller
may invoke ``execute_at_most_one`` once per HTTP request; the repository's atomic global
claim guarantees that no more than one analysis is RUNNING at a time.
"""

from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from typing import Any

try:
    from .repository import PersistenceUnavailable
    from .storage import StorageUnavailable
except ImportError:  # Supports local imports from flask_backend.
    from repository import PersistenceUnavailable
    from storage import StorageUnavailable

REPORT_SCHEMA_VERSION = "wafermap-pro.analysis-report.v1"
REQUEST_MANIFEST_VERSION = "wafermap-pro.analysis-request.v1"
DEFAULT_REPORT_MAX_BYTES = 4 * 1024 * 1024
MAX_SAFE_ERROR_LENGTH = 512


class AnalysisReportLimitError(RuntimeError):
    """A governed report would exceed the configured persisted JSON size bound."""


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _isoformat_utc(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
    return str(value)


def _safe_filename_component(value: str) -> str:
    component = re.sub(r"[^A-Za-z0-9._-]+", "_", value.strip()).strip("._-")
    return (component or "user")[:64]


def _safe_error(error: Exception) -> str:
    """Return a bounded operational message that cannot echo source rows or URLs."""
    if isinstance(error, AnalysisReportLimitError):
        message = str(error)
    elif isinstance(error, StorageUnavailable):
        message = "Managed report storage failed; no completed report was published."
    elif isinstance(error, PersistenceUnavailable):
        message = "Analysis report persistence failed."
    elif isinstance(error, ValueError):
        message = "Persisted source validation failed during analysis execution."
    else:
        message = f"Analysis execution failed safely ({error.__class__.__name__})."
    return re.sub(r"[\x00-\x1f\x7f]+", " ", message).strip()[:MAX_SAFE_ERROR_LENGTH]


def build_request_manifest(
    cp_dataset_id: int,
    wat_dataset_id: int | None,
    kla_dataset_id: int | None,
    source_references: list[dict[str, Any]],
) -> dict[str, Any]:
    return {
        "version": REQUEST_MANIFEST_VERSION,
        "dataset_ids": {
            "cp": cp_dataset_id,
            "wat": wat_dataset_id,
            "kla": kla_dataset_id,
        },
        "sources": source_references,
        "source_policy": "PERSISTED_NORMALIZED_MEASUREMENTS_ONLY",
    }


class AnalysisQueueExecutor:
    """Synchronously claim and execute zero or one globally queued job."""

    def __init__(self, repository: Any, storage: Any, *, report_max_bytes: int = DEFAULT_REPORT_MAX_BYTES, running_stale_seconds: int = 1800):
        self.repository = repository
        self.storage = storage
        self.report_max_bytes = int(report_max_bytes)
        self.running_stale_seconds = int(running_stale_seconds)

    def execute_at_most_one(self) -> dict[str, Any] | None:
        job = self.repository.claim_next_analysis_job(stale_after_seconds=self.running_stale_seconds)
        if job is None:
            return None
        job_id = int(job["id"])
        owner_open_id = str(job["owner_open_id"])
        try:
            if self.storage is None:
                raise StorageUnavailable("Managed report storage is not configured.")
            aggregate = self.repository.ingestion_analysis(
                int(job["cp_dataset_id"]),
                wat_dataset_id=job.get("wat_dataset_id"),
                kla_dataset_id=job.get("kla_dataset_id"),
            )
            generated_at = _utc_now()
            stamp = generated_at.strftime("%Y%m%dT%H%M%SZ")
            filename = f"{_safe_filename_component(str(job['owner_name']))}_{stamp}_WAFERMAP_PRO_analysis_{job_id}.json"
            manifest = job.get("request_manifest") or {}
            payload = {
                "schema_version": REPORT_SCHEMA_VERSION,
                "generated_at": generated_at.isoformat(timespec="seconds").replace("+00:00", "Z"),
                "filename": filename,
                "job": {
                    "id": job_id,
                    "queue_sequence": int(job["queue_sequence"]),
                    "request_version": job["request_version"],
                    "submitted_at": _isoformat_utc(job.get("submitted_at")),
                    "started_at": _isoformat_utc(job.get("started_at")),
                    "attempt": int(job.get("attempts") or 1),
                },
                "identity": {
                    "owner_open_id": owner_open_id,
                    "owner_name": job["owner_name"],
                },
                "sources": {
                    "source_backed": True,
                    "measurement_policy": "Only persisted normalized CP/WAT/KLA measurement rows were aggregated; no synthetic or dummy observations are permitted.",
                    "datasets": manifest.get("sources", []),
                },
                "governance": {
                    "execution_mode": "REQUEST_DRIVEN_SINGLE_GLOBAL_CLAIM",
                    "resource_limits": {
                        "max_report_bytes": self.report_max_bytes,
                        "jobs_claimed_by_this_request": 1,
                    },
                    "analysis_scope": "Decision-support aggregates only. The report does not expose retained source rows or infer unavailable manufacturing facts.",
                    "correlation": {
                        "ready": bool(aggregate.get("correlation_ready", False)),
                        "reasons": list(aggregate.get("correlation_reasons") or []),
                        "reasoning_boundary": "LOT_ID/WAFER_ID equality permits identity compatibility checks but does not prove product provenance, coordinate-frame alignment, causality, or scientific correlation.",
                    },
                },
                "aggregate_result": aggregate,
            }
            content = json.dumps(
                payload,
                ensure_ascii=False,
                separators=(",", ":"),
                sort_keys=True,
                allow_nan=False,
            ).encode("utf-8")
            if len(content) > self.report_max_bytes:
                raise AnalysisReportLimitError(
                    f"Generated report exceeds the configured {self.report_max_bytes:,}-byte limit."
                )
            stored = self.storage.put(filename, content, "application/json")
            storage_key = str(stored.get("key", ""))
            storage_url = str(stored.get("url", ""))
            if not storage_key or not storage_url:
                raise StorageUnavailable("Managed report storage returned an incomplete reference.")
            self.repository.complete_analysis_job(
                job_id,
                owner_open_id,
                filename=filename,
                storage_key=storage_key,
                storage_url=storage_url,
                payload_hash=hashlib.sha256(content).hexdigest(),
                byte_size=len(content),
                payload=payload,
            )
        except Exception as error:
            self.repository.fail_analysis_job(job_id, owner_open_id, _safe_error(error))
        return self.repository.analysis_job_for_owner(job_id, owner_open_id)
