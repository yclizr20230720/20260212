# Analysis queue operations

## Deployment constraint and execution model

WAFERMAP.PRO runs Flask directly in a **1 vCPU / 512 MiB request-scoped deployment**. This implementation therefore does not start an in-container worker and does not use threads, `setInterval`, Celery, Redis, detached processes, or a permanently running process.

`analysis_jobs` is the durable queue. Every `POST /api/analysis/jobs` persists a job before execution is attempted. That request then asks the repository to atomically claim **at most one** globally oldest `QUEUED` job. `GET /api/analysis/jobs` and `GET /api/analysis/jobs/<id>` may do the same once before returning. There is no server-side polling loop. The claimed job executes synchronously inside that triggering HTTP request.

A MySQL advisory lock serializes enqueue cap checks and claims across Flask processes. Claiming also checks for an existing `RUNNING` row. Consequently, the service has strict global one-at-a-time analysis execution while allowing concurrent users to enqueue. Queue order is the monotonic `queueSequence`, then job id. A request that submits job B may fairly execute an older job A; B remains durable and queued.

A `RUNNING` row older than `ANALYSIS_RUNNING_STALE_SECONDS` (default 1,800 seconds) is marked `FAILED` before another claim. This recovers a request killed by the hosting timeout or process loss. The threshold must remain above the platform request timeout/expected analysis duration to avoid overlap. There is no automatic retry in this deployment; submit a new job after reviewing a failure.

## Authentication and owner scope

All `/api/analysis/jobs*` and `/api/analysis/reports*` routes require the existing `app_session_id` cookie. Flask verifies the Node-issued HS256 JWT with the standard library and `JWT_SECRET`; accepted payload fields are non-empty `openId`, `appId`, `name`, and an unexpired numeric `exp`. Missing cookies return 401. Missing secrets, malformed/expired tokens, wrong algorithms, and invalid signatures return 403.

There is no trusted identity request header. Tests can provide `ANALYSIS_TEST_IDENTITY` or `ANALYSIS_TEST_IDENTITY_PROVIDER` only while Flask `TESTING` is true; configuring either in production is rejected.

Jobs and reports store `ownerOpenId` directly and every single/list/update lookup is scoped by it. Retained ingestion data instead uses the existing `users.id` foreign key: Flask maps the same verified OpenId through `users.openId`, creating a stable default-role `user` row when necessary and never changing an existing role. An authenticated caller receives 404, not existence disclosure, for another owner's job, report, or retained dataset.

## Submission and source boundary

`POST /api/analysis/jobs` accepts:

```json
{
  "cp_dataset_id": 31,
  "wat_dataset_id": 32,
  "kla_dataset_id": 33
}
```

CP is required; WAT/KLA are optional. IDs must be positive integers. Before enqueue, the repository verifies that each id belongs to the authenticated OpenId through `ingestion_datasets.ownerId -> users.id`, is a persisted dataset of the requested source type, contains at least `ANALYSIS_MIN_CP_MEASUREMENTS` (CP; default 1) or one selected secondary measurement, and shares source `LOT_ID` and `WAFER_ID`. A missing, owner-less, or other-owner source returns 404, even when its id is known.

Execution re-establishes the same owner scope from the durable RUNNING job's `ownerOpenId` before reading any selected dataset or normalized measurement row. Thus queue-time validation is not the only authorization check: a stale, tampered, or historically invalid job cannot cause CP/WAT/KLA rows from an unauthorized dataset to be read. Execution calls only the owner-scoped `ingestion_analysis` aggregate path; it never invokes geometry defaults, synthetic generators, dummy rows, or the CSV parser.

The versioned request manifest records the owner-validated source references and dataset IDs but no source rows, owner database IDs, user records, or storage URLs. The job's `ownerOpenId`, manifest, and report source list retain a clear audit linkage for the owner-scoped decision. Analysis errors and reports do not echo source records.

Legacy `ingestion_datasets` rows with `ownerId IS NULL` are intentionally inaccessible and cannot be queued or executed as shared/reference inputs. They are never auto-adopted; the source must be re-imported by an authenticated owner.

## Capacity and failure behavior

Defaults are intentionally static and conservative:

| Setting | Default | Behavior |
|---|---:|---|
| `ANALYSIS_OWNER_ACTIVE_CAP` | 5 | Maximum `QUEUED` + `RUNNING` jobs for one OpenId |
| `ANALYSIS_GLOBAL_BACKLOG_CAP` | 100 | Maximum global `QUEUED` + `RUNNING` jobs |
| `ANALYSIS_REPORT_MAX_BYTES` | 4 MiB | Maximum canonical UTF-8 JSON report before storage |
| `ANALYSIS_RUNNING_STALE_SECONDS` | 1,800 | Failed-recovery age for interrupted `RUNNING` jobs |
| `ANALYSIS_MIN_CP_MEASUREMENTS` | 1 | Minimum persisted CP measurement rows |

Capacity checks and insert happen under the same queue coordination lock; overflow returns HTTP 429 and does not enqueue. Status timestamps, queue sequence, attempts, request version/manifest, completion time, and a bounded safe error preserve the transition audit. Errors are at most 512 characters, exclude source rows/URLs, and a failed job is owner-visible.

Storage is completion-critical: the executor serializes and bounds JSON, uploads it with ManagedStorage, and only then atomically inserts `analysis_reports` plus transitions the job to `COMPLETED`. Upload failure produces `FAILED`, never `COMPLETED`. A process loss after object upload but before the DB transaction can leave an unreferenced object; it cannot create a completed report without a DB record.

## Historical report contract

Successful jobs retain the full governed JSON in MySQL and ManagedStorage. The sanitized filename is:

```text
<user_name>_<YYYYMMDDTHHMMSSZ>_WAFERMAP_PRO_analysis_<jobid>.json
```

The envelope includes job/queue metadata, authenticated identity, source dataset references, UTC generation time, limits, correlation boundaries/reasons, and the actual `ingestion_analysis` aggregate result. It does not include raw CP/WAT/KLA rows.

- `GET /api/analysis/reports` lists the caller's history and source metadata.
- `GET /api/analysis/reports/<id>` returns owner-scoped metadata and JSON payload.
- `GET /api/analysis/reports/<id>/download` returns the retained DB payload as an `application/json` attachment, so review works even if a direct object-store GET is unavailable.

Neither list nor detail APIs expose `storageUrl` or presigned object URLs. Storage key/url remain server-side persistence fields.

## Upgrade path

When request-driven latency or backlog is no longer acceptable, keep `analysis_jobs`, manifests, owner scoping, atomic claim method, report transaction, and all endpoint contracts. Move only the `execute_at_most_one` trigger into one managed external worker/service with the same database and storage credentials. The worker can call the claim method repeatedly with explicit bounded concurrency; keep concurrency at one for the current resource profile, then increase only after measuring database and memory load and replacing the global-running guard with intentional leases/worker slots.

During migration, disable opportunistic HTTP draining before enabling the external worker to avoid competing triggers. Add heartbeat/lease columns and an immutable transition-event table if automatic retries or multi-worker execution are introduced. Redis/Celery is not required for durability because MySQL remains the source of queue truth, but a managed queue may be added as a wake-up signal only; DB state should stay authoritative.
