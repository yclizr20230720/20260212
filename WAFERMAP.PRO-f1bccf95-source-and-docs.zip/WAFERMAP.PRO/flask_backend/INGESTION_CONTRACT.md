# Real-data ingestion contract

## Endpoints

`POST /api/ingestion/packages/validate` (alias: `/api/ingestion/validate`) accepts `multipart/form-data` with `source_type=CP|WAT|KLA` and explicit CSV file-role fields.

| Package | Primary role | Optional companion roles |
|---|---|---|
| CP | `cp_die` | `cp_summary`, `cp_bins`, `cp_limits` |
| WAT | exactly one of `wat_long`, `wat_wide` | `wat_specs`, `wat_summary`; `wat_wide` requires `wat_specs` |
| KLA | `kla_defects` | `kla_summary`, `kla_classes` |

Defaults are configurable with `WAFERMAP_MAX_REQUEST_BYTES` (384 MiB), `WAFERMAP_MAX_FILE_BYTES` (128 MiB per file), and `WAFERMAP_MAX_ROWS` (250,000 rows per uploaded CSV and normalized WAT-wide output). Files are decoded as UTF-8/UTF-8-BOM and consumed incrementally. Diagnostics are bounded to 50 items and never embed raw source rows.

### Gateway-safe staged uploads

The browser uses the staged protocol for every package submission so public gateways never receive a whole 50+ MiB CSV in one multipart request:

1. `POST /api/ingestion/package-sessions` creates a metadata-only session with `source_type` and role-keyed `{ role, filename, byte_size }` declarations.
2. `POST /api/ingestion/package-sessions/<session_id>/chunks` receives ordered **4 MiB** (configurable) chunks with the session token in `X-WaferMap-Upload-Token`.
3. `POST /api/ingestion/package-sessions/<session_id>/validate` runs the same parser and returns the same bounded validation contract as the legacy endpoint.
4. After an authenticated user selects one canonical partition, `POST /api/ingestion/package-sessions/<session_id>/persist` reparses, fingerprints, retains, and persists that selected wafer. `DELETE /api/ingestion/package-sessions/<session_id>` cancels a session.

Staged data is stored in a private temporary directory, is token-bound, role-bound, size-bound, sequentially chunk-checked, and expires after 30 minutes by default (`WAFERMAP_PACKAGE_UPLOAD_TTL_SECONDS`). Successful persistence and explicit cancellation remove it immediately. The process never echoes source rows or temporary object locations. `WAFERMAP_PACKAGE_UPLOAD_CHUNK_BYTES` is limited to 64 KiB–8 MiB; `WAFERMAP_PACKAGE_UPLOAD_MAX_TOTAL_BYTES` protects aggregate temporary disk consumption. The legacy full-multipart routes remain available for compatible internal clients but are not used by the UI.

`POST /api/ingestion/packages/persist` accepts the same `source_type` and role-keyed CSV fields, plus required `selected_lot_id` and `selected_wafer_id` text fields. It requires the verified `app_session_id` identity. The server maps the authenticated OpenId to `users.id` (creating a normal `user` row when needed without changing an existing role) and writes that owner to both `import_runs.ownerId` and `ingestion_datasets.ownerId`. Form fields cannot select or override the owner, and owner/user identifiers are not included in the response.

The caller must resubmit the complete package that was previewed. The server does not trust a prior preview: it fingerprints and reparses every role, applies the exact validation contract above, reconciles companion identities against the primary role, and then persists only the exact canonical `(selected_lot_id, selected_wafer_id)` partition. Duplicate file-role fields, an absent selection, an unknown selection, an invalid package, an unsupported/cross-source role, or any cross-role partition mismatch is rejected before dataset insertion.

One persist request creates **exactly one `ingestion_datasets` row for exactly one submitted selected wafer**. To retain another wafer from the same source package, submit another request with that wafer's explicit identity. A multi-wafer package is never flattened into one dataset, and omission of either selection field never means “persist all.” Validation scans all source rows, but normalized record collection is gated to the selected partition; for example, unselected CP die and parametric rows are not accumulated in memory.

A successful response has HTTP 201 and this shape (summary fields vary by source):

```json
{
  "status": "COMPLETED",
  "persistent": true,
  "dataset": {
    "dataset_id": 31,
    "import_run_id": 41,
    "source_type": "CP",
    "summary": {"lot_id": "TW2600.1", "wafer_id": "TW2600.1-01"}
  },
  "selected_partition": {
    "partition_key": "TW2600.1::TW2600.1-01",
    "lot_id": "TW2600.1",
    "wafer_id": "TW2600.1-01",
    "valid_rows": 935
  },
  "package": {
    "source_type": "CP",
    "source_package_partition_count": 200,
    "retained_roles": ["cp_bins", "cp_die", "cp_limits", "cp_summary"],
    "parser_mapping_version": "wafermap-real-csv-v1"
  },
  "correlation_ready": false,
  "correlation_note": "The dataset is source-backed, but LOT_ID/WAFER_ID equality alone does not establish cross-source correlation readiness."
}
```

The endpoint does not return a source object URL. Validation failures return HTTP 400 `ingestion_validation_error`; persistence/storage availability failures retain their existing HTTP 503 contracts. Once an import run starts, success finishes it as `COMPLETED`; validation, storage, or persistence failures finish it as `REJECTED` with bounded structured diagnostics and no raw CSV row or source URL.

## Canonical partitions

Every primary row must provide `LOT_ID` and `WAFER_ID`. The response contains a deterministic sorted partition list keyed as `LOT_ID::WAFER_ID`; package identity is never taken from the last row. The validator returns per-partition observed statistics, coordinate-frame labels, source product provenance, per-file SHA-256 checksums, row counts, detected headers, and parser mapping version.

The downloadable CSV templates include recommended manufacturing lineage columns. Browser preflight checks only the exact minimum Flask parser contract for each role, so a valid approved source file is never rejected merely because it omits optional template columns; the authoritative server parser still performs complete semantic validation.

Validation remains a public, non-persistent preview, including for multi-wafer packages. Package persistence is explicitly selected-wafer-only and creates one dataset per request. The legacy `/api/ingestion/upload` endpoint has the same authenticated-owner boundary: it maps the verified identity, persists `ownerId` on its import run and dataset, continues to persist only strict single-wafer real-contract files, and rejects multi-wafer input instead of flattening it. Clients that previously used the legacy persistence endpoint anonymously must now sign in; request identity headers and owner form fields are not trusted.

Every submitted role is retained in managed storage after successful revalidation. Dataset provenance contains a sorted role manifest with sanitized filename, byte size, SHA-256 checksum, detected headers, role mapping, parser version, and retained storage object key. The dataset's legacy storage columns reference the primary role; companion object keys and hashes remain in `packageDiagnostics`. Managed upload URLs and presigned/secret URLs are not included in the package API response or role manifest. The import-run source hash is a deterministic digest over role, sanitized filename, and each role content hash.

## Source semantics

- **CP:** `PASS_FAIL` is authoritative; soft bins 1, 2, and 3 are valid pass bins when the bin-definition companion is supplied. `PRODUCT_ID` is retained from the source and cannot be replaced by a UI form preset. Eight named parametric columns are normalized separately with optional source test limits and observed OOS counts.
- **WAT:** long input retains parameter/spec/unit metadata and source `OOS_FLAG` (`PASS`/`OOS`). Wide input is unpivoted only from parameter columns defined by `wat_specs`; without the spec file it is rejected with an actionable message. WAT product provenance is `UNAVAILABLE` unless the primary source actually supplies a non-empty `PRODUCT_ID`; a supplied source product is retained and is never replaced by form data.
- **KLA:** display `x_mm`/`y_mm` are `XREL_UM`/`YREL_UM` divided by 1000; raw relative micrometre values are retained. Event `KILLER_FLAG` is authoritative even when it differs from `KILLER_DEFAULT`. Class and inspection/reticle context fields are retained. KLA product provenance is `UNAVAILABLE` unless the primary source actually supplies a non-empty `PRODUCT_ID`; a supplied source product is retained and is never replaced by form data.

## Statistical summary and correlation boundary

`GET /api/ingestion/datasets/<cp_dataset_id>/analysis` derives CP yield/bin/parametric-OOS, WAT parameter/OOS, and KLA class/killer/size summaries from persisted normalized rows. Requested secondary datasets must belong to the same authenticated owner and have the same source `LOT_ID` and `WAFER_ID`. `correlation_ready` is false with explicit reasons when no secondary source is selected, product provenance is unavailable, or WAT/KLA coordinate alignment to CP has not been established. No causal or scientific correlation is claimed from identifier equality or coordinate proximity alone.

## Retained-source ownership boundary

The retained-data endpoints `GET /api/ingestion/recent`, `GET /api/ingestion/catalog`, `GET /api/ingestion/datasets/<id>/overlay`, and `GET /api/ingestion/datasets/<id>/analysis` require the verified session identity. Recent results, catalog rows, and catalog facets contain only datasets whose `ownerId` maps to that OpenId. Direct reads return HTTP 404 when a dataset is missing or belongs to another owner, preventing existence disclosure; response payloads never expose `ownerId` or user records.

Existing rows with `ingestion_datasets.ownerId IS NULL` are intentionally outside every authenticated user's scope. They are not auto-adopted, shown as shared reference data, used as optional analysis sources, or reused by queued execution. Re-import the real source while authenticated to create an owner-scoped dataset.

## Geometry-only API boundary

`GET /api/wafer/default` and `POST /api/wafer/calculate` produce only deterministic configuration geometry: wafer outline, usable radius, reticle/shot stepping, die centers, geometric `FULL`/`PARTIAL` containment, and gross-die counts. Without a retained source dataset their contract is `GEOMETRY_ONLY` with measurement state `NO_SOURCE_DATASET`. They do not emit CP bins or pass/fail results, WAT parameters, test frequency or leakage, KLA defects or inspection records, yield, failure clustering, Moran statistics, or other manufacturing observations.

Geometry-only calculations are not saved as analysis sessions. A request with `persist=true` is rejected with HTTP 409. `POST /api/wafer/grid-search-center-offset` performs a deterministic center-offset grid search using only geometric full-die count. The legacy `/api/wafer/optimize-shot` route is a deprecated alias for the same deterministic operation and returns no measurement results.

SEMI E142 and G85 exports are not emitted from configuration geometry. Until a retained, source-specific standards exporter is implemented, `/api/wafer/export/semi-e142` and `/api/wafer/export/semi-g85` return HTTP 409 `source_data_required`; consequently they cannot contain invented bin definitions, die test outcomes, or defect records.
