"""Deterministic wafer and reticle geometry calculations for WAFERMAP.PRO.

This module deliberately does not synthesize manufacturing measurements.  CP,
WAT, and KLA facts are available only through the persisted ingestion paths.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any


class SourceDatasetRequired(RuntimeError):
    """Raised when an operation requires retained real manufacturing data."""


@dataclass
class DieConfig:
    width_mm: float = 8.5
    height_mm: float = 10.2
    scribe_x_mm: float = 0.08
    scribe_y_mm: float = 0.08
    reticle_cols: int = 3
    reticle_rows: int = 2
    die_type_matrix: list[list[str]] = field(
        default_factory=lambda: [
            ["DIE", "DIE", "DIE"],
            ["DIE", "DIE", "DIE"],
        ]
    )


@dataclass
class WaferConfig:
    diameter_mm: float = 300.0
    edge_exclusion_mm: float = 3.0
    notch_angle_deg: float = 270.0
    center_offset_x_mm: float = 0.0
    center_offset_y_mm: float = 0.0
    wafer_id: str = "UNSPECIFIED"
    lot_id: str = "UNSPECIFIED"
    product_id: str = "UNSPECIFIED"


class WaferEngine:
    """Pure deterministic geometry engine; it never invents fab observations."""

    @staticmethod
    def calculate_gdpw_formula(
        diameter_mm: float,
        edge_exclusion_mm: float,
        die_w_mm: float,
        die_h_mm: float,
    ) -> int:
        """Return the closed-form theoretical gross-die approximation."""
        usable_radius = (diameter_mm / 2.0) - edge_exclusion_mm
        if usable_radius <= 0:
            return 0
        die_area = die_w_mm * die_h_mm
        if die_area <= 0:
            return 0
        area_term = (math.pi * usable_radius**2) / die_area
        edge_term = (math.pi * usable_radius) / math.sqrt(2.0 * die_area)
        return max(0, int(area_term - edge_term))

    @staticmethod
    def generate_wafer_layout(
        wafer_cfg: WaferConfig,
        die_cfg: DieConfig,
    ) -> dict[str, Any]:
        """Build a deterministic geometry-only wafer, shot, and die grid.

        FULL/PARTIAL are geometric containment states.  They are not electrical
        test outcomes and no bin, yield, parametric, telemetry, or inspection
        values are generated.
        """
        wafer_radius = wafer_cfg.diameter_mm / 2.0
        usable_radius = wafer_radius - wafer_cfg.edge_exclusion_mm

        reticle_width = (
            die_cfg.reticle_cols * die_cfg.width_mm
            + (die_cfg.reticle_cols - 1) * die_cfg.scribe_x_mm
        )
        reticle_height = (
            die_cfg.reticle_rows * die_cfg.height_mm
            + (die_cfg.reticle_rows - 1) * die_cfg.scribe_y_mm
        )
        shot_pitch_x = reticle_width + die_cfg.scribe_x_mm
        shot_pitch_y = reticle_height + die_cfg.scribe_y_mm
        die_step_x = die_cfg.width_mm + die_cfg.scribe_x_mm
        die_step_y = die_cfg.height_mm + die_cfg.scribe_y_mm

        max_shot_cols = int(math.ceil(wafer_radius / shot_pitch_x)) + 2
        max_shot_rows = int(math.ceil(wafer_radius / shot_pitch_y)) + 2
        shot_half_width = reticle_width / 2.0
        shot_half_height = reticle_height / 2.0
        shot_half_diagonal = math.hypot(shot_half_width, shot_half_height)
        die_half_width = die_cfg.width_mm / 2.0
        die_half_height = die_cfg.height_mm / 2.0

        dies: list[dict[str, Any]] = []
        shots: list[dict[str, Any]] = []
        gross_die_count = 0
        partial_die_count = 0

        for shot_row in range(-max_shot_rows, max_shot_rows + 1):
            for shot_col in range(-max_shot_cols, max_shot_cols + 1):
                shot_center_x = wafer_cfg.center_offset_x_mm + shot_col * shot_pitch_x
                shot_center_y = wafer_cfg.center_offset_y_mm + shot_row * shot_pitch_y
                if math.hypot(shot_center_x, shot_center_y) - shot_half_diagonal > wafer_radius:
                    continue

                shot_dies: list[dict[str, Any]] = []
                full_die_count = 0
                shot_partial_die_count = 0
                for reticle_row in range(die_cfg.reticle_rows):
                    for reticle_col in range(die_cfg.reticle_cols):
                        local_x = (
                            -shot_half_width
                            + reticle_col * die_step_x
                            + die_cfg.width_mm / 2.0
                        )
                        local_y = (
                            shot_half_height
                            - reticle_row * die_step_y
                            - die_cfg.height_mm / 2.0
                        )
                        die_center_x = shot_center_x + local_x
                        die_center_y = shot_center_y + local_y
                        global_die_x = shot_col * die_cfg.reticle_cols + reticle_col
                        global_die_y = (
                            shot_row * die_cfg.reticle_rows
                            + die_cfg.reticle_rows
                            - 1
                            - reticle_row
                        )
                        corners = (
                            (die_center_x - die_half_width, die_center_y - die_half_height),
                            (die_center_x + die_half_width, die_center_y - die_half_height),
                            (die_center_x + die_half_width, die_center_y + die_half_height),
                            (die_center_x - die_half_width, die_center_y + die_half_height),
                        )
                        inside_count = sum(
                            1
                            for corner_x, corner_y in corners
                            if math.hypot(corner_x, corner_y) <= usable_radius
                        )
                        radial_distance = math.hypot(die_center_x, die_center_y)
                        if inside_count == 4:
                            geometry_status = "FULL"
                            is_full_die = True
                            gross_die_count += 1
                            full_die_count += 1
                        elif inside_count > 0 or radial_distance <= usable_radius:
                            geometry_status = "PARTIAL"
                            is_full_die = False
                            partial_die_count += 1
                            shot_partial_die_count += 1
                        else:
                            continue

                        die_type = die_cfg.die_type_matrix[reticle_row][reticle_col]
                        angle_deg = (
                            math.degrees(math.atan2(die_center_y, die_center_x)) + 360.0
                        ) % 360.0
                        die = {
                            "die_uid": f"G({global_die_x:+d},{global_die_y:+d})",
                            "global_x": global_die_x,
                            "global_y": global_die_y,
                            "center_x_mm": round(die_center_x, 4),
                            "center_y_mm": round(die_center_y, 4),
                            "width_mm": round(die_cfg.width_mm, 4),
                            "height_mm": round(die_cfg.height_mm, 4),
                            "shot_row": shot_row,
                            "shot_col": shot_col,
                            "reticle_row": reticle_row,
                            "reticle_col": reticle_col,
                            "die_type": die_type,
                            "status": geometry_status,
                            "is_full_die": is_full_die,
                            "radial_dist_mm": round(radial_distance, 3),
                            "angle_deg": round(angle_deg, 2),
                        }
                        dies.append(die)
                        shot_dies.append(die)

                if shot_dies:
                    shots.append(
                        {
                            "shot_id": f"S({shot_row:+03d},{shot_col:+03d})",
                            "shot_row": shot_row,
                            "shot_col": shot_col,
                            "center_x_mm": round(shot_center_x, 4),
                            "center_y_mm": round(shot_center_y, 4),
                            "width_mm": round(reticle_width, 4),
                            "height_mm": round(reticle_height, 4),
                            "status": (
                                "FULL"
                                if full_die_count == len(shot_dies)
                                else "PARTIAL"
                            ),
                            "die_count": len(shot_dies),
                            "full_die_count": full_die_count,
                            "partial_die_count": shot_partial_die_count,
                        }
                    )

        theoretical_gdpw = WaferEngine.calculate_gdpw_formula(
            wafer_cfg.diameter_mm,
            wafer_cfg.edge_exclusion_mm,
            die_cfg.width_mm,
            die_cfg.height_mm,
        )
        return {
            "contract": {
                "mode": "GEOMETRY_ONLY",
                "measurement_state": "NO_SOURCE_DATASET",
                "measurements_available": False,
                "description": (
                    "Configuration-derived wafer and reticle geometry only; "
                    "no manufacturing result is inferred."
                ),
            },
            "metadata": {
                "wafer_id": wafer_cfg.wafer_id,
                "lot_id": wafer_cfg.lot_id,
                "product_id": wafer_cfg.product_id,
                "identifiers_are_configuration": True,
                "diameter_mm": wafer_cfg.diameter_mm,
                "edge_exclusion_mm": wafer_cfg.edge_exclusion_mm,
                "usable_radius_mm": round(usable_radius, 3),
                "notch_angle_deg": wafer_cfg.notch_angle_deg,
                "center_offset_x_mm": wafer_cfg.center_offset_x_mm,
                "center_offset_y_mm": wafer_cfg.center_offset_y_mm,
                "theoretical_gdpw": theoretical_gdpw,
                "theoretical_gross_die_count": theoretical_gdpw,
                "gross_die_count": gross_die_count,
                "partial_die_count": partial_die_count,
                "reticle_field_w_mm": round(reticle_width, 4),
                "reticle_field_h_mm": round(reticle_height, 4),
                "reticle_rows": die_cfg.reticle_rows,
                "reticle_cols": die_cfg.reticle_cols,
                "shot_pitch_x_mm": round(shot_pitch_x, 4),
                "shot_pitch_y_mm": round(shot_pitch_y, 4),
                "total_shots": len(shots),
            },
            "dies": dies,
            "shots": shots,
        }

    @staticmethod
    def grid_search_center_offset(
        wafer_cfg: WaferConfig,
        die_cfg: DieConfig,
        grid_steps: int = 24,
    ) -> dict[str, Any]:
        """Deterministically search one shot pitch for maximum full-die count."""
        reticle_width = (
            die_cfg.reticle_cols * die_cfg.width_mm
            + (die_cfg.reticle_cols - 1) * die_cfg.scribe_x_mm
        )
        reticle_height = (
            die_cfg.reticle_rows * die_cfg.height_mm
            + (die_cfg.reticle_rows - 1) * die_cfg.scribe_y_mm
        )
        shot_pitch_x = reticle_width + die_cfg.scribe_x_mm
        shot_pitch_y = reticle_height + die_cfg.scribe_y_mm
        step_x = shot_pitch_x / grid_steps
        step_y = shot_pitch_y / grid_steps

        best_offset = (0.0, 0.0)
        best_gross_die_count = -1
        candidate_grid: list[list[dict[str, Any]]] = []
        for x_index in range(grid_steps):
            offset_x = (x_index - grid_steps / 2.0) * step_x
            row: list[dict[str, Any]] = []
            for y_index in range(grid_steps):
                offset_y = (y_index - grid_steps / 2.0) * step_y
                candidate_config = WaferConfig(
                    diameter_mm=wafer_cfg.diameter_mm,
                    edge_exclusion_mm=wafer_cfg.edge_exclusion_mm,
                    notch_angle_deg=wafer_cfg.notch_angle_deg,
                    center_offset_x_mm=offset_x,
                    center_offset_y_mm=offset_y,
                    wafer_id=wafer_cfg.wafer_id,
                    lot_id=wafer_cfg.lot_id,
                    product_id=wafer_cfg.product_id,
                )
                gross_die_count = WaferEngine.generate_wafer_layout(
                    candidate_config, die_cfg
                )["metadata"]["gross_die_count"]
                row.append(
                    {
                        "offset_x_mm": round(offset_x, 3),
                        "offset_y_mm": round(offset_y, 3),
                        "gross_die_count": gross_die_count,
                    }
                )
                if gross_die_count > best_gross_die_count:
                    best_gross_die_count = gross_die_count
                    best_offset = (offset_x, offset_y)
            candidate_grid.append(row)

        baseline_gross_die_count = WaferEngine.generate_wafer_layout(
            wafer_cfg, die_cfg
        )["metadata"]["gross_die_count"]
        return {
            "contract": {
                "mode": "GEOMETRY_ONLY",
                "measurement_state": "NO_SOURCE_DATASET",
                "measurements_available": False,
            },
            "search_method": "DETERMINISTIC_CENTER_OFFSET_GRID_SEARCH",
            "grid_steps": grid_steps,
            "candidate_count": grid_steps * grid_steps,
            "best_offset_x_mm": round(best_offset[0], 4),
            "best_offset_y_mm": round(best_offset[1], 4),
            "best_gross_die_count": best_gross_die_count,
            "baseline_gross_die_count": baseline_gross_die_count,
            "gross_die_gain": best_gross_die_count - baseline_gross_die_count,
            "candidate_grid": candidate_grid,
        }

    @staticmethod
    def calculate_spatial_analytics(layout_data: dict[str, Any]) -> dict[str, Any]:
        """Return an explicit no-data state for a configuration-derived layout."""
        del layout_data
        return {
            "available": False,
            "state": "NO_SOURCE_DATASET",
            "source_dataset_id": None,
            "message": (
                "Measurement analytics require a retained real CP/WAT/KLA "
                "dataset and are not calculated from geometry."
            ),
        }

    @staticmethod
    def export_semi_e142_xml(layout_data: dict[str, Any]) -> str:
        """Reject geometry-only E142 output until a source-backed exporter exists."""
        del layout_data
        raise SourceDatasetRequired(
            "SEMI E142 export requires a retained source dataset; the current "
            "backend does not implement a source-backed E142 exporter."
        )

    @staticmethod
    def export_semi_g85_map(layout_data: dict[str, Any]) -> str:
        """Reject geometry-only G85 output until a source-backed exporter exists."""
        del layout_data
        raise SourceDatasetRequired(
            "SEMI G85 export requires a retained source dataset; the current "
            "backend does not implement a source-backed G85 exporter."
        )
