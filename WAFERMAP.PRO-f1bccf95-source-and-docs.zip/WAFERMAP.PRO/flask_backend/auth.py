"""Authentication helpers for Flask routes backed by the existing Manus session cookie.

Production authentication verifies the Node-created ``app_session_id`` HS256 JWT with
Python's standard library. Tests may inject an identity through Flask configuration;
there is deliberately no trusted identity HTTP header.
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import json
import math
import time
from dataclasses import dataclass
from typing import Any, Callable

from flask import Flask, request

SESSION_COOKIE_NAME = "app_session_id"
MAX_SESSION_TOKEN_BYTES = 8192


class AuthenticationError(RuntimeError):
    """An API request is missing a session or supplied an unverifiable session."""

    def __init__(self, message: str, status_code: int):
        super().__init__(message)
        self.status_code = status_code


@dataclass(frozen=True)
class AuthenticatedIdentity:
    open_id: str
    app_id: str
    name: str


def _base64url_decode(value: str) -> bytes:
    if not value or any(character not in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_" for character in value):
        raise ValueError("Invalid base64url value.")
    try:
        return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))
    except (binascii.Error, ValueError) as exc:
        raise ValueError("Invalid base64url value.") from exc


def verify_hs256_session(token: str, secret: str, *, now: float | None = None) -> AuthenticatedIdentity:
    """Verify the Node ``jose`` HS256 session shape without adding PyJWT."""
    if not isinstance(token, str) or not token or len(token.encode("utf-8")) > MAX_SESSION_TOKEN_BYTES:
        raise ValueError("Invalid session token.")
    if not isinstance(secret, str) or not secret:
        raise ValueError("Session verification is not configured.")
    parts = token.split(".")
    if len(parts) != 3:
        raise ValueError("Invalid session token.")
    encoded_header, encoded_payload, encoded_signature = parts
    try:
        header = json.loads(_base64url_decode(encoded_header).decode("utf-8"))
        payload = json.loads(_base64url_decode(encoded_payload).decode("utf-8"))
        signature = _base64url_decode(encoded_signature)
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
        raise ValueError("Invalid session token.") from exc
    if not isinstance(header, dict) or header.get("alg") != "HS256":
        raise ValueError("Unsupported session signing algorithm.")
    if not isinstance(payload, dict):
        raise ValueError("Invalid session payload.")
    signing_input = f"{encoded_header}.{encoded_payload}".encode("ascii")
    expected = hmac.new(secret.encode("utf-8"), signing_input, hashlib.sha256).digest()
    if not hmac.compare_digest(signature, expected):
        raise ValueError("Invalid session signature.")
    expiration = payload.get("exp")
    if isinstance(expiration, bool) or not isinstance(expiration, (int, float)) or not math.isfinite(float(expiration)):
        raise ValueError("Invalid session expiration.")
    if float(expiration) <= (time.time() if now is None else now):
        raise ValueError("Session has expired.")
    open_id = payload.get("openId")
    app_id = payload.get("appId")
    name = payload.get("name")
    if not all(isinstance(value, str) and value.strip() for value in (open_id, app_id, name)):
        raise ValueError("Session payload is missing required identity fields.")
    if len(open_id) > 191 or len(app_id) > 191 or len(name) > 255:
        raise ValueError("Session identity exceeds storage limits.")
    return AuthenticatedIdentity(open_id=open_id, app_id=app_id, name=name)


def _test_identity(app: Flask) -> AuthenticatedIdentity | None:
    configured: Any = app.config.get("ANALYSIS_TEST_IDENTITY")
    provider: Callable[[], Any] | None = app.config.get("ANALYSIS_TEST_IDENTITY_PROVIDER")
    if configured is None and provider is None:
        return None
    if not app.config.get("TESTING"):
        raise RuntimeError("Test analysis identities are forbidden outside Flask TESTING mode.")
    value = provider() if provider is not None else configured
    if value is None:
        return None
    if isinstance(value, AuthenticatedIdentity):
        return value
    if not isinstance(value, dict):
        raise RuntimeError("ANALYSIS_TEST_IDENTITY must be a mapping or AuthenticatedIdentity.")
    open_id = value.get("open_id", value.get("openId"))
    app_id = value.get("app_id", value.get("appId", "test-app"))
    name = value.get("name")
    if not all(isinstance(item, str) and item.strip() for item in (open_id, app_id, name)):
        raise RuntimeError("ANALYSIS_TEST_IDENTITY requires non-empty open_id, app_id, and name.")
    return AuthenticatedIdentity(open_id=open_id, app_id=app_id, name=name)


def require_authenticated_identity(app: Flask) -> AuthenticatedIdentity:
    """Return the authenticated caller or raise a 401/403 AuthenticationError."""
    identity = _test_identity(app)
    if identity is not None:
        return identity
    token = request.cookies.get(SESSION_COOKIE_NAME)
    if not token:
        raise AuthenticationError("Authentication is required.", 401)
    try:
        return verify_hs256_session(token, str(app.config.get("JWT_SECRET", "")))
    except ValueError as exc:
        raise AuthenticationError("The session cookie could not be verified.", 403) from exc
