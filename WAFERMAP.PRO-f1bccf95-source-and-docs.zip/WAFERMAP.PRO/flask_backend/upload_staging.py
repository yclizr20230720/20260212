"""Bounded, short-lived staging for gateway-safe package uploads.

The public WebDev gateway can reject a single multipart body before Flask receives it.
This manager accepts a package as a sequence of small role-bound chunks, writes only
those chunks to a private temporary directory, and exposes completed role files as
fresh ``FileStorage`` streams to the existing CSV package parser.  It deliberately
never returns raw CSV data or storage URLs.
"""

from __future__ import annotations

import hashlib
import hmac
import os
import secrets
import shutil
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from werkzeug.datastructures import FileStorage

try:
    from .ingestion import PACKAGE_ROLES
except ImportError:  # Supports local execution from flask_backend.
    from ingestion import PACKAGE_ROLES


class UploadStagingError(ValueError):
    """Raised for safe, client-actionable staged upload failures."""


@dataclass
class StagedRole:
    role: str
    filename: str
    declared_bytes: int
    path: Path
    total_chunks: int | None = None
    next_chunk_index: int = 0
    received_bytes: int = 0
    complete: bool = False


@dataclass
class StagedSession:
    session_id: str
    token: str
    source_type: str
    directory: Path
    created_at: float
    expires_at: float
    roles: dict[str, StagedRole] = field(default_factory=dict)
    accepted_bytes: int = 0


class PackageUploadManager:
    """Thread-safe ephemeral staging with bounded disk and request consumption."""

    def __init__(
        self,
        directory: str | Path,
        *,
        chunk_bytes: int = 4 * 1024 * 1024,
        max_file_bytes: int = 128 * 1024 * 1024,
        max_session_bytes: int = 384 * 1024 * 1024,
        max_total_bytes: int = 1024 * 1024 * 1024,
        ttl_seconds: int = 30 * 60,
    ) -> None:
        self.directory = Path(directory).resolve()
        self.chunk_bytes = int(chunk_bytes)
        self.max_file_bytes = int(max_file_bytes)
        self.max_session_bytes = int(max_session_bytes)
        self.max_total_bytes = int(max_total_bytes)
        self.ttl_seconds = int(ttl_seconds)
        if self.chunk_bytes < 64 * 1024 or self.chunk_bytes > 8 * 1024 * 1024:
            raise ValueError("chunk_bytes must be between 64 KiB and 8 MiB")
        self.directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        self._sessions: dict[str, StagedSession] = {}
        self._lock = threading.RLock()

    def _now(self) -> float:
        return time.time()

    def _safe_filename(self, value: Any) -> str:
        filename = Path(str(value or "")).name.strip()
        if not filename or filename in {".", ".."} or len(filename) > 255:
            raise UploadStagingError("Each staged file requires a safe filename no longer than 255 characters.")
        if not filename.lower().endswith(".csv"):
            raise UploadStagingError("Staged package uploads accept CSV files only.")
        return filename

    def _cleanup_expired_locked(self) -> None:
        now = self._now()
        for session_id, session in list(self._sessions.items()):
            if session.expires_at <= now:
                self._remove_session_locked(session_id)

    def _remove_session_locked(self, session_id: str) -> None:
        session = self._sessions.pop(session_id, None)
        if session is not None:
            shutil.rmtree(session.directory, ignore_errors=True)

    def _active_bytes_locked(self) -> int:
        return sum(session.accepted_bytes for session in self._sessions.values())

    def create(self, source_type: str, files: Any) -> dict[str, Any]:
        source_type = str(source_type or "").strip().upper()
        contract = PACKAGE_ROLES.get(source_type)
        if contract is None:
            raise UploadStagingError("source_type must be CP, WAT, or KLA.")
        if not isinstance(files, list) or not files:
            raise UploadStagingError("Provide a non-empty files array with role, filename, and byte_size for staged upload.")
        if len(files) > len(contract["allowed"]):
            raise UploadStagingError("The staged package declares more roles than the selected source type allows.")

        declared: list[tuple[str, str, int]] = []
        seen_roles: set[str] = set()
        total_bytes = 0
        for item in files:
            if not isinstance(item, dict):
                raise UploadStagingError("Each staged file declaration must be an object.")
            role = str(item.get("role", "")).strip()
            if role not in contract["allowed"]:
                raise UploadStagingError(f"File role '{role or 'unknown'}' is not allowed for {source_type}.")
            if role in seen_roles:
                raise UploadStagingError(f"File role '{role}' may be declared only once.")
            try:
                byte_size = int(item.get("byte_size"))
            except (TypeError, ValueError) as exc:
                raise UploadStagingError(f"File role '{role}' requires an integer byte_size.") from exc
            if byte_size < 1 or byte_size > self.max_file_bytes:
                raise UploadStagingError(
                    f"File role '{role}' must be between 1 byte and {self.max_file_bytes:,} bytes."
                )
            filename = self._safe_filename(item.get("filename"))
            declared.append((role, filename, byte_size))
            seen_roles.add(role)
            total_bytes += byte_size

        if total_bytes > self.max_session_bytes:
            raise UploadStagingError(
                f"This package is {total_bytes:,} bytes; staged packages are limited to {self.max_session_bytes:,} bytes."
            )

        with self._lock:
            self._cleanup_expired_locked()
            if self._active_bytes_locked() + total_bytes > self.max_total_bytes:
                raise UploadStagingError("The temporary upload queue is full. Wait for an active upload to finish, then retry.")
            session_id = secrets.token_urlsafe(24)
            token = secrets.token_urlsafe(32)
            session_directory = self.directory / session_id
            session_directory.mkdir(mode=0o700)
            now = self._now()
            session = StagedSession(
                session_id=session_id,
                token=token,
                source_type=source_type,
                directory=session_directory,
                created_at=now,
                expires_at=now + self.ttl_seconds,
            )
            for role, filename, byte_size in declared:
                session.roles[role] = StagedRole(
                    role=role,
                    filename=filename,
                    declared_bytes=byte_size,
                    path=session_directory / f"{role}.csv",
                )
            self._sessions[session_id] = session
            return self._public_session(session, include_token=True)

    def _get_locked(self, session_id: str, token: str) -> StagedSession:
        self._cleanup_expired_locked()
        session = self._sessions.get(str(session_id or ""))
        if session is None:
            raise UploadStagingError("The staged upload session was not found or expired. Start validation again.")
        if not token or not hmac.compare_digest(session.token, token):
            raise UploadStagingError("The staged upload token is invalid. Start validation again.")
        return session

    def _public_session(self, session: StagedSession, *, include_token: bool = False) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "session_id": session.session_id,
            "source_type": session.source_type,
            "chunk_bytes": self.chunk_bytes,
            "expires_at": int(session.expires_at * 1000),
            "files": [
                {
                    "role": staged.role,
                    "filename": staged.filename,
                    "byte_size": staged.declared_bytes,
                    "received_bytes": staged.received_bytes,
                    "next_chunk_index": staged.next_chunk_index,
                    "total_chunks": staged.total_chunks,
                    "complete": staged.complete,
                }
                for staged in sorted(session.roles.values(), key=lambda item: item.role)
            ],
        }
        if include_token:
            payload["upload_token"] = session.token
        return payload

    def receive_chunk(
        self,
        session_id: str,
        token: str,
        *,
        role: str,
        chunk_index: int,
        total_chunks: int,
        upload: FileStorage | None,
    ) -> dict[str, Any]:
        if upload is None or not upload.filename:
            raise UploadStagingError("Attach one chunk file for the declared role.")
        try:
            chunk_index = int(chunk_index)
            total_chunks = int(total_chunks)
        except (TypeError, ValueError) as exc:
            raise UploadStagingError("chunk_index and total_chunks must be integers.") from exc
        if chunk_index < 0 or total_chunks < 1 or chunk_index >= total_chunks:
            raise UploadStagingError("Chunk index is outside the declared chunk range.")

        with self._lock:
            session = self._get_locked(session_id, token)
            staged = session.roles.get(str(role or ""))
            if staged is None:
                raise UploadStagingError("The chunk role was not declared for this staged package.")
            if staged.total_chunks is not None and staged.total_chunks != total_chunks:
                raise UploadStagingError("All chunks for a role must use the same total_chunks value.")
            if chunk_index < staged.next_chunk_index:
                return {"status": "ALREADY_RECEIVED", **self._public_session(session)}
            if chunk_index != staged.next_chunk_index:
                raise UploadStagingError(
                    f"Chunk {chunk_index} is out of order; next required chunk is {staged.next_chunk_index}."
                )
            content = upload.stream.read(self.chunk_bytes + 1)
            if not content:
                raise UploadStagingError("Empty chunks are not accepted.")
            if len(content) > self.chunk_bytes:
                raise UploadStagingError(f"Each upload chunk must be no larger than {self.chunk_bytes:,} bytes.")
            if staged.received_bytes + len(content) > staged.declared_bytes:
                raise UploadStagingError("Received chunk bytes exceed the file size declared when the session was created.")
            if chunk_index == total_chunks - 1 and staged.received_bytes + len(content) != staged.declared_bytes:
                raise UploadStagingError(
                    f"Final chunk size does not match the declared {staged.declared_bytes:,}-byte file size."
                )
            if self._active_bytes_locked() + len(content) > self.max_total_bytes:
                raise UploadStagingError("The temporary upload queue is full. Retry after an active upload completes.")
            mode = "ab" if staged.path.exists() else "wb"
            with staged.path.open(mode) as output:
                output.write(content)
            staged.received_bytes += len(content)
            session.accepted_bytes += len(content)
            staged.total_chunks = total_chunks
            staged.next_chunk_index += 1
            if staged.next_chunk_index == total_chunks:
                staged.complete = True
            return {"status": "CHUNK_RECEIVED", **self._public_session(session)}

    def completed_file_storages(self, session_id: str, token: str) -> tuple[str, dict[str, FileStorage]]:
        """Open fresh streams for a fully received package. Caller must close them."""
        with self._lock:
            session = self._get_locked(session_id, token)
            incomplete = [item.role for item in session.roles.values() if not item.complete]
            if incomplete:
                raise UploadStagingError(f"Complete every declared file before validation: {', '.join(sorted(incomplete))}.")
            uploads: dict[str, FileStorage] = {}
            try:
                for role, staged in session.roles.items():
                    stream = staged.path.open("rb")
                    uploads[role] = FileStorage(stream=stream, filename=staged.filename, content_type="text/csv")
            except Exception:
                for upload in uploads.values():
                    upload.close()
                raise
            return session.source_type, uploads

    def session_metadata(self, session_id: str, token: str) -> dict[str, Any]:
        with self._lock:
            return self._public_session(self._get_locked(session_id, token))

    def abandon(self, session_id: str, token: str) -> None:
        with self._lock:
            self._get_locked(session_id, token)
            self._remove_session_locked(session_id)

    def consume(self, session_id: str, token: str) -> None:
        """Remove source chunks after successful persistence; caller must have closed streams."""
        self.abandon(session_id, token)

    @staticmethod
    def fingerprints(uploads: dict[str, FileStorage]) -> list[dict[str, Any]]:
        """Stream hashes for audit manifests without retaining file bytes in memory."""
        metadata: list[dict[str, Any]] = []
        for role, upload in uploads.items():
            digest = hashlib.sha256()
            count = 0
            while True:
                chunk = upload.stream.read(1024 * 1024)
                if not chunk:
                    break
                digest.update(chunk)
                count += len(chunk)
            upload.stream.seek(0)
            metadata.append({"role": role, "filename": Path(upload.filename or "").name, "byte_size": count, "checksum_sha256": digest.hexdigest()})
        return sorted(metadata, key=lambda item: item["role"])
