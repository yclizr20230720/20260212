"""Flask API and same-origin SPA host for the deployable WAFERMAP.PRO website."""

from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path
from typing import Any

from flask import Flask, Response, abort, current_app, jsonify, request, send_from_directory
from werkzeug.exceptions import HTTPException

try:
    from .analysis_queue import AnalysisQueueExecutor, REQUEST_MANIFEST_VERSION, build_request_manifest
    from .auth import AuthenticationError, require_authenticated_identity
    from .engine import DieConfig, SourceDatasetRequired, WaferConfig, WaferEngine
    from .ingestion import (
        DEFAULT_MAX_FILE_BYTES,
        DEFAULT_MAX_ROWS,
        IngestionValidationError,
        parse_ingestion_file,
        parse_ingestion_package_partition,
        validate_ingestion_package,
    )
    from .repository import OwnedDatasetNotFound, PersistenceUnavailable, QueueCapacityError, WaferRepository
    from .storage import ManagedStorage, StorageUnavailable
    from .upload_staging import PackageUploadManager, UploadStagingError
except ImportError:  # Supports local `python app.py` execution from the flask_backend directory.
    from analysis_queue import AnalysisQueueExecutor, REQUEST_MANIFEST_VERSION, build_request_manifest
    from auth import AuthenticationError, require_authenticated_identity
    from engine import DieConfig, SourceDatasetRequired, WaferConfig, WaferEngine
    from ingestion import DEFAULT_MAX_FILE_BYTES, DEFAULT_MAX_ROWS, IngestionValidationError, parse_ingestion_file, parse_ingestion_package_partition, validate_ingestion_package
    from repository import OwnedDatasetNotFound, PersistenceUnavailable, QueueCapacityError, WaferRepository
    from storage import ManagedStorage, StorageUnavailable
    from upload_staging import PackageUploadManager, UploadStagingError

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DIST_DIR = PROJECT_ROOT / "dist" / "public"
DEFAULT_DIE_TYPES = [["DIE", "DIE", "DIE"], ["DIE", "DIE", "DIE"]]


class RequestValidationError(ValueError):
    """Raised when a request cannot safely form a wafer layout configuration."""


def _number(payload: dict[str, Any], key: str, default: float, *, minimum: float | None = None, maximum: float | None = None) -> float:
    try:
        value = float(payload.get(key, default))
    except (TypeError, ValueError) as exc:
        raise RequestValidationError(f"'{key}' must be numeric.") from exc
    if not math.isfinite(value):
        raise RequestValidationError(f"'{key}' must be finite.")
    if minimum is not None and value < minimum:
        raise RequestValidationError(f"'{key}' must be at least {minimum}.")
    if maximum is not None and value > maximum:
        raise RequestValidationError(f"'{key}' must be at most {maximum}.")
    return value


def _integer(payload: dict[str, Any], key: str, default: int, *, minimum: int, maximum: int) -> int:
    value = _number(payload, key, default, minimum=minimum, maximum=maximum)
    if not value.is_integer():
        raise RequestValidationError(f"'{key}' must be an integer.")
    return int(value)


def _text(payload: dict[str, Any], key: str, default: str, *, max_length: int) -> str:
    value = str(payload.get(key, default)).strip()
    if not value:
        raise RequestValidationError(f"'{key}' cannot be empty.")
    if len(value) > max_length:
        raise RequestValidationError(f"'{key}' must be {max_length} characters or fewer.")
    return value


def _read_payload() -> dict[str, Any]:
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        raise RequestValidationError("Request body must be a JSON object.")
    return payload


def _positive_dataset_id(payload: dict[str, Any], key: str, *, required: bool) -> int | None:
    value = payload.get(key)
    if value is None and not required:
        return None
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        requirement = "required and " if required else ""
        raise RequestValidationError(f"'{key}' is {requirement}must be a positive integer.")
    return value


def _bounded_query_limit(default: int = 50) -> int:
    try:
        return min(max(int(request.args.get("limit", str(default))), 1), 100)
    except ValueError as exc:
        raise RequestValidationError("'limit' must be an integer.") from exc


def _reject_geometry_persistence(payload: dict[str, Any]) -> None:
    value = payload.get("persist", False)
    if not isinstance(value, bool):
        raise RequestValidationError("'persist' must be a boolean.")
    if value:
        raise SourceDatasetRequired(
            "Geometry-only calculations are not analysis sessions and cannot be persisted."
        )


def _optional_dataset_query_id(key: str) -> int | None:
    raw_value = request.args.get(key)
    if raw_value in (None, ""):
        return None
    try:
        value = int(raw_value)
    except ValueError as exc:
        raise RequestValidationError(f"'{key}' must be a positive integer.") from exc
    if value < 1:
        raise RequestValidationError(f"'{key}' must be a positive integer.")
    return value


def _catalog_text_query(key: str) -> str | None:
    value = request.args.get(key)
    if value in (None, ""):
        return None
    return _text({key: value}, key, "", max_length=128)


def _catalog_source_types() -> list[str]:
    raw_value = request.args.get("source_types", "")
    if not raw_value:
        return []
    values = [value.strip().upper() for value in raw_value.split(",") if value.strip()]
    if not values or any(value not in {"CP", "WAT", "KLA"} for value in values):
        raise RequestValidationError("'source_types' must contain only CP, WAT, or KLA.")
    return values


def _package_request_audit_identity(source_type: str, package_files: dict[str, Any]) -> tuple[str, str]:
    """Hash a role-keyed upload without retaining its bytes or exposing source content."""
    package_digest = hashlib.sha256()
    names: list[str] = []
    for role, upload in sorted(package_files.items()):
        filename = Path(str(upload.filename or f"{role}.csv")).name
        names.append(f"{role}={filename}")
        file_digest = hashlib.sha256()
        upload.stream.seek(0)
        while True:
            chunk = upload.stream.read(1024 * 1024)
            if not chunk:
                break
            file_digest.update(chunk)
        upload.stream.seek(0)
        package_digest.update(role.encode("utf-8"))
        package_digest.update(b"\0")
        package_digest.update(filename.encode("utf-8"))
        package_digest.update(b"\0")
        package_digest.update(file_digest.digest())
    label = f"{source_type} package: " + ", ".join(names)
    return label[:255], package_digest.hexdigest()


def _build_configs(payload: dict[str, Any]) -> tuple[WaferConfig, DieConfig]:
    die_type_matrix = payload.get("die_type_matrix", DEFAULT_DIE_TYPES)
    if not isinstance(die_type_matrix, list) or not die_type_matrix or not all(isinstance(row, list) and row for row in die_type_matrix):
        raise RequestValidationError("'die_type_matrix' must be a non-empty two-dimensional array.")
    reticle_cols = _integer(payload, "reticle_cols", 3, minimum=1, maximum=32)
    reticle_rows = _integer(payload, "reticle_rows", 2, minimum=1, maximum=32)
    if len(die_type_matrix) != reticle_rows or any(len(row) != reticle_cols for row in die_type_matrix):
        raise RequestValidationError("'die_type_matrix' dimensions must match 'reticle_rows' and 'reticle_cols'.")

    wafer_config = WaferConfig(
        diameter_mm=_number(payload, "diameter_mm", 300.0, minimum=25.0, maximum=450.0),
        edge_exclusion_mm=_number(payload, "edge_exclusion_mm", 3.0, minimum=0.0, maximum=25.0),
        notch_angle_deg=_number(payload, "notch_angle_deg", 270.0, minimum=0.0, maximum=360.0),
        center_offset_x_mm=_number(payload, "center_offset_x_mm", 0.0, minimum=-300.0, maximum=300.0),
        center_offset_y_mm=_number(payload, "center_offset_y_mm", 0.0, minimum=-300.0, maximum=300.0),
        wafer_id=_text(payload, "wafer_id", "UNSPECIFIED", max_length=128),
        lot_id=_text(payload, "lot_id", "UNSPECIFIED", max_length=128),
        product_id=_text(payload, "product_id", "UNSPECIFIED", max_length=128),
    )
    if wafer_config.edge_exclusion_mm >= wafer_config.diameter_mm / 2:
        raise RequestValidationError("'edge_exclusion_mm' must be smaller than the wafer radius.")
    die_config = DieConfig(
        width_mm=_number(payload, "die_width_mm", 8.5, minimum=0.05, maximum=100.0),
        height_mm=_number(payload, "die_height_mm", 10.2, minimum=0.05, maximum=100.0),
        scribe_x_mm=_number(payload, "scribe_x_mm", 0.0, minimum=0.0, maximum=10.0),
        scribe_y_mm=_number(payload, "scribe_y_mm", 0.0, minimum=0.0, maximum=10.0),
        reticle_cols=reticle_cols,
        reticle_rows=reticle_rows,
        die_type_matrix=[[str(cell)[:64] for cell in row] for row in die_type_matrix],
    )
    return wafer_config, die_config


def create_app(test_config: dict[str, Any] | None = None) -> Flask:
    """Create a validated Flask API which also serves the React production build."""
    app = Flask(__name__)
    app.config.from_mapping(
        JSON_SORT_KEYS=False,
        MAX_CONTENT_LENGTH=int(os.environ.get("WAFERMAP_MAX_REQUEST_BYTES", str(384 * 1024 * 1024))),
        INGESTION_MAX_FILE_BYTES=int(os.environ.get("WAFERMAP_MAX_FILE_BYTES", str(DEFAULT_MAX_FILE_BYTES))),
        INGESTION_MAX_ROWS=int(os.environ.get("WAFERMAP_MAX_ROWS", str(DEFAULT_MAX_ROWS))),
        PACKAGE_UPLOAD_STAGING_DIR=os.environ.get("WAFERMAP_PACKAGE_UPLOAD_STAGING_DIR", "/tmp/wafermap-package-staging"),
        PACKAGE_UPLOAD_CHUNK_BYTES=int(os.environ.get("WAFERMAP_PACKAGE_UPLOAD_CHUNK_BYTES", str(4 * 1024 * 1024))),
        PACKAGE_UPLOAD_TTL_SECONDS=int(os.environ.get("WAFERMAP_PACKAGE_UPLOAD_TTL_SECONDS", "1800")),
        PACKAGE_UPLOAD_MAX_TOTAL_BYTES=int(os.environ.get("WAFERMAP_PACKAGE_UPLOAD_MAX_TOTAL_BYTES", str(512 * 1024 * 1024))),
        JWT_SECRET=os.environ.get("JWT_SECRET", ""),
        ANALYSIS_OWNER_ACTIVE_CAP=int(os.environ.get("ANALYSIS_OWNER_ACTIVE_CAP", "5")),
        ANALYSIS_GLOBAL_BACKLOG_CAP=int(os.environ.get("ANALYSIS_GLOBAL_BACKLOG_CAP", "100")),
        ANALYSIS_REPORT_MAX_BYTES=int(os.environ.get("ANALYSIS_REPORT_MAX_BYTES", str(4 * 1024 * 1024))),
        ANALYSIS_RUNNING_STALE_SECONDS=int(os.environ.get("ANALYSIS_RUNNING_STALE_SECONDS", "1800")),
        ANALYSIS_MIN_CP_MEASUREMENTS=int(os.environ.get("ANALYSIS_MIN_CP_MEASUREMENTS", "1")),
        FRONTEND_DIST=DIST_DIR,
    )
    if test_config:
        app.config.update(test_config)
    repository = app.config.get("WAFER_REPOSITORY") or WaferRepository.from_environment()
    storage = app.config.get("INGESTION_STORAGE") or ManagedStorage.from_environment()
    upload_manager = app.config.get("PACKAGE_UPLOAD_MANAGER") or PackageUploadManager(
        app.config["PACKAGE_UPLOAD_STAGING_DIR"],
        chunk_bytes=int(app.config["PACKAGE_UPLOAD_CHUNK_BYTES"]),
        max_file_bytes=int(app.config["INGESTION_MAX_FILE_BYTES"]),
        max_session_bytes=int(app.config["MAX_CONTENT_LENGTH"]),
        max_total_bytes=int(app.config["PACKAGE_UPLOAD_MAX_TOTAL_BYTES"]),
        ttl_seconds=int(app.config["PACKAGE_UPLOAD_TTL_SECONDS"]),
    )
    if (app.config.get("ANALYSIS_TEST_IDENTITY") is not None or app.config.get("ANALYSIS_TEST_IDENTITY_PROVIDER") is not None) and not app.config.get("TESTING"):
        raise RuntimeError("Test analysis identities may only be configured while Flask TESTING is true.")
    executor = AnalysisQueueExecutor(
        repository,
        storage,
        report_max_bytes=int(app.config["ANALYSIS_REPORT_MAX_BYTES"]),
        running_stale_seconds=int(app.config["ANALYSIS_RUNNING_STALE_SECONDS"]),
    ) if repository is not None else None

    @app.after_request
    def add_response_headers(response: Response) -> Response:
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "SAMEORIGIN"
        response.headers["Referrer-Policy"] = "same-origin"
        if request.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        return response

    @app.errorhandler(RequestValidationError)
    def validation_error(error: RequestValidationError) -> tuple[Response, int]:
        return jsonify({"error": "validation_error", "message": str(error)}), 400

    @app.errorhandler(AuthenticationError)
    def authentication_error(error: AuthenticationError) -> tuple[Response, int]:
        code = "authentication_required" if error.status_code == 401 else "invalid_session"
        return jsonify({"error": code, "message": str(error)}), error.status_code

    @app.errorhandler(QueueCapacityError)
    def queue_capacity_error(error: QueueCapacityError) -> tuple[Response, int]:
        return jsonify({"error": "analysis_queue_capacity", "message": str(error)}), 429

    @app.errorhandler(IngestionValidationError)
    def ingestion_validation_error(error: IngestionValidationError) -> tuple[Response, int]:
        payload: dict[str, Any] = {"error": "ingestion_validation_error", "message": str(error)}
        if error.diagnostics:
            payload["diagnostics"] = error.diagnostics
        return jsonify(payload), 400

    @app.errorhandler(UploadStagingError)
    def staged_upload_error(error: UploadStagingError) -> tuple[Response, int]:
        return jsonify({"error": "package_upload_error", "message": str(error)}), 400

    @app.errorhandler(StorageUnavailable)
    def storage_unavailable(error: StorageUnavailable) -> tuple[Response, int]:
        return jsonify({"error": "storage_unavailable", "message": str(error)}), 503

    @app.errorhandler(PersistenceUnavailable)
    def persistence_unavailable(error: PersistenceUnavailable) -> tuple[Response, int]:
        return jsonify({"error": "persistence_unavailable", "message": str(error)}), 503

    @app.errorhandler(SourceDatasetRequired)
    def source_data_required(error: SourceDatasetRequired) -> tuple[Response, int]:
        return jsonify({"error": "source_data_required", "message": str(error)}), 409

    @app.errorhandler(413)
    def payload_too_large(_: Exception) -> tuple[Response, int]:
        return jsonify({"error": "payload_too_large", "message": f"Maximum request size is {app.config['MAX_CONTENT_LENGTH']:,} bytes."}), 413

    @app.errorhandler(HTTPException)
    def http_error(error: HTTPException) -> Response | tuple[Response, int]:
        if request.path.startswith("/api/"):
            return jsonify({"error": error.name.lower().replace(" ", "_"), "message": error.description}), error.code
        return error

    @app.get("/api/health")
    def health() -> Response:
        return jsonify({"status": "ok", "service": "WaferMap Flask API", "frontend_build_available": Path(app.config["FRONTEND_DIST"]).is_dir(), "persistence_available": repository is not None})

    def require_analysis_runtime() -> tuple[Any, Any]:
        identity = require_authenticated_identity(current_app)
        if repository is None or executor is None:
            raise PersistenceUnavailable("Analysis queue persistence is not configured for this environment.")
        return identity, repository

    def require_retained_source_runtime() -> tuple[Any, Any]:
        identity = require_authenticated_identity(current_app)
        if repository is None:
            raise PersistenceUnavailable("Retained source persistence is not configured for this environment.")
        return identity, repository

    def drain_one_analysis_job() -> None:
        # Exactly one claim attempt; AnalysisQueueExecutor never loops or starts background work.
        assert executor is not None
        executor.execute_at_most_one()

    @app.post("/api/analysis/jobs")
    def create_analysis_job() -> tuple[Response, int]:
        identity, queue_repository = require_analysis_runtime()
        payload = _read_payload()
        allowed = {"cp_dataset_id", "wat_dataset_id", "kla_dataset_id"}
        unknown = sorted(set(payload) - allowed)
        if unknown:
            raise RequestValidationError(f"Unsupported analysis request fields: {', '.join(unknown)}.")
        cp_dataset_id = _positive_dataset_id(payload, "cp_dataset_id", required=True)
        wat_dataset_id = _positive_dataset_id(payload, "wat_dataset_id", required=False)
        kla_dataset_id = _positive_dataset_id(payload, "kla_dataset_id", required=False)
        assert cp_dataset_id is not None
        try:
            source_references = queue_repository.validate_analysis_sources(
                cp_dataset_id,
                wat_dataset_id=wat_dataset_id,
                kla_dataset_id=kla_dataset_id,
                minimum_cp_measurements=int(app.config["ANALYSIS_MIN_CP_MEASUREMENTS"]),
                owner_open_id=identity.open_id,
            )
        except OwnedDatasetNotFound as exc:
            abort(404, description=str(exc))
        except ValueError as exc:
            raise RequestValidationError(str(exc)) from exc
        manifest = build_request_manifest(cp_dataset_id, wat_dataset_id, kla_dataset_id, source_references)
        job = queue_repository.enqueue_analysis_job(
            identity.open_id,
            identity.name,
            cp_dataset_id,
            wat_dataset_id=wat_dataset_id,
            kla_dataset_id=kla_dataset_id,
            request_manifest=manifest,
            request_version=REQUEST_MANIFEST_VERSION,
            owner_active_cap=int(app.config["ANALYSIS_OWNER_ACTIVE_CAP"]),
            global_backlog_cap=int(app.config["ANALYSIS_GLOBAL_BACKLOG_CAP"]),
        )
        drain_one_analysis_job()
        current = queue_repository.analysis_job_for_owner(int(job["id"]), identity.open_id) or job
        return jsonify({"job": current, "execution": {"mode": "REQUEST_DRIVEN", "max_claims_this_request": 1}}), 202

    @app.get("/api/analysis/jobs")
    def list_analysis_jobs() -> Response:
        identity, queue_repository = require_analysis_runtime()
        drain_one_analysis_job()
        return jsonify({
            "jobs": queue_repository.analysis_jobs_for_owner(identity.open_id, _bounded_query_limit()),
            "queue": {"execution_mode": "REQUEST_DRIVEN", "global_concurrency": 1, "max_claims_this_request": 1},
        })

    @app.get("/api/analysis/jobs/<int:job_id>")
    def get_analysis_job(job_id: int) -> Response:
        identity, queue_repository = require_analysis_runtime()
        drain_one_analysis_job()
        job = queue_repository.analysis_job_for_owner(job_id, identity.open_id)
        if job is None:
            abort(404, description="Analysis job was not found.")
        return jsonify({"job": job})

    @app.get("/api/analysis/reports")
    def list_analysis_reports() -> Response:
        identity, queue_repository = require_analysis_runtime()
        return jsonify({"reports": queue_repository.analysis_reports_for_owner(identity.open_id, _bounded_query_limit())})

    @app.get("/api/analysis/reports/<int:report_id>")
    def get_analysis_report(report_id: int) -> Response:
        identity, queue_repository = require_analysis_runtime()
        report = queue_repository.analysis_report_for_owner(report_id, identity.open_id)
        if report is None:
            abort(404, description="Analysis report was not found.")
        return jsonify({"report": report})

    @app.get("/api/analysis/reports/<int:report_id>/download")
    def download_analysis_report(report_id: int) -> Response:
        identity, queue_repository = require_analysis_runtime()
        report = queue_repository.analysis_report_for_owner(report_id, identity.open_id)
        if report is None:
            abort(404, description="Analysis report was not found.")
        content = json.dumps(
            report["payload"],
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
            allow_nan=False,
        ).encode("utf-8")
        response = Response(content, content_type="application/json; charset=utf-8")
        response.headers.set("Content-Disposition", "attachment", filename=report["filename"])
        return response

    @app.get("/api/wafer/default")
    def default_wafer() -> Response:
        return jsonify(WaferEngine.generate_wafer_layout(WaferConfig(), DieConfig()))

    @app.post("/api/wafer/calculate")
    def calculate_wafer() -> Response:
        payload = _read_payload()
        _reject_geometry_persistence(payload)
        wafer_config, die_config = _build_configs(payload)
        layout = WaferEngine.generate_wafer_layout(wafer_config, die_config)
        return jsonify({"layout": layout, "spatial": WaferEngine.calculate_spatial_analytics(layout)})

    @app.post("/api/wafer/optimize-shot")
    @app.post("/api/wafer/grid-search-center-offset")
    def grid_search_center_offset() -> Response:
        payload = _read_payload()
        _reject_geometry_persistence(payload)
        wafer_config, die_config = _build_configs(payload)
        grid_steps = _integer(payload, "grid_steps", 20, minimum=4, maximum=100)
        response = jsonify(WaferEngine.grid_search_center_offset(wafer_config, die_config, grid_steps))
        if request.path.endswith("/optimize-shot"):
            response.headers["Deprecation"] = "true"
            response.headers["Link"] = '</api/wafer/grid-search-center-offset>; rel="successor-version"'
        return response

    def export_response(export_format: str, mimetype: str) -> Response:
        payload = _read_payload()
        _reject_geometry_persistence(payload)
        wafer_config, die_config = _build_configs(payload)
        layout = WaferEngine.generate_wafer_layout(wafer_config, die_config)
        content = WaferEngine.export_semi_e142_xml(layout) if export_format == "semi_e142" else WaferEngine.export_semi_g85_map(layout)
        response = Response(content, mimetype=mimetype)
        return response

    @app.post("/api/wafer/export/semi-e142")
    def export_e142() -> Response:
        return export_response("semi_e142", "application/xml; charset=utf-8")

    @app.post("/api/wafer/export/semi-g85")
    def export_g85() -> Response:
        return export_response("semi_g85", "text/plain; charset=utf-8")

    @app.get("/api/sessions/recent")
    def recent_sessions() -> Response:
        if repository is None:
            return jsonify({"sessions": [], "persistence_available": False})
        limit = min(max(int(request.args.get("limit", "12")), 1), 50)
        return jsonify({"sessions": repository.recent_sessions(limit), "persistence_available": True})

    @app.post("/api/ingestion/upload")
    def upload_ingestion_file() -> Response:
        identity, ingestion_repository = require_retained_source_runtime()
        if storage is None:
            raise StorageUnavailable("Managed source-file storage is not configured for this environment.")
        owner_id = ingestion_repository.ensure_owner(identity.open_id, identity.name)
        source_type = str(request.form.get("source_type", "")).strip().upper()
        source_file = request.files.get("file")
        if source_file is None or not source_file.filename:
            raise IngestionValidationError("Attach one CP, WAT, or KLA .csv/.xlsx source file.")
        filename = Path(source_file.filename).name
        content = source_file.read(app.config["INGESTION_MAX_FILE_BYTES"] + 1)
        if len(content) > app.config["INGESTION_MAX_FILE_BYTES"]:
            raise IngestionValidationError(f"Source file exceeds the configured {app.config['INGESTION_MAX_FILE_BYTES']:,}-byte limit.")
        if not content:
            raise IngestionValidationError("Source file is empty.")
        source_hash = hashlib.sha256(content).hexdigest()
        import_run_id = ingestion_repository.start_import_run(source_type, filename, source_hash, owner_id=owner_id)
        try:
            parsed = parse_ingestion_file(source_type, filename, content)
            # Source PRODUCT_ID is authoritative. WAT/KLA intentionally remain
            # explicit UNAVAILABLE rather than accepting a UI-invented product.
            content_type = "text/csv" if filename.lower().endswith(".csv") else "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            stored = storage.put(filename, content, content_type)
            result = ingestion_repository.save_ingestion_dataset(source_type, parsed, stored, source_hash, len(content), import_run_id=import_run_id, owner_id=owner_id)
            ingestion_repository.finish_import_run(import_run_id, "COMPLETED", {"dataset_id": result["dataset_id"], "valid_rows": parsed["summary"]["valid_rows"], "error_rows": parsed["summary"]["error_rows"]})
            return jsonify({"dataset": result}), 201
        except (IngestionValidationError, StorageUnavailable, PersistenceUnavailable) as error:
            ingestion_repository.finish_import_run(import_run_id, "REJECTED", {"error": str(error)[:512]})
            raise

    def _staged_upload_token() -> str:
        token = str(request.headers.get("X-WaferMap-Upload-Token", "")).strip()
        if not token or len(token) > 256:
            raise UploadStagingError("A valid staged upload token is required.")
        return token

    def _close_package_files(package_files: dict[str, Any]) -> None:
        for upload in package_files.values():
            try:
                upload.close()
            except Exception:
                pass

    @app.post("/api/ingestion/package-sessions")
    def create_package_upload_session() -> Response:
        """Create a short-lived metadata-only session for gateway-safe chunk uploads."""
        payload = _read_payload()
        session = upload_manager.create(payload.get("source_type", ""), payload.get("files"))
        return jsonify(session), 201

    @app.post("/api/ingestion/package-sessions/<session_id>/chunks")
    def receive_package_upload_chunk(session_id: str) -> Response:
        """Accept one bounded, sequential CSV chunk; no source rows are echoed."""
        result = upload_manager.receive_chunk(
            session_id,
            _staged_upload_token(),
            role=str(request.form.get("role", "")),
            chunk_index=request.form.get("chunk_index", ""),
            total_chunks=request.form.get("total_chunks", ""),
            upload=request.files.get("chunk"),
        )
        return jsonify(result)

    @app.get("/api/ingestion/package-sessions/<session_id>")
    def package_upload_session_status(session_id: str) -> Response:
        return jsonify(upload_manager.session_metadata(session_id, _staged_upload_token()))

    @app.delete("/api/ingestion/package-sessions/<session_id>")
    def abandon_package_upload_session(session_id: str) -> Response:
        upload_manager.abandon(session_id, _staged_upload_token())
        return Response(status=204)

    @app.post("/api/ingestion/package-sessions/<session_id>/validate")
    def validate_staged_ingestion_package(session_id: str) -> Response:
        """Run the same package validator after all small chunks have completed."""
        source_type, package_files = upload_manager.completed_file_storages(session_id, _staged_upload_token())
        try:
            result = validate_ingestion_package(
                source_type,
                package_files,
                max_file_bytes=int(app.config["INGESTION_MAX_FILE_BYTES"]),
                max_rows=int(app.config["INGESTION_MAX_ROWS"]),
            )
            return jsonify(result), 200 if result["valid"] else 422
        finally:
            _close_package_files(package_files)

    @app.post("/api/ingestion/package-sessions/<session_id>/persist")
    def persist_staged_ingestion_package(session_id: str) -> Response:
        """Revalidate and persist one selected partition from staged source files."""
        identity, ingestion_repository = require_retained_source_runtime()
        if storage is None:
            raise StorageUnavailable("Managed source-file storage is not configured for this environment.")
        payload = _read_payload()
        selected_lot_id = str(payload.get("selected_lot_id", "")).strip()
        selected_wafer_id = str(payload.get("selected_wafer_id", "")).strip()
        if not selected_lot_id or not selected_wafer_id:
            raise IngestionValidationError("selected_lot_id and selected_wafer_id are required; one explicit partition is persisted per request.")
        token = _staged_upload_token()
        source_type, package_files = upload_manager.completed_file_storages(session_id, token)
        owner_id = ingestion_repository.ensure_owner(identity.open_id, identity.name)
        audit_filename, audit_hash = _package_request_audit_identity(source_type, package_files)
        import_run_id = ingestion_repository.start_import_run(source_type, audit_filename, audit_hash, owner_id=owner_id)
        try:
            package, parsed = parse_ingestion_package_partition(
                source_type,
                package_files,
                selected_lot_id,
                selected_wafer_id,
                max_file_bytes=int(app.config["INGESTION_MAX_FILE_BYTES"]),
                max_rows=int(app.config["INGESTION_MAX_ROWS"]),
            )
            retained_files: list[dict[str, Any]] = []
            for file_meta in package["files"]:
                role = file_meta["role"]
                upload = package_files[role]
                upload.stream.seek(0)
                content = upload.stream.read(int(app.config["INGESTION_MAX_FILE_BYTES"]) + 1)
                upload.stream.seek(0)
                if len(content) != file_meta["byte_size"] or hashlib.sha256(content).hexdigest() != file_meta["checksum_sha256"]:
                    raise IngestionValidationError(f"File role '{role}' changed after validation; nothing was persisted.")
                stored = storage.put(file_meta["filename"], content, "text/csv")
                retained_files.append({
                    "role": role,
                    "filename": file_meta["filename"],
                    "byte_size": file_meta["byte_size"],
                    "checksum_sha256": file_meta["checksum_sha256"],
                    "storage_key": stored["key"],
                    "storage_url": stored["url"],
                })
            primary_storage = next(item for item in retained_files if item["role"] == package["primary_role"])
            storage_reference = {"key": primary_storage["storage_key"], "url": primary_storage["storage_url"]}
            parsed["summary"]["package_diagnostics"]["retained_files"] = [
                {key: value for key, value in item.items() if key != "storage_url"}
                for item in retained_files
            ]
            parsed["summary"]["package_diagnostics"]["package_byte_size"] = sum(int(item["byte_size"]) for item in retained_files)
            result = ingestion_repository.save_ingestion_dataset(
                source_type,
                parsed,
                storage_reference,
                primary_storage["checksum_sha256"],
                int(primary_storage["byte_size"]),
                import_run_id=import_run_id,
                owner_id=owner_id,
            )
            ingestion_repository.finish_import_run(import_run_id, "COMPLETED", {
                "operation": "STAGED_PACKAGE_PARTITION_PERSIST",
                "dataset_id": result["dataset_id"],
                "selected_partition": {"lot_id": selected_lot_id, "wafer_id": selected_wafer_id},
                "source_package_partition_count": package["partition_count"],
                "retained_roles": [item["role"] for item in retained_files],
                "valid_rows": parsed["summary"]["valid_rows"],
                "error_rows": parsed["summary"]["error_rows"],
                "correlation_ready": False,
                "correlation_note": "LOT_ID/WAFER_ID equality alone does not establish cross-source correlation readiness.",
            })
            safe_dataset = {key: value for key, value in result.items() if key != "storage_url"}
            upload_manager.consume(session_id, token)
            return jsonify({
                "status": "COMPLETED",
                "persistent": True,
                "import_run_id": import_run_id,
                "dataset": safe_dataset,
                "selected_partition": parsed["partition"],
                "package": {
                    "source_type": package["source_type"],
                    "source_package_partition_count": package["partition_count"],
                    "retained_roles": [item["role"] for item in retained_files],
                    "parser_mapping_version": package["parser_mapping_version"],
                },
                "correlation_ready": False,
                "correlation_note": "The dataset is source-backed, but LOT_ID/WAFER_ID equality alone does not establish cross-source correlation readiness.",
            }), 201
        except (IngestionValidationError, StorageUnavailable, PersistenceUnavailable) as error:
            ingestion_repository.finish_import_run(import_run_id, "REJECTED", {
                "operation": "STAGED_PACKAGE_PARTITION_PERSIST",
                "selected_partition": {"lot_id": selected_lot_id, "wafer_id": selected_wafer_id},
                "error_type": error.__class__.__name__,
                "error": str(error)[:512],
                "diagnostics": getattr(error, "diagnostics", [])[:10],
            })
            raise
        finally:
            _close_package_files(package_files)

    @app.post("/api/ingestion/packages/validate")
    @app.post("/api/ingestion/validate")
    def validate_ingestion_files() -> Response:
        """Stream-validate a real CP/WAT/KLA package and preview every wafer partition."""
        source_type = str(request.form.get("source_type", "")).strip().upper()
        duplicate_roles = sorted(role for role in request.files if len(request.files.getlist(role)) != 1)
        if duplicate_roles:
            raise IngestionValidationError(f"Each file role may be supplied once; duplicates: {', '.join(duplicate_roles)}.")
        package_files = {role: request.files[role] for role in request.files}
        result = validate_ingestion_package(
            source_type,
            package_files,
            max_file_bytes=int(app.config["INGESTION_MAX_FILE_BYTES"]),
            max_rows=int(app.config["INGESTION_MAX_ROWS"]),
        )
        return jsonify(result), 200 if result["valid"] else 422

    @app.post("/api/ingestion/packages/persist")
    def persist_ingestion_package() -> Response:
        """Persist one explicitly selected partition from a fully revalidated package."""
        identity, ingestion_repository = require_retained_source_runtime()
        if storage is None:
            raise StorageUnavailable("Managed source-file storage is not configured for this environment.")
        owner_id = ingestion_repository.ensure_owner(identity.open_id, identity.name)
        source_type = str(request.form.get("source_type", "")).strip().upper()
        if source_type not in {"CP", "WAT", "KLA"}:
            raise IngestionValidationError("source_type must be CP, WAT, or KLA.")
        selected_lot_id = str(request.form.get("selected_lot_id", "")).strip()
        selected_wafer_id = str(request.form.get("selected_wafer_id", "")).strip()
        if not selected_lot_id or not selected_wafer_id:
            raise IngestionValidationError("selected_lot_id and selected_wafer_id are required; one explicit partition is persisted per request.")
        duplicate_roles = sorted(role for role in request.files if len(request.files.getlist(role)) != 1)
        if duplicate_roles:
            raise IngestionValidationError(f"Each file role may be supplied once; duplicates: {', '.join(duplicate_roles)}.")
        package_files = {role: request.files[role] for role in request.files}
        audit_filename, audit_hash = _package_request_audit_identity(source_type, package_files)
        import_run_id = ingestion_repository.start_import_run(source_type, audit_filename, audit_hash, owner_id=owner_id)
        try:
            package, parsed = parse_ingestion_package_partition(
                source_type,
                package_files,
                selected_lot_id,
                selected_wafer_id,
                max_file_bytes=int(app.config["INGESTION_MAX_FILE_BYTES"]),
                max_rows=int(app.config["INGESTION_MAX_ROWS"]),
            )
            retained_files: list[dict[str, Any]] = []
            for file_meta in package["files"]:
                role = file_meta["role"]
                upload = package_files[role]
                upload.stream.seek(0)
                content = upload.stream.read(int(app.config["INGESTION_MAX_FILE_BYTES"]) + 1)
                upload.stream.seek(0)
                if len(content) != file_meta["byte_size"] or hashlib.sha256(content).hexdigest() != file_meta["checksum_sha256"]:
                    raise IngestionValidationError(f"File role '{role}' changed after validation; nothing was persisted.")
                stored = storage.put(file_meta["filename"], content, "text/csv")
                retained_files.append({
                    "role": role,
                    "filename": file_meta["filename"],
                    "byte_size": file_meta["byte_size"],
                    "checksum_sha256": file_meta["checksum_sha256"],
                    "storage_key": stored["key"],
                    "storage_url": stored["url"],
                })
            primary_storage = next(item for item in retained_files if item["role"] == package["primary_role"])
            storage_reference = {
                "key": primary_storage["storage_key"],
                "url": primary_storage["storage_url"],
            }
            parsed["summary"]["package_diagnostics"]["retained_files"] = [
                {key: value for key, value in item.items() if key != "storage_url"}
                for item in retained_files
            ]
            parsed["summary"]["package_diagnostics"]["package_byte_size"] = sum(
                int(item["byte_size"]) for item in retained_files
            )
            result = ingestion_repository.save_ingestion_dataset(
                source_type,
                parsed,
                storage_reference,
                primary_storage["checksum_sha256"],
                int(primary_storage["byte_size"]),
                import_run_id=import_run_id,
                owner_id=owner_id,
            )
            run_diagnostics = {
                "operation": "PACKAGE_PARTITION_PERSIST",
                "dataset_id": result["dataset_id"],
                "selected_partition": {"lot_id": selected_lot_id, "wafer_id": selected_wafer_id},
                "source_package_partition_count": package["partition_count"],
                "retained_roles": [item["role"] for item in retained_files],
                "valid_rows": parsed["summary"]["valid_rows"],
                "error_rows": parsed["summary"]["error_rows"],
                "correlation_ready": False,
                "correlation_note": "LOT_ID/WAFER_ID equality alone does not establish cross-source correlation readiness.",
            }
            ingestion_repository.finish_import_run(import_run_id, "COMPLETED", run_diagnostics)
            # The repository's legacy return includes a managed relative URL. Package
            # persistence intentionally returns only non-secret identifiers and lineage.
            safe_dataset = {key: value for key, value in result.items() if key != "storage_url"}
            return jsonify({
                "status": "COMPLETED",
                "persistent": True,
                "import_run_id": import_run_id,
                "dataset": safe_dataset,
                "selected_partition": parsed["partition"],
                "package": {
                    "source_type": package["source_type"],
                    "source_package_partition_count": package["partition_count"],
                    "retained_roles": [item["role"] for item in retained_files],
                    "parser_mapping_version": package["parser_mapping_version"],
                },
                "correlation_ready": False,
                "correlation_note": "The dataset is source-backed, but LOT_ID/WAFER_ID equality alone does not establish cross-source correlation readiness.",
            }), 201
        except (IngestionValidationError, StorageUnavailable, PersistenceUnavailable) as error:
            ingestion_repository.finish_import_run(import_run_id, "REJECTED", {
                "operation": "PACKAGE_PARTITION_PERSIST",
                "selected_partition": {"lot_id": selected_lot_id, "wafer_id": selected_wafer_id},
                "error_type": error.__class__.__name__,
                "error": str(error)[:512],
                "diagnostics": getattr(error, "diagnostics", [])[:10],
            })
            raise

    @app.get("/api/ingestion/datasets/<int:dataset_id>/overlay")
    def ingestion_overlay(dataset_id: int) -> Response:
        identity, ingestion_repository = require_retained_source_runtime()
        overlay = ingestion_repository.ingestion_overlay(dataset_id, identity.open_id)
        if overlay is None:
            abort(404, description="Ingestion dataset was not found.")
        return jsonify(overlay)

    @app.get("/api/ingestion/datasets/<int:dataset_id>/analysis")
    def ingestion_analysis(dataset_id: int) -> Response:
        identity, ingestion_repository = require_retained_source_runtime()
        try:
            result = ingestion_repository.ingestion_analysis(
                dataset_id,
                wat_dataset_id=_optional_dataset_query_id("wat_dataset_id"),
                kla_dataset_id=_optional_dataset_query_id("kla_dataset_id"),
                owner_open_id=identity.open_id,
            )
        except OwnedDatasetNotFound as exc:
            abort(404, description=str(exc))
        except ValueError as exc:
            raise RequestValidationError(str(exc)) from exc
        return jsonify(result)

    @app.get("/api/ingestion/recent")
    def recent_ingestion_datasets() -> Response:
        identity, ingestion_repository = require_retained_source_runtime()
        try:
            limit = min(max(int(request.args.get("limit", "12")), 1), 50)
        except ValueError as exc:
            raise RequestValidationError("'limit' must be an integer.") from exc
        return jsonify({"datasets": ingestion_repository.recent_ingestion_datasets(identity.open_id, limit), "persistence_available": True})

    @app.get("/api/ingestion/import-runs")
    def ingestion_import_runs() -> Response:
        """Return a bounded operator history without source rows, object locations, or owner identifiers."""
        identity, ingestion_repository = require_retained_source_runtime()
        return jsonify({
            "import_runs": ingestion_repository.import_runs_for_owner(identity.open_id, _bounded_query_limit()),
            "persistence_available": True,
        })

    @app.get("/api/ingestion/catalog")
    def ingestion_dataset_catalog() -> Response:
        identity, ingestion_repository = require_retained_source_runtime()
        try:
            limit = min(max(int(request.args.get("limit", "50")), 1), 50)
        except ValueError as exc:
            raise RequestValidationError("'limit' must be an integer.") from exc
        catalog = ingestion_repository.ingestion_dataset_catalog(
            owner_open_id=identity.open_id,
            source_types=_catalog_source_types(),
            lot_id=_catalog_text_query("lot_id"),
            wafer_id=_catalog_text_query("wafer_id"),
            product_id=_catalog_text_query("product_id"),
            limit=limit,
        )
        catalog["persistence_available"] = True
        return jsonify(catalog)

    @app.route("/", defaults={"asset_path": ""})
    @app.route("/<path:asset_path>")
    def serve_frontend(asset_path: str) -> Response | tuple[Response, int]:
        if asset_path.startswith("api/"):
            abort(404)
        frontend_dist = Path(app.config["FRONTEND_DIST"])
        if not frontend_dist.is_dir():
            return jsonify({"error": "frontend_not_built", "message": "Run 'pnpm run build' before starting the server."}), 503
        if asset_path and (frontend_dist / asset_path).is_file():
            return send_from_directory(frontend_dist, asset_path)
        return send_from_directory(frontend_dist, "index.html")

    return app


if __name__ == "__main__":
    host = os.environ.get("WAFERMAP_HOST", "127.0.0.1")
    port = int(os.environ.get("WAFERMAP_PORT", "5001"))
    create_app().run(host=host, port=port, debug=os.environ.get("WAFERMAP_DEBUG", "false").lower() == "true")
