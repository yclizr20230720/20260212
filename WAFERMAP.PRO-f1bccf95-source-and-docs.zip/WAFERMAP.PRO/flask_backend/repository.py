"""Small, dependency-light persistence layer for durable WaferMap audit records."""

from __future__ import annotations

import json
import math
import os
from collections import Counter
from contextlib import contextmanager
from typing import Any, Iterator
from urllib.parse import unquote, urlparse

import pymysql
from pymysql.cursors import DictCursor


class PersistenceUnavailable(RuntimeError):
    """Raised when a request explicitly requires persistence but no database is configured."""


class QueueCapacityError(RuntimeError):
    """Raised when an analysis enqueue would exceed a configured active-job cap."""


class OwnedDatasetNotFound(ValueError):
    """Raised when a retained dataset is absent from the authenticated owner's scope."""


class WaferRepository:
    """Persist and analyze normalized, source-backed CP/WAT/KLA datasets."""

    def __init__(self, database_url: str):
        parsed = urlparse(database_url)
        if parsed.scheme not in {"mysql", "mysql+pymysql"} or not parsed.hostname or not parsed.path:
            raise ValueError("DATABASE_URL must be a complete MySQL connection URL.")
        self.connection_kwargs = {
            "host": parsed.hostname,
            "port": parsed.port or 3306,
            "user": unquote(parsed.username or ""),
            "password": unquote(parsed.password or ""),
            "database": parsed.path.lstrip("/"),
            "charset": "utf8mb4",
            "cursorclass": DictCursor,
            "connect_timeout": 5,
            "read_timeout": 90,
            "write_timeout": 90,
            "autocommit": False,
        }

    @classmethod
    def from_environment(cls) -> "WaferRepository | None":
        database_url = os.environ.get("DATABASE_URL", "").strip()
        return cls(database_url) if database_url else None

    @contextmanager
    def _connection(self) -> Iterator[pymysql.connections.Connection]:
        connection = pymysql.connect(**self.connection_kwargs)
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    @staticmethod
    def _json(value: Any) -> str:
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False)

    @staticmethod
    def configuration_snapshot(request_payload: dict[str, Any]) -> dict[str, Any]:
        """Keep wafer/stepping settings separate from versioned reticle cell assignments."""
        reticle_keys = {"die_type_matrix", "reticle_cols", "reticle_rows", "persist", "view_mode"}
        return {key: value for key, value in request_payload.items() if key not in reticle_keys}

    @staticmethod
    def _matches_json(stored_value: Any, candidate: dict[str, Any] | list[list[str]]) -> bool:
        if isinstance(stored_value, str):
            try:
                stored_value = json.loads(stored_value)
            except json.JSONDecodeError:
                return False
        return stored_value == candidate

    def recent_sessions(self, limit: int = 12) -> list[dict[str, Any]]:
        """Do not expose legacy analysis snapshots that may contain generated data."""
        del limit
        return []

    def ensure_owner(self, open_id: str, name: str) -> int:
        """Map an authenticated OpenId to a stable users row without changing its role."""
        normalized_open_id = str(open_id).strip()
        normalized_name = str(name).strip()
        if not normalized_open_id or len(normalized_open_id) > 64 or not normalized_name or len(normalized_name) > 255:
            raise PersistenceUnavailable("The authenticated identity cannot be mapped to a persistence owner.")
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """INSERT INTO users (openId, name, role) VALUES (%s, %s, 'user')
                       ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id), name = VALUES(name)""",
                    (normalized_open_id, normalized_name),
                )
                owner_id = int(cursor.lastrowid or 0)
                if owner_id < 1:
                    cursor.execute("SELECT id FROM users WHERE openId = %s", (normalized_open_id,))
                    owner = cursor.fetchone()
                    owner_id = int((owner or {}).get("id") or 0)
                if owner_id < 1:
                    raise PersistenceUnavailable("The authenticated identity could not be mapped to a persistence owner.")
                return owner_id

    def save_ingestion_dataset(self, source_type: str, parsed: dict[str, Any], storage: dict[str, str], source_hash: str, byte_size: int, *, import_run_id: int, owner_id: int) -> dict[str, Any]:
        """Persist a source-file audit record and its normalized overlay points in bounded batches."""
        summary = parsed["summary"]
        records = parsed["records"]
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """INSERT INTO ingestion_datasets
                    (ownerId, importRunId, sourceType, waferId, lotId, productId, originalFilename, storageKey, storageUrl, sourceHash, sourceRole, parserMappingVersion, packageDiagnostics, productProvenance, byteSize, totalRows, validRows, errorRows, columnMapping, summary)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                    (
                        owner_id, import_run_id, source_type, summary["wafer_id"], summary["lot_id"], summary["product_name"],
                        summary["source_filename"], storage["key"], storage["url"], source_hash,
                        summary.get("source_role"), summary.get("parser_mapping_version"),
                        self._json(summary.get("package_diagnostics", {})), summary.get("product_provenance", "UNAVAILABLE"),
                        byte_size, summary["total_rows"], summary["valid_rows"], summary["error_rows"],
                        self._json(parsed["mapping"]), self._json(summary),
                    ),
                )
                dataset_id = int(cursor.lastrowid)
                if source_type == "CP":
                    statement = """INSERT INTO cp_die_measurements (datasetId, dieX, dieY, xMm, yMm, hardBin, binCode, binName, binQuality, paramName, paramValue, paramUnit, testFreqGhz, leakageUa) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
                    values = [(dataset_id, item["die_x"], item["die_y"], item["x_mm"], item["y_mm"], item.get("hard_bin"), item["bin_code"], item["bin_name"], item["bin_quality"], item["param_name"], item["param_value"], item["param_unit"], item["test_freq_ghz"], item["leakage_ua"]) for item in records]
                    parametric_statement = """INSERT INTO cp_parametric_measurements (datasetId, dieX, dieY, paramName, value, unit, specLow, specHigh, isOos) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"""
                    parametric_values = [
                        (dataset_id, item["die_x"], item["die_y"], item["param_name"], item["value"], item["unit"], item["spec_low"], item["spec_high"], item["is_oos"])
                        for item in parsed.get("parametric_records", [])
                    ]
                elif source_type == "WAT":
                    statement = """INSERT INTO wat_measurements (datasetId, siteId, dieX, dieY, xMm, yMm, paramName, paramId, value, unit, specLow, specTarget, specHigh, status, sourceStatus, module, paramGroup, testStructure, criticality) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
                    values = [(dataset_id, item["site_id"], item["die_x"], item["die_y"], item["x_mm"], item["y_mm"], item["param_name"], item.get("param_id"), item["value"], item["unit"], item["spec_low"], item["spec_target"], item["spec_high"], item["status"], "OOS" if item["status"] == "FAIL" else item["status"], item.get("module"), item.get("param_group"), item.get("test_structure"), item.get("criticality")) for item in records]
                else:
                    statement = """INSERT INTO kla_defects (datasetId, defectId, dieX, dieY, xMm, yMm, xRelUm, yRelUm, sizeUm, defectClass, classCode, classGroup, killerFlag, layer, inspectionTool, inspectionRecipe, inspectionStep, reticleShotId, clusterId, isRepeater) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
                    values = [(dataset_id, item["defect_id"], item["die_x"], item["die_y"], item["x_mm"], item["y_mm"], item.get("xrel_um"), item.get("yrel_um"), item["size_um"], item["defect_class"], item.get("class_code"), item.get("class_group"), item.get("killer_flag", False), item["layer"], item.get("inspection_tool"), item.get("inspection_recipe"), item.get("inspection_step"), item.get("reticle_shot_id"), item["cluster_id"], item["is_repeater"]) for item in records]
                for start in range(0, len(values), 1000):
                    cursor.executemany(statement, values[start : start + 1000])
                if source_type == "CP":
                    for start in range(0, len(parametric_values), 1000):
                        cursor.executemany(parametric_statement, parametric_values[start : start + 1000])
        return {"dataset_id": dataset_id, "import_run_id": import_run_id, "source_type": source_type, "summary": summary, "storage_url": storage["url"]}

    def start_import_run(self, source_type: str, filename: str, source_hash: str, *, owner_id: int) -> int:
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    "INSERT INTO import_runs (ownerId, sourceType, originalFilename, sourceHash, status) VALUES (%s, %s, %s, %s, 'PROCESSING')",
                    (owner_id, source_type, filename, source_hash),
                )
                return int(cursor.lastrowid)

    def finish_import_run(self, import_run_id: int, status: str, diagnostics: dict[str, Any]) -> None:
        if status not in {"COMPLETED", "REJECTED"}:
            raise ValueError("Import runs may only be completed or rejected.")
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    "UPDATE import_runs SET status = %s, diagnostics = %s, completedAt = NOW() WHERE id = %s",
                    (status, self._json(diagnostics), import_run_id),
                )

    @staticmethod
    def _safe_import_run_diagnostics(value: Any) -> dict[str, Any]:
        """Return bounded, allowlisted diagnostic metadata without source records or storage references."""
        if isinstance(value, str):
            try:
                value = json.loads(value)
            except json.JSONDecodeError:
                value = {}
        if not isinstance(value, dict):
            value = {}

        selected = value.get("selected_partition")
        selected_partition = None
        if isinstance(selected, dict):
            lot_id = selected.get("lot_id")
            wafer_id = selected.get("wafer_id")
            if isinstance(lot_id, str) and isinstance(wafer_id, str):
                selected_partition = {"lot_id": lot_id[:128], "wafer_id": wafer_id[:128]}

        retained_roles = value.get("retained_roles")
        if not isinstance(retained_roles, list):
            retained_roles = []
        source_roles = [str(role)[:64] for role in retained_roles if isinstance(role, str)][:12]

        raw_items = value.get("diagnostics")
        safe_items: list[dict[str, str]] = []
        if isinstance(raw_items, list):
            for item in raw_items[:10]:
                if not isinstance(item, dict):
                    continue
                code = item.get("code")
                role = item.get("role")
                severity = item.get("severity")
                safe_item = {
                    key: str(candidate)[:96]
                    for key, candidate in (("code", code), ("role", role), ("severity", severity))
                    if isinstance(candidate, str) and candidate
                }
                if safe_item:
                    safe_items.append(safe_item)

        counts: dict[str, int] = {}
        for key in ("valid_rows", "error_rows", "total_rows", "source_package_partition_count"):
            candidate = value.get(key)
            if isinstance(candidate, (int, float)) and not isinstance(candidate, bool):
                counts[key] = max(0, int(candidate))

        result: dict[str, Any] = {
            "operation": str(value.get("operation") or "SINGLE_SOURCE_IMPORT")[:64],
            "selected_partition": selected_partition,
            "source_roles": source_roles,
            "counts": counts,
            "diagnostic_codes": safe_items,
            "error_type": str(value.get("error_type") or "")[:96] or None,
            "has_error": bool(value.get("error") or value.get("error_type")),
        }
        return result

    def import_runs_for_owner(self, owner_open_id: str, limit: int = 50) -> list[dict[str, Any]]:
        """List only concise, owner-scoped import metadata suitable for the operator history UI."""
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """SELECT r.id, r.sourceType, r.originalFilename, r.sourceHash, r.status,
                              r.diagnostics, r.startedAt, r.completedAt,
                              d.id AS datasetId, d.lotId, d.waferId, d.productId,
                              d.totalRows, d.validRows, d.errorRows, d.byteSize
                       FROM import_runs r
                       JOIN users u ON u.id = r.ownerId
                       LEFT JOIN ingestion_datasets d ON d.importRunId = r.id
                       WHERE u.openId = %s
                       ORDER BY r.startedAt DESC, r.id DESC LIMIT %s""",
                    (owner_open_id, limit),
                )
                rows = cursor.fetchall()

        history: list[dict[str, Any]] = []
        for row in rows:
            safe_diagnostics = self._safe_import_run_diagnostics(row.get("diagnostics"))
            dataset_id = row.get("datasetId")
            dataset = None
            if dataset_id is not None:
                dataset = {
                    "id": int(dataset_id),
                    "lot_id": row.get("lotId"),
                    "wafer_id": row.get("waferId"),
                    "product_id": row.get("productId"),
                    "total_rows": int(row.get("totalRows") or 0),
                    "valid_rows": int(row.get("validRows") or 0),
                    "error_rows": int(row.get("errorRows") or 0),
                    "byte_size": int(row.get("byteSize") or 0),
                }
            history.append(
                {
                    "id": int(row["id"]),
                    "source_type": row["sourceType"],
                    "status": row["status"],
                    "original_filename": row["originalFilename"],
                    "source_hash": row["sourceHash"],
                    "started_at": row.get("startedAt"),
                    "completed_at": row.get("completedAt"),
                    "dataset": dataset,
                    **safe_diagnostics,
                }
            )
        return history

    def ingestion_overlay(self, dataset_id: int, owner_open_id: str) -> dict[str, Any] | None:
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """SELECT d.id, d.sourceType, d.waferId, d.lotId, d.productId, d.summary
                       FROM ingestion_datasets d JOIN users u ON u.id = d.ownerId
                       WHERE d.id = %s AND u.openId = %s""",
                    (dataset_id, owner_open_id),
                )
                dataset = cursor.fetchone()
                if not dataset:
                    return None
                source_type = dataset["sourceType"]
                if source_type == "CP":
                    cursor.execute("SELECT dieX, dieY, xMm, yMm, binCode, binQuality FROM cp_die_measurements WHERE datasetId = %s", (dataset_id,))
                    rows = cursor.fetchall()
                    columns = ["die_x", "die_y", "x_mm", "y_mm", "bin_code", "bin_quality"]
                    return {"dataset": {"id": dataset["id"], "source_type": source_type, "wafer_id": dataset["waferId"], "lot_id": dataset["lotId"], "product_id": dataset["productId"], "summary": json.loads(dataset["summary"]) if isinstance(dataset["summary"], str) else dataset["summary"]}, "columns": columns, "rows": [[row["dieX"], row["dieY"], row["xMm"], row["yMm"], row["binCode"], row["binQuality"]] for row in rows]}
                elif source_type == "WAT":
                    cursor.execute("SELECT siteId AS site_id, dieX AS die_x, dieY AS die_y, xMm AS x_mm, yMm AS y_mm, paramName AS param_name, value, unit, specLow AS spec_low, specTarget AS spec_target, specHigh AS spec_high, status FROM wat_measurements WHERE datasetId = %s", (dataset_id,))
                else:
                    cursor.execute("SELECT defectId AS defect_id, dieX AS die_x, dieY AS die_y, xMm AS x_mm, yMm AS y_mm, sizeUm AS size_um, defectClass AS defect_class, layer, clusterId AS cluster_id, isRepeater AS is_repeater FROM kla_defects WHERE datasetId = %s", (dataset_id,))
                summary = dataset["summary"]
                if isinstance(summary, str):
                    summary = json.loads(summary)
                return {"dataset": {"id": dataset["id"], "source_type": source_type, "wafer_id": dataset["waferId"], "lot_id": dataset["lotId"], "product_id": dataset["productId"], "summary": summary}, "records": list(cursor.fetchall())}

    @staticmethod
    def _dataset_reference(dataset: dict[str, Any]) -> dict[str, Any]:
        return {
            "id": int(dataset["id"]),
            "source_type": dataset["sourceType"],
            "wafer_id": dataset["waferId"],
            "lot_id": dataset["lotId"],
            "product_id": dataset["productId"],
            "product_provenance": dataset.get("productProvenance", "UNAVAILABLE"),
        }

    @staticmethod
    def _number_or_none(value: Any) -> float | None:
        return float(value) if value is not None else None

    @staticmethod
    def _cp_coordinate_results(rows: list[dict[str, Any]]) -> dict[tuple[int, int], str]:
        """Collapse CP rows to one conservative result per imported die coordinate."""
        results: dict[tuple[int, int], str] = {}
        for row in rows:
            coordinate = (int(row["die_x"]), int(row["die_y"]))
            quality = str(row.get("bin_quality") or "NULL").upper()
            previous = results.get(coordinate)
            if quality == "FAIL" or previous == "FAIL":
                results[coordinate] = "FAIL"
            elif quality == "PASS" or previous == "PASS":
                results[coordinate] = "PASS"
            else:
                results[coordinate] = "NULL"
        return results

    @staticmethod
    def _kla_coordinate_screening(
        cp_results: dict[tuple[int, int], str],
        defect_rows: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Return class-level event and unique-die overlap aggregates, never source rows."""
        grouped: dict[str, dict[str, Any]] = {}
        all_coordinates: set[tuple[int, int]] = set()
        for row in defect_rows:
            defect_class = str(row.get("defect_class") or "UNCLASSIFIED")
            coordinate = (int(row["die_x"]), int(row["die_y"]))
            all_coordinates.add(coordinate)
            group = grouped.setdefault(
                defect_class,
                {"total_defects": 0, "repeater_defects": 0, "coordinates": set()},
            )
            group["total_defects"] += 1
            group["repeater_defects"] += int(bool(row.get("is_repeater")))
            group["coordinates"].add(coordinate)

        correlations: list[dict[str, Any]] = []
        for defect_class, group in grouped.items():
            affected_coordinates = group["coordinates"]
            matched_coordinates = affected_coordinates.intersection(cp_results)
            failure_coordinates = {
                coordinate for coordinate in matched_coordinates if cp_results[coordinate] == "FAIL"
            }
            matched_die_count = len(matched_coordinates)
            killed_dies = len(failure_coordinates)
            correlations.append(
                {
                    "defect_class": defect_class,
                    "total_defects": group["total_defects"],
                    "distinct_affected_dies": len(affected_coordinates),
                    # Kept for existing clients; this is a unique affected-die count.
                    "affected_dies": len(affected_coordinates),
                    "matched_cp_dies": matched_die_count,
                    "unmatched_affected_dies": len(affected_coordinates) - matched_die_count,
                    # Kept for UI compatibility; this means CP failure-coordinate overlap.
                    "killed_dies": killed_dies,
                    "kill_ratio_pct": round(
                        (killed_dies / len(affected_coordinates) * 100) if affected_coordinates else 0.0,
                        2,
                    ),
                    "repeater_defects": group["repeater_defects"],
                }
            )
        correlations.sort(
            key=lambda item: (-item["killed_dies"], -item["total_defects"], item["defect_class"])
        )
        matched_coordinates = all_coordinates.intersection(cp_results)
        return {
            "rows": correlations,
            "source_coordinate_die_count": len(all_coordinates),
            "matched_die_count": len(matched_coordinates),
            "unmatched_die_count": len(all_coordinates) - len(matched_coordinates),
        }

    @staticmethod
    def _wat_coordinate_screening(
        cp_results: dict[tuple[int, int], str],
        measurement_rows: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Screen WAT parameters against unique CP die coordinates without causal inference."""
        grouped: dict[tuple[str, str], dict[str, Any]] = {}
        all_coordinates: set[tuple[int, int]] = set()
        for row in measurement_rows:
            param_name = str(row.get("param_name") or "UNCLASSIFIED")
            unit = str(row.get("unit") or "")
            coordinate = (int(row["die_x"]), int(row["die_y"]))
            all_coordinates.add(coordinate)
            group = grouped.setdefault(
                (param_name, unit),
                {
                    "values": [],
                    "coordinates": set(),
                    "measurement_count": 0,
                    "matched_measurement_count": 0,
                    "oos_measurement_count": 0,
                },
            )
            group["measurement_count"] += 1
            group["coordinates"].add(coordinate)
            if coordinate in cp_results:
                group["matched_measurement_count"] += 1
            if row.get("value") is not None:
                group["values"].append(float(row["value"]))
            group["oos_measurement_count"] += int(
                str(row.get("source_status") or "").upper() == "OOS"
                or str(row.get("status") or "").upper() == "FAIL"
            )

        screening: list[dict[str, Any]] = []
        for (param_name, unit), group in grouped.items():
            source_coordinates = group["coordinates"]
            matched_coordinates = source_coordinates.intersection(cp_results)
            failed_coordinates = {
                coordinate for coordinate in matched_coordinates if cp_results[coordinate] == "FAIL"
            }
            passed_coordinates = {
                coordinate for coordinate in matched_coordinates if cp_results[coordinate] == "PASS"
            }
            matched_die_count = len(matched_coordinates)
            failure_count = len(failed_coordinates)
            pass_count = len(passed_coordinates)
            screening.append(
                {
                    "param_name": param_name,
                    "unit": unit,
                    "measurement_count": group["measurement_count"],
                    "source_die_count": len(source_coordinates),
                    "matched_die_count": matched_die_count,
                    "unmatched_die_count": len(source_coordinates) - matched_die_count,
                    "matched_measurement_count": group["matched_measurement_count"],
                    "unmatched_measurement_count": group["measurement_count"] - group["matched_measurement_count"],
                    "cp_fail_die_count": failure_count,
                    "cp_pass_die_count": pass_count,
                    "cp_failure_rate_pct": round(
                        (failure_count / matched_die_count * 100) if matched_die_count else 0.0,
                        2,
                    ),
                    "cp_pass_rate_pct": round(
                        (pass_count / matched_die_count * 100) if matched_die_count else 0.0,
                        2,
                    ),
                    "coordinate_coverage_pct": round(
                        (matched_die_count / len(source_coordinates) * 100) if source_coordinates else 0.0,
                        2,
                    ),
                    "oos_measurement_count": group["oos_measurement_count"],
                    "mean_wat_value": round(sum(group["values"]) / len(group["values"]), 6)
                    if group["values"]
                    else None,
                    "screening_indicator": "CP_FAILURE_OVERLAP_PRESENT"
                    if failure_count
                    else "NO_CP_FAILURE_OVERLAP"
                    if matched_die_count
                    else "NO_DIRECT_COORDINATE_OVERLAP",
                }
            )
        screening.sort(key=lambda item: (item["param_name"], item["unit"]))
        matched_coordinates = all_coordinates.intersection(cp_results)
        return {
            "rows": screening,
            "source_coordinate_die_count": len(all_coordinates),
            "matched_die_count": len(matched_coordinates),
            "unmatched_die_count": len(all_coordinates) - len(matched_coordinates),
        }

    @staticmethod
    def _correlation_status(
        wat_dataset: dict[str, Any] | None,
        wat_overlap_dies: int,
        kla_dataset: dict[str, Any] | None,
        kla_overlap_dies: int,
    ) -> tuple[bool, list[str], list[str]]:
        """Describe readiness for bounded coordinate screening, not physical correlation."""
        ready = wat_overlap_dies > 0 or kla_overlap_dies > 0
        reasons: list[str] = []
        caveats: list[str] = []
        if ready:
            reasons.append(
                "At least one selected WAT or KLA source has a direct DIE_X/DIE_Y overlap with CP for the same LOT_ID and WAFER_ID."
            )
        elif wat_dataset is None and kla_dataset is None:
            reasons.append("No secondary WAT or KLA dataset was selected for coordinate screening.")
        else:
            if wat_dataset is not None and wat_overlap_dies == 0:
                reasons.append("The matching WAT source has zero direct DIE_X/DIE_Y overlap with CP.")
            if kla_dataset is not None and kla_overlap_dies == 0:
                reasons.append("The matching KLA source has zero direct DIE_X/DIE_Y overlap with CP.")

        for label, dataset in (("WAT", wat_dataset), ("KLA", kla_dataset)):
            if dataset is None:
                continue
            if str(dataset.get("productId") or "").upper() == "UNAVAILABLE":
                caveats.append(
                    f"{label} PRODUCT_ID is unavailable; compatibility and screening use source LOT_ID and WAFER_ID only."
                )
            elif dataset.get("productProvenance") != "SOURCE":
                caveats.append(
                    f"{label} PRODUCT_ID source provenance is unavailable; compatibility and screening use source LOT_ID and WAFER_ID only."
                )
        if wat_dataset is not None or kla_dataset is not None:
            caveats.append(
                "DIE_X/DIE_Y equality is a source-coordinate screening key only; no physical coordinate-frame transform has been verified, and overlap does not establish causation."
            )
        return ready, reasons, caveats

    @staticmethod
    def _dataset_for_source(cursor: Any, dataset_id: int, source_type: str, owner_open_id: str) -> dict[str, Any]:
        cursor.execute(
            """SELECT d.id, d.sourceType, d.waferId, d.lotId, d.productId, d.productProvenance
               FROM ingestion_datasets d JOIN users u ON u.id = d.ownerId
               WHERE d.id = %s AND d.sourceType = %s AND u.openId = %s""",
            (dataset_id, source_type, owner_open_id),
        )
        dataset = cursor.fetchone()
        if not dataset:
            raise OwnedDatasetNotFound("Ingestion dataset was not found.")
        return dataset

    @staticmethod
    def _running_analysis_owner(
        cursor: Any,
        cp_dataset_id: int,
        wat_dataset_id: int | None,
        kla_dataset_id: int | None,
    ) -> str:
        """Resolve the owner only from the single durable RUNNING job being executed."""
        cursor.execute(
            """SELECT ownerOpenId FROM analysis_jobs
               WHERE status = 'RUNNING' AND cpDatasetId = %s
                 AND watDatasetId <=> %s AND klaDatasetId <=> %s
               ORDER BY startedAt ASC, id ASC LIMIT 2""",
            (cp_dataset_id, wat_dataset_id, kla_dataset_id),
        )
        rows = list(cursor.fetchall())
        if len(rows) != 1 or not rows[0].get("ownerOpenId"):
            raise ValueError("Analysis execution requires one owner-scoped running job.")
        return str(rows[0]["ownerOpenId"])

    @staticmethod
    def _matching_dataset_identity(primary: dict[str, Any], candidate: dict[str, Any]) -> tuple[bool, str | None]:
        mismatched_fields = [
            label
            for label, key in (("lot", "lotId"), ("wafer", "waferId"))
            if primary.get(key) != candidate.get(key)
        ]
        if not mismatched_fields:
            return True, None
        return False, f"Selected datasets do not share the same {', '.join(mismatched_fields)} identity."

    def ingestion_analysis(self, cp_dataset_id: int, *, wat_dataset_id: int | None = None, kla_dataset_id: int | None = None, owner_open_id: str | None = None) -> dict[str, Any]:
        """Aggregate existing normalized measurements without fabricating manufacturing data."""
        with self._connection() as connection:
            with connection.cursor() as cursor:
                scoped_owner_open_id = owner_open_id or self._running_analysis_owner(
                    cursor, cp_dataset_id, wat_dataset_id, kla_dataset_id
                )
                cp_dataset = self._dataset_for_source(cursor, cp_dataset_id, "CP", scoped_owner_open_id)
                cursor.execute(
                    """SELECT COUNT(*) AS total_dies,
                              SUM(CASE WHEN binQuality = 'PASS' THEN 1 ELSE 0 END) AS pass_dies,
                              SUM(CASE WHEN binQuality = 'FAIL' THEN 1 ELSE 0 END) AS fail_dies
                       FROM cp_die_measurements WHERE datasetId = %s""",
                    (cp_dataset_id,),
                )
                cp_totals = cursor.fetchone() or {}
                total_dies = int(cp_totals.get("total_dies") or 0)
                pass_dies = int(cp_totals.get("pass_dies") or 0)
                fail_dies = int(cp_totals.get("fail_dies") or 0)
                cursor.execute(
                    """SELECT dieX AS die_x, dieY AS die_y, binQuality AS bin_quality
                       FROM cp_die_measurements WHERE datasetId = %s""",
                    (cp_dataset_id,),
                )
                cp_coordinate_results = self._cp_coordinate_results(list(cursor.fetchall()))
                cursor.execute(
                    """SELECT binCode AS bin_code,
                              COALESCE(NULLIF(MAX(binName), ''), CONCAT('BIN_', binCode)) AS bin_name,
                              MAX(binQuality) AS bin_quality,
                              COUNT(*) AS count
                       FROM cp_die_measurements
                       WHERE datasetId = %s
                       GROUP BY binCode
                       ORDER BY count DESC, binCode ASC""",
                    (cp_dataset_id,),
                )
                running_percent = 0.0
                bins: list[dict[str, Any]] = []
                bin_distribution: list[dict[str, Any]] = []
                for row in cursor.fetchall():
                    count = int(row["count"])
                    bin_distribution.append(
                        {
                            "bin_code": int(row["bin_code"]),
                            "bin_name": row["bin_name"],
                            "bin_quality": row["bin_quality"],
                            "count": count,
                            "percent_of_total": round((count / total_dies * 100) if total_dies else 0.0, 2),
                        }
                    )
                    if row["bin_quality"] != "FAIL":
                        continue
                    percent = round((count / fail_dies * 100) if fail_dies else 0.0, 2)
                    running_percent = min(100.0, running_percent + percent)
                    bins.append(
                        {
                            "bin_code": int(row["bin_code"]),
                            "bin_name": row["bin_name"],
                            "count": count,
                            "percent_of_fails": percent,
                            "cumulative_percent": round(running_percent, 2),
                        }
                    )

                cursor.execute(
                    """SELECT paramName AS param_name, unit AS param_unit,
                              COUNT(*) AS measured_rows, AVG(value) AS mean_value,
                              STDDEV_POP(value) AS std_dev, MIN(value) AS min_value,
                              MAX(value) AS max_value,
                              SUM(CASE WHEN isOos = 1 THEN 1 ELSE 0 END) AS oos_count
                       FROM cp_parametric_measurements
                       WHERE datasetId = %s
                       GROUP BY paramName, unit
                       ORDER BY measured_rows DESC, param_name ASC, param_unit ASC
                       LIMIT 24""",
                    (cp_dataset_id,),
                )
                parametrics = [
                    {
                        "param_name": row["param_name"],
                        "param_unit": row["param_unit"],
                        "measured_rows": int(row["measured_rows"]),
                        "mean": round(self._number_or_none(row["mean_value"]), 6) if row["mean_value"] is not None else None,
                        "std_dev": round(self._number_or_none(row["std_dev"]), 6) if row["std_dev"] is not None else None,
                        "min": round(self._number_or_none(row["min_value"]), 6) if row["min_value"] is not None else None,
                        "max": round(self._number_or_none(row["max_value"]), 6) if row["max_value"] is not None else None,
                        "oos_count": int(row.get("oos_count") or 0),
                    }
                    for row in cursor.fetchall()
                ]

                # Coordinate-aware screening is deliberately computed from the imported
                # measurements only. It is not an ML classifier and does not infer a
                # fab tool or a causal mechanism from spatial proximity alone.
                radial_zone_order = ("Center 0–50 mm", "Middle 50–100 mm", "Edge 100–147 mm", "Outside 147 mm")
                radial_zones = {
                    label: {"zone": label, "total_dies": 0, "pass_dies": 0, "fail_dies": 0}
                    for label in radial_zone_order
                }
                scenario_edges = (0.0, 2.0, 3.0, 5.0, 7.0)
                scenarios = {
                    edge: {"edge_exclusion_mm": edge, "included_dies": 0, "pass_dies": 0, "fail_dies": 0}
                    for edge in scenario_edges
                }
                cursor.execute(
                    "SELECT xMm, yMm, binQuality FROM cp_die_measurements WHERE datasetId = %s",
                    (cp_dataset_id,),
                )
                for row in cursor.fetchall():
                    radius = math.hypot(float(row["xMm"]), float(row["yMm"]))
                    zone = "Center 0–50 mm" if radius < 50 else "Middle 50–100 mm" if radius < 100 else "Edge 100–147 mm" if radius <= 147 else "Outside 147 mm"
                    radial_zones[zone]["total_dies"] += 1
                    if row["binQuality"] == "PASS":
                        radial_zones[zone]["pass_dies"] += 1
                    elif row["binQuality"] == "FAIL":
                        radial_zones[zone]["fail_dies"] += 1
                    for edge, scenario in scenarios.items():
                        if radius <= 150.0 - edge:
                            scenario["included_dies"] += 1
                            if row["binQuality"] == "PASS":
                                scenario["pass_dies"] += 1
                            elif row["binQuality"] == "FAIL":
                                scenario["fail_dies"] += 1
                radial_zone_summary = [
                    {
                        **zone,
                        "yield_pct": round((zone["pass_dies"] / zone["total_dies"] * 100) if zone["total_dies"] else 0.0, 2),
                    }
                    for zone in (radial_zones[label] for label in radial_zone_order)
                ]
                observed_edge_scenarios = [
                    {
                        **scenario,
                        "excluded_dies": total_dies - scenario["included_dies"],
                        "yield_pct": round((scenario["pass_dies"] / scenario["included_dies"] * 100) if scenario["included_dies"] else 0.0, 2),
                    }
                    for scenario in (scenarios[edge] for edge in scenario_edges)
                ]

                cursor.execute(
                    """SELECT dieX, dieY, MAX(binCode) AS bin_code,
                              COALESCE(NULLIF(MAX(binName), ''), 'UNCLASSIFIED') AS bin_name
                       FROM cp_die_measurements
                       WHERE datasetId = %s AND binQuality = 'FAIL'
                       GROUP BY dieX, dieY""",
                    (cp_dataset_id,),
                )
                failed_coordinates = {
                    (int(row["dieX"]), int(row["dieY"])): {"bin_code": int(row["bin_code"]), "bin_name": row["bin_name"]}
                    for row in cursor.fetchall()
                }
                unvisited = set(failed_coordinates)
                cluster_rows: list[dict[str, Any]] = []
                isolated_failure_dies = 0
                component_count = 0
                while unvisited:
                    seed = unvisited.pop()
                    component = [seed]
                    stack = [seed]
                    while stack:
                        x, y = stack.pop()
                        for dx in (-1, 0, 1):
                            for dy in (-1, 0, 1):
                                if dx == 0 and dy == 0:
                                    continue
                                neighbor = (x + dx, y + dy)
                                if neighbor in unvisited:
                                    unvisited.remove(neighbor)
                                    stack.append(neighbor)
                                    component.append(neighbor)
                    component_count += 1
                    if len(component) < 2:
                        isolated_failure_dies += 1
                        continue
                    bins_in_component = Counter(failed_coordinates[key]["bin_code"] for key in component)
                    dominant_bin, dominant_count = bins_in_component.most_common(1)[0]
                    representative = next(value for key, value in failed_coordinates.items() if key in component and value["bin_code"] == dominant_bin)
                    xs = [key[0] for key in component]
                    ys = [key[1] for key in component]
                    cluster_rows.append(
                        {
                            "die_count": len(component),
                            "dominant_bin": dominant_bin,
                            "dominant_bin_name": representative["bin_name"],
                            "dominant_bin_count": dominant_count,
                            "die_x_min": min(xs),
                            "die_x_max": max(xs),
                            "die_y_min": min(ys),
                            "die_y_max": max(ys),
                        }
                    )
                cluster_rows.sort(key=lambda item: (-item["die_count"], item["dominant_bin"], item["die_x_min"], item["die_y_min"]))

                telemetry: list[dict[str, Any]] = []
                for column, label, unit in (("testFreqGhz", "Test frequency", "GHz"), ("leakageUa", "Leakage", "µA")):
                    cursor.execute(
                        f"""SELECT COUNT({column}) AS measured_rows, AVG({column}) AS mean_value,
                                    STDDEV_POP({column}) AS std_dev, MIN({column}) AS min_value, MAX({column}) AS max_value
                             FROM cp_die_measurements WHERE datasetId = %s AND {column} IS NOT NULL""",
                        (cp_dataset_id,),
                    )
                    telemetry_row = cursor.fetchone() or {}
                    measured_rows = int(telemetry_row.get("measured_rows") or 0)
                    telemetry.append(
                        {
                            "name": label,
                            "unit": unit,
                            "measured_rows": measured_rows,
                            "mean": round(self._number_or_none(telemetry_row["mean_value"]), 6) if telemetry_row.get("mean_value") is not None else None,
                            "std_dev": round(self._number_or_none(telemetry_row["std_dev"]), 6) if telemetry_row.get("std_dev") is not None else None,
                            "min": round(self._number_or_none(telemetry_row["min_value"]), 6) if telemetry_row.get("min_value") is not None else None,
                            "max": round(self._number_or_none(telemetry_row["max_value"]), 6) if telemetry_row.get("max_value") is not None else None,
                        }
                    )

                wat_dataset: dict[str, Any] | None = None
                wat_overlap_dies = 0
                wat: dict[str, Any] = {
                    "available": False,
                    "dataset": None,
                    "compatibility": {"status": "NOT_LOADED", "message": None},
                    "total_measurements": 0,
                    "fail_measurements": 0,
                    "parameters": [],
                    "coordinate_screening": [],
                    "coordinate_coverage": {"source_die_count": 0, "matched_die_count": 0, "unmatched_die_count": 0},
                }
                if wat_dataset_id is not None:
                    wat_dataset = self._dataset_for_source(cursor, wat_dataset_id, "WAT", scoped_owner_open_id)
                    matched, message = self._matching_dataset_identity(cp_dataset, wat_dataset)
                    if not matched:
                        raise ValueError(message or "Selected CP and WAT datasets are incompatible.")
                    cursor.execute(
                        """SELECT COUNT(*) AS total_measurements,
                                      SUM(CASE WHEN sourceStatus = 'OOS' OR status = 'FAIL' THEN 1 ELSE 0 END) AS fail_measurements
                           FROM wat_measurements WHERE datasetId = %s""",
                        (wat_dataset_id,),
                    )
                    wat_totals = cursor.fetchone() or {}
                    cursor.execute(
                        """SELECT paramName AS param_name, unit, COUNT(*) AS count,
                                      AVG(value) AS mean_value, STDDEV_POP(value) AS std_dev,
                                      MIN(specLow) AS spec_low, MAX(specHigh) AS spec_high,
                                      SUM(CASE WHEN sourceStatus = 'OOS' OR status = 'FAIL' THEN 1 ELSE 0 END) AS fail_count
                           FROM wat_measurements
                           WHERE datasetId = %s
                           GROUP BY paramName, unit
                           ORDER BY paramName ASC, unit ASC""",
                        (wat_dataset_id,),
                    )
                    parameters: list[dict[str, Any]] = []
                    for row in cursor.fetchall():
                        mean_value = self._number_or_none(row["mean_value"])
                        std_dev = self._number_or_none(row["std_dev"])
                        spec_low = self._number_or_none(row["spec_low"])
                        spec_high = self._number_or_none(row["spec_high"])
                        cp = cpk = None
                        if std_dev is not None and std_dev > 0 and spec_low is not None and spec_high is not None and spec_high > spec_low:
                            cp = round((spec_high - spec_low) / (6 * std_dev), 3)
                            cpu = (spec_high - mean_value) / (3 * std_dev) if mean_value is not None else None
                            cpl = (mean_value - spec_low) / (3 * std_dev) if mean_value is not None else None
                            if cpu is not None and cpl is not None:
                                cpk = round(min(cpu, cpl), 3)
                        parameters.append(
                            {
                                "param_name": row["param_name"],
                                "unit": row["unit"],
                                "count": int(row["count"]),
                                "mean": round(mean_value, 6) if mean_value is not None else None,
                                "std_dev": round(std_dev, 6) if std_dev is not None else None,
                                "spec_low": spec_low,
                                "spec_high": spec_high,
                                "cp": cp,
                                "cpk": cpk,
                                "oos_count": int(row["fail_count"] or 0),
                                "fail_count": int(row["fail_count"] or 0),
                            }
                        )
                    cursor.execute(
                        """SELECT dieX AS die_x, dieY AS die_y, paramName AS param_name,
                                  unit, value, status, sourceStatus AS source_status
                           FROM wat_measurements WHERE datasetId = %s""",
                        (wat_dataset_id,),
                    )
                    wat_coordinate_result = self._wat_coordinate_screening(
                        cp_coordinate_results, list(cursor.fetchall())
                    )
                    wat_overlap_dies = wat_coordinate_result["matched_die_count"]
                    wat = {
                        "available": True,
                        "dataset": self._dataset_reference(wat_dataset),
                        "compatibility": {"status": "IDENTITY_MATCHED", "message": "Source LOT_ID and WAFER_ID match the active CP dataset; WAT product provenance is not inferred."},
                        "total_measurements": int(wat_totals.get("total_measurements") or 0),
                        "oos_measurements": int(wat_totals.get("fail_measurements") or 0),
                        "fail_measurements": int(wat_totals.get("fail_measurements") or 0),
                        "parameters": parameters,
                        "coordinate_screening": wat_coordinate_result["rows"],
                        "coordinate_coverage": {
                            "source_die_count": wat_coordinate_result["source_coordinate_die_count"],
                            "matched_die_count": wat_coordinate_result["matched_die_count"],
                            "unmatched_die_count": wat_coordinate_result["unmatched_die_count"],
                        },
                    }

                kla_dataset: dict[str, Any] | None = None
                kla_overlap_dies = 0
                kla: dict[str, Any] = {
                    "available": False,
                    "dataset": None,
                    "compatibility": {"status": "NOT_LOADED", "message": None},
                    "total_defects": 0,
                    "repeater_defects": 0,
                    "correlations": [],
                    "coordinate_coverage": {"source_die_count": 0, "matched_die_count": 0, "unmatched_die_count": 0},
                }
                if kla_dataset_id is not None:
                    kla_dataset = self._dataset_for_source(cursor, kla_dataset_id, "KLA", scoped_owner_open_id)
                    matched, message = self._matching_dataset_identity(cp_dataset, kla_dataset)
                    if not matched:
                        raise ValueError(message or "Selected CP and KLA datasets are incompatible.")
                    cursor.execute(
                        """SELECT COUNT(*) AS total_defects,
                                      SUM(CASE WHEN isRepeater = 1 THEN 1 ELSE 0 END) AS repeater_defects,
                                      SUM(CASE WHEN killerFlag = 1 THEN 1 ELSE 0 END) AS killer_defects,
                                      AVG(sizeUm) AS mean_size_um, MIN(sizeUm) AS min_size_um, MAX(sizeUm) AS max_size_um
                           FROM kla_defects WHERE datasetId = %s""",
                        (kla_dataset_id,),
                    )
                    kla_totals = cursor.fetchone() or {}
                    cursor.execute(
                        """SELECT defectClass AS defect_class, classCode AS class_code, classGroup AS class_group,
                                      COUNT(*) AS total_defects,
                                      SUM(CASE WHEN killerFlag = 1 THEN 1 ELSE 0 END) AS killer_defects,
                                      AVG(sizeUm) AS mean_size_um
                           FROM kla_defects
                           WHERE datasetId = %s
                           GROUP BY defectClass, classCode, classGroup
                           ORDER BY total_defects DESC, defect_class ASC""",
                        (kla_dataset_id,),
                    )
                    class_statistics: list[dict[str, Any]] = []
                    for row in cursor.fetchall():
                        class_statistics.append(
                            {
                                "defect_class": row["defect_class"],
                                "class_code": row.get("class_code"),
                                "class_group": row.get("class_group"),
                                "total_defects": int(row["total_defects"]),
                                "killer_defects": int(row.get("killer_defects") or 0),
                                "mean_size_um": round(self._number_or_none(row["mean_size_um"]), 6) if row.get("mean_size_um") is not None else None,
                            }
                        )
                    cursor.execute(
                        """SELECT dieX AS die_x, dieY AS die_y, defectClass AS defect_class,
                                  isRepeater AS is_repeater
                           FROM kla_defects WHERE datasetId = %s""",
                        (kla_dataset_id,),
                    )
                    kla_coordinate_result = self._kla_coordinate_screening(
                        cp_coordinate_results, list(cursor.fetchall())
                    )
                    kla_overlap_dies = kla_coordinate_result["matched_die_count"]
                    kla = {
                        "available": True,
                        "dataset": self._dataset_reference(kla_dataset),
                        "compatibility": {"status": "IDENTITY_MATCHED", "message": "Source LOT_ID and WAFER_ID match the active CP dataset; coordinate-frame equivalence has not been proven."},
                        "total_defects": int(kla_totals.get("total_defects") or 0),
                        "repeater_defects": int(kla_totals.get("repeater_defects") or 0),
                        "killer_defects": int(kla_totals.get("killer_defects") or 0),
                        "size_um": {
                            "mean": round(self._number_or_none(kla_totals["mean_size_um"]), 6) if kla_totals.get("mean_size_um") is not None else None,
                            "min": round(self._number_or_none(kla_totals["min_size_um"]), 6) if kla_totals.get("min_size_um") is not None else None,
                            "max": round(self._number_or_none(kla_totals["max_size_um"]), 6) if kla_totals.get("max_size_um") is not None else None,
                        },
                        "class_statistics": class_statistics,
                        "correlations": kla_coordinate_result["rows"],
                        "coordinate_coverage": {
                            "source_die_count": kla_coordinate_result["source_coordinate_die_count"],
                            "matched_die_count": kla_coordinate_result["matched_die_count"],
                            "unmatched_die_count": kla_coordinate_result["unmatched_die_count"],
                        },
                    }

                primary_bin = bins[0] if bins else None
                clustered_failure_dies = sum(cluster["die_count"] for cluster in cluster_rows)
                evidence: list[dict[str, Any]] = []
                recommendations: list[str] = []
                if primary_bin is not None:
                    evidence.append({"category": "CP", "label": f"Primary detractor: bin {primary_bin['bin_code']}", "value": f"{primary_bin['count']:,} dies / {primary_bin['percent_of_fails']}% of failures", "detail": primary_bin["bin_name"]})
                    recommendations.append(f"Review the bin {primary_bin['bin_code']} disposition and the affected die coordinates before changing a test limit or process setting.")
                if clustered_failure_dies:
                    evidence.append({"category": "Spatial", "label": "Connected failure components", "value": f"{len(cluster_rows):,} multi-die components", "detail": f"{clustered_failure_dies:,} failed die coordinates are in components of two or more adjacent die sites."})
                    recommendations.append("Inspect the largest connected failure component against the wafer map; spatial adjacency is screening evidence, not a confirmed root cause.")
                if wat["available"]:
                    evidence.append({"category": "WAT", "label": "Imported WAT status", "value": f"{wat['fail_measurements']:,} out-of-spec measurements", "detail": "WAT limits and status are retained from the selected source."})
                    if wat["fail_measurements"]:
                        recommendations.append("Review WAT parameters marked FAIL alongside the CP fail-bin distribution before initiating an OCAP escalation.")
                if kla["available"] and kla["class_statistics"]:
                    top_class = kla["class_statistics"][0]
                    evidence.append({"category": "KLA", "label": f"Top defect class: {top_class['defect_class']}", "value": f"{top_class['total_defects']:,} defects", "detail": "Class statistics are retained event facts; direct die-coordinate overlap is reported separately as screening only."})
                    recommendations.append("Review KLA-to-CP DIE_X/DIE_Y overlap as a screening signal and verify the physical coordinate-frame transform before drawing process conclusions.")
                if not recommendations:
                    recommendations.append("No fail-bin excursion is present in the selected CP source. Retain the data lineage and continue normal monitoring.")
                ocap_status = "ATTENTION" if fail_dies and (fail_dies / total_dies * 100) >= 5 else "REVIEW" if fail_dies else "NOMINAL"
                correlation_ready, correlation_reasons, correlation_caveats = self._correlation_status(
                    wat_dataset,
                    wat_overlap_dies,
                    kla_dataset,
                    kla_overlap_dies,
                )

                return {
                    "correlation_ready": correlation_ready,
                    "correlation_reasons": correlation_reasons,
                    "correlation_caveats": correlation_caveats,
                    "cp": {
                        "dataset": self._dataset_reference(cp_dataset),
                        "total_dies": total_dies,
                        "pass_dies": pass_dies,
                        "fail_dies": fail_dies,
                        "yield_pct": round((pass_dies / total_dies * 100) if total_dies else 0.0, 2),
                        "bin_distribution": bin_distribution,
                        "bins": bins,
                        "parametrics": parametrics,
                        "spatial": {
                            "coordinate_note": "Radial zones and connected components use the imported x/y and die-coordinate frame. No ML classifier, reticle pitch inference, or physical cause is asserted.",
                            "radial_zones": radial_zone_summary,
                            "failure_components": {
                                "component_count": component_count,
                                "cluster_count": len(cluster_rows),
                                "clustered_failure_dies": clustered_failure_dies,
                                "isolated_failure_dies": isolated_failure_dies,
                                "top_clusters": cluster_rows[:12],
                            },
                        },
                        "telemetry": telemetry,
                        "observed_edge_scenarios": observed_edge_scenarios,
                    },
                    "wat": wat,
                    "kla": kla,
                    "ocap": {
                        "status": ocap_status,
                        "scope_note": "Decision-support triage generated from retained CP/WAT/KLA aggregates. It does not prescribe a process change or infer unavailable tool, tester, or time-series data.",
                        "evidence": evidence,
                        "recommendations": recommendations,
                    },
                }

    def validate_analysis_sources(
        self,
        cp_dataset_id: int,
        *,
        wat_dataset_id: int | None = None,
        kla_dataset_id: int | None = None,
        minimum_cp_measurements: int = 1,
        owner_open_id: str,
    ) -> list[dict[str, Any]]:
        """Validate owner-scoped source types, identities, and a non-empty measurement floor."""
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cp_dataset = self._dataset_for_source(cursor, cp_dataset_id, "CP", owner_open_id)
                cursor.execute("SELECT COUNT(*) AS row_count FROM cp_die_measurements WHERE datasetId = %s", (cp_dataset_id,))
                cp_count = int((cursor.fetchone() or {}).get("row_count") or 0)
                if cp_count < minimum_cp_measurements:
                    raise ValueError(
                        f"CP dataset #{cp_dataset_id} has {cp_count} persisted measurement rows; at least {minimum_cp_measurements} are required."
                    )
                references = [{**self._dataset_reference(cp_dataset), "measurement_rows": cp_count}]
                for dataset_id, source_type, table in (
                    (wat_dataset_id, "WAT", "wat_measurements"),
                    (kla_dataset_id, "KLA", "kla_defects"),
                ):
                    if dataset_id is None:
                        continue
                    dataset = self._dataset_for_source(cursor, dataset_id, source_type, owner_open_id)
                    matched, message = self._matching_dataset_identity(cp_dataset, dataset)
                    if not matched:
                        raise ValueError(message or f"Selected CP and {source_type} datasets are incompatible.")
                    cursor.execute(f"SELECT COUNT(*) AS row_count FROM {table} WHERE datasetId = %s", (dataset_id,))
                    count = int((cursor.fetchone() or {}).get("row_count") or 0)
                    if count < 1:
                        raise ValueError(f"{source_type} dataset #{dataset_id} contains no persisted measurement rows.")
                    references.append({**self._dataset_reference(dataset), "measurement_rows": count})
                return references

    @staticmethod
    def _decode_json_columns(row: dict[str, Any] | None, *columns: str) -> dict[str, Any] | None:
        if row is None:
            return None
        result = dict(row)
        for column in columns:
            if isinstance(result.get(column), str):
                result[column] = json.loads(result[column])
        return result

    @staticmethod
    def _analysis_job(row: dict[str, Any] | None) -> dict[str, Any] | None:
        decoded = WaferRepository._decode_json_columns(row, "requestManifest")
        if decoded is None:
            return None
        result = {
            "id": int(decoded["id"]),
            "job_id": int(decoded["id"]),
            "owner_open_id": decoded["ownerOpenId"],
            "owner_name": decoded["ownerName"],
            "cp_dataset_id": int(decoded["cpDatasetId"]),
            "wat_dataset_id": int(decoded["watDatasetId"]) if decoded.get("watDatasetId") is not None else None,
            "kla_dataset_id": int(decoded["klaDatasetId"]) if decoded.get("klaDatasetId") is not None else None,
            "status": decoded["status"],
            "queue_sequence": int(decoded["queueSequence"]),
            "attempts": int(decoded.get("attempts") or 0),
            "error": decoded.get("error"),
            "request_version": decoded["requestVersion"],
            "request_manifest": decoded["requestManifest"],
            "submitted_at": decoded.get("submittedAt"),
            "started_at": decoded.get("startedAt"),
            "completed_at": decoded.get("completedAt"),
            "updated_at": decoded.get("updatedAt"),
        }
        if decoded.get("reportId") is not None:
            result["report"] = {
                "id": int(decoded["reportId"]),
                "filename": decoded["reportFilename"],
                "payload_hash": decoded["reportPayloadHash"],
                "byte_size": int(decoded["reportByteSize"]),
                "created_at": decoded.get("reportCreatedAt"),
            }
        else:
            result["report"] = None
        return result

    def enqueue_analysis_job(
        self,
        owner_open_id: str,
        owner_name: str,
        cp_dataset_id: int,
        *,
        wat_dataset_id: int | None,
        kla_dataset_id: int | None,
        request_manifest: dict[str, Any],
        request_version: str,
        owner_active_cap: int,
        global_backlog_cap: int,
    ) -> dict[str, Any]:
        """Atomically capacity-check and append one durable FIFO job."""
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute("SELECT GET_LOCK('wafermap_analysis_queue', 5) AS acquired")
                if int((cursor.fetchone() or {}).get("acquired") or 0) != 1:
                    raise PersistenceUnavailable("The analysis queue is busy; retry the request.")
                try:
                    cursor.execute("SELECT COUNT(*) AS count FROM analysis_jobs WHERE status IN ('QUEUED', 'RUNNING')")
                    global_active = int((cursor.fetchone() or {}).get("count") or 0)
                    if global_active >= global_backlog_cap:
                        raise QueueCapacityError(f"The global analysis backlog limit of {global_backlog_cap} active jobs has been reached.")
                    cursor.execute(
                        "SELECT COUNT(*) AS count FROM analysis_jobs WHERE ownerOpenId = %s AND status IN ('QUEUED', 'RUNNING')",
                        (owner_open_id,),
                    )
                    owner_active = int((cursor.fetchone() or {}).get("count") or 0)
                    if owner_active >= owner_active_cap:
                        raise QueueCapacityError(f"Your active analysis-job limit of {owner_active_cap} has been reached.")
                    cursor.execute("SELECT COALESCE(MAX(queueSequence), 0) + 1 AS next_sequence FROM analysis_jobs")
                    queue_sequence = int((cursor.fetchone() or {}).get("next_sequence") or 1)
                    cursor.execute(
                        """INSERT INTO analysis_jobs
                           (ownerOpenId, ownerName, cpDatasetId, watDatasetId, klaDatasetId, status,
                            queueSequence, attempts, requestManifest, requestVersion)
                           VALUES (%s, %s, %s, %s, %s, 'QUEUED', %s, 0, %s, %s)""",
                        (
                            owner_open_id,
                            owner_name,
                            cp_dataset_id,
                            wat_dataset_id,
                            kla_dataset_id,
                            queue_sequence,
                            self._json(request_manifest),
                            request_version,
                        ),
                    )
                    job_id = int(cursor.lastrowid)
                    connection.commit()
                finally:
                    cursor.execute("SELECT RELEASE_LOCK('wafermap_analysis_queue')")
                cursor.execute("SELECT * FROM analysis_jobs WHERE id = %s AND ownerOpenId = %s", (job_id, owner_open_id))
                job = self._analysis_job(cursor.fetchone())
                if job is None:
                    raise PersistenceUnavailable("The queued analysis job could not be read after insertion.")
                return job

    def claim_next_analysis_job(self, *, stale_after_seconds: int) -> dict[str, Any] | None:
        """Globally serialize and atomically transition at most one FIFO job to RUNNING."""
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute("SELECT GET_LOCK('wafermap_analysis_queue', 5) AS acquired")
                if int((cursor.fetchone() or {}).get("acquired") or 0) != 1:
                    return None
                try:
                    cursor.execute(
                        """UPDATE analysis_jobs
                           SET status = 'FAILED', error = 'Execution request ended before completion; submit a new job to retry.',
                               completedAt = NOW(), updatedAt = NOW()
                           WHERE status = 'RUNNING' AND startedAt < DATE_SUB(NOW(), INTERVAL %s SECOND)""",
                        (stale_after_seconds,),
                    )
                    cursor.execute("SELECT id FROM analysis_jobs WHERE status = 'RUNNING' ORDER BY startedAt ASC, id ASC LIMIT 1")
                    if cursor.fetchone() is not None:
                        connection.commit()
                        return None
                    cursor.execute(
                        "SELECT * FROM analysis_jobs WHERE status = 'QUEUED' ORDER BY queueSequence ASC, id ASC LIMIT 1 FOR UPDATE"
                    )
                    queued = cursor.fetchone()
                    if queued is None:
                        connection.commit()
                        return None
                    job_id = int(queued["id"])
                    cursor.execute(
                        """UPDATE analysis_jobs SET status = 'RUNNING', attempts = attempts + 1,
                           startedAt = NOW(), updatedAt = NOW(), error = NULL
                           WHERE id = %s AND status = 'QUEUED'""",
                        (job_id,),
                    )
                    if cursor.rowcount != 1:
                        connection.commit()
                        return None
                    cursor.execute("SELECT * FROM analysis_jobs WHERE id = %s", (job_id,))
                    claimed = self._analysis_job(cursor.fetchone())
                    connection.commit()
                    return claimed
                finally:
                    cursor.execute("SELECT RELEASE_LOCK('wafermap_analysis_queue')")

    def complete_analysis_job(
        self,
        job_id: int,
        owner_open_id: str,
        *,
        filename: str,
        storage_key: str,
        storage_url: str,
        payload_hash: str,
        byte_size: int,
        payload: dict[str, Any],
    ) -> int:
        """Insert the historical report and complete its RUNNING job in one transaction."""
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    "SELECT id FROM analysis_jobs WHERE id = %s AND ownerOpenId = %s AND status = 'RUNNING' FOR UPDATE",
                    (job_id, owner_open_id),
                )
                if cursor.fetchone() is None:
                    raise PersistenceUnavailable("The running analysis job is no longer claimable for completion.")
                cursor.execute(
                    """INSERT INTO analysis_reports
                       (jobId, ownerOpenId, filename, storageKey, storageUrl, payloadHash, byteSize, reportPayload)
                       VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
                    (job_id, owner_open_id, filename, storage_key, storage_url, payload_hash, byte_size, self._json(payload)),
                )
                report_id = int(cursor.lastrowid)
                cursor.execute(
                    """UPDATE analysis_jobs SET status = 'COMPLETED', error = NULL,
                       completedAt = NOW(), updatedAt = NOW() WHERE id = %s AND ownerOpenId = %s AND status = 'RUNNING'""",
                    (job_id, owner_open_id),
                )
                if cursor.rowcount != 1:
                    raise PersistenceUnavailable("The report was not attached to a running analysis job.")
                return report_id

    def fail_analysis_job(self, job_id: int, owner_open_id: str, error: str) -> None:
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """UPDATE analysis_jobs SET status = 'FAILED', error = %s, completedAt = NOW(), updatedAt = NOW()
                       WHERE id = %s AND ownerOpenId = %s AND status = 'RUNNING'""",
                    (error[:512], job_id, owner_open_id),
                )

    def analysis_job_for_owner(self, job_id: int, owner_open_id: str) -> dict[str, Any] | None:
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """SELECT j.*, r.id AS reportId, r.filename AS reportFilename,
                              r.payloadHash AS reportPayloadHash, r.byteSize AS reportByteSize,
                              r.createdAt AS reportCreatedAt
                       FROM analysis_jobs j
                       LEFT JOIN analysis_reports r ON r.jobId = j.id AND r.ownerOpenId = j.ownerOpenId
                       WHERE j.id = %s AND j.ownerOpenId = %s""",
                    (job_id, owner_open_id),
                )
                return self._analysis_job(cursor.fetchone())

    def analysis_jobs_for_owner(self, owner_open_id: str, limit: int = 50) -> list[dict[str, Any]]:
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """SELECT j.*, r.id AS reportId, r.filename AS reportFilename,
                              r.payloadHash AS reportPayloadHash, r.byteSize AS reportByteSize,
                              r.createdAt AS reportCreatedAt
                       FROM analysis_jobs j
                       LEFT JOIN analysis_reports r ON r.jobId = j.id AND r.ownerOpenId = j.ownerOpenId
                       WHERE j.ownerOpenId = %s
                       ORDER BY j.submittedAt DESC, j.id DESC LIMIT %s""",
                    (owner_open_id, limit),
                )
                return [job for row in cursor.fetchall() if (job := self._analysis_job(row)) is not None]

    @staticmethod
    def _analysis_report(row: dict[str, Any] | None, *, include_payload: bool) -> dict[str, Any] | None:
        decoded = WaferRepository._decode_json_columns(row, "report_payload", "request_manifest")
        if decoded is None:
            return None
        result = {
            "id": int(decoded["id"]),
            "job_id": int(decoded["jobId"]),
            "filename": decoded["filename"],
            "payload_hash": decoded["payloadHash"],
            "byte_size": int(decoded["byteSize"]),
            "created_at": decoded.get("createdAt"),
            "source_datasets": (decoded.get("request_manifest") or {}).get("sources", []),
        }
        if include_payload:
            result["payload"] = decoded.get("report_payload")
        return result

    def analysis_reports_for_owner(self, owner_open_id: str, limit: int = 50) -> list[dict[str, Any]]:
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """SELECT r.id, r.jobId, r.filename, r.payloadHash, r.byteSize, r.createdAt,
                              j.requestManifest AS request_manifest
                       FROM analysis_reports r JOIN analysis_jobs j ON j.id = r.jobId
                       WHERE r.ownerOpenId = %s AND j.ownerOpenId = %s
                       ORDER BY r.createdAt DESC, r.id DESC LIMIT %s""",
                    (owner_open_id, owner_open_id, limit),
                )
                return [report for row in cursor.fetchall() if (report := self._analysis_report(row, include_payload=False)) is not None]

    def analysis_report_for_owner(self, report_id: int, owner_open_id: str) -> dict[str, Any] | None:
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """SELECT r.id, r.jobId, r.filename, r.payloadHash, r.byteSize, r.reportPayload AS report_payload,
                              r.createdAt, j.requestManifest AS request_manifest
                       FROM analysis_reports r JOIN analysis_jobs j ON j.id = r.jobId
                       WHERE r.id = %s AND r.ownerOpenId = %s AND j.ownerOpenId = %s""",
                    (report_id, owner_open_id, owner_open_id),
                )
                return self._analysis_report(cursor.fetchone(), include_payload=True)

    def recent_ingestion_datasets(self, owner_open_id: str, limit: int = 12) -> list[dict[str, Any]]:
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """SELECT d.id, d.sourceType, d.waferId, d.lotId, d.productId,
                              d.originalFilename, d.validRows, d.errorRows, d.createdAt
                       FROM ingestion_datasets d JOIN users u ON u.id = d.ownerId
                       WHERE u.openId = %s
                       ORDER BY d.createdAt DESC, d.id DESC LIMIT %s""",
                    (owner_open_id, limit),
                )
                return list(cursor.fetchall())

    def ingestion_dataset_catalog(
        self,
        *,
        owner_open_id: str,
        source_types: list[str] | None = None,
        lot_id: str | None = None,
        wafer_id: str | None = None,
        product_id: str | None = None,
        limit: int = 50,
    ) -> dict[str, Any]:
        """Return a bounded, allowlisted operational dataset catalog with facet values."""
        allowed_source_types = {"CP", "WAT", "KLA"}
        normalized_types = sorted({value for value in (source_types or []) if value in allowed_source_types})
        clauses: list[str] = ["u.openId = %s"]
        values: list[Any] = [owner_open_id]
        if normalized_types:
            clauses.append("d.sourceType IN (" + ", ".join(["%s"] * len(normalized_types)) + ")")
            values.extend(normalized_types)
        for column, value in (("lotId", lot_id), ("waferId", wafer_id), ("productId", product_id)):
            if value:
                clauses.append(f"d.{column} = %s")
                values.append(value)
        where = " WHERE " + " AND ".join(clauses)
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """SELECT d.id, d.sourceType, d.waferId, d.lotId, d.productId,
                              d.originalFilename, d.validRows, d.errorRows, d.createdAt
                       FROM ingestion_datasets d JOIN users u ON u.id = d.ownerId"""
                    + where
                    + " ORDER BY d.createdAt DESC, d.id DESC LIMIT %s",
                    (*values, limit),
                )
                datasets = list(cursor.fetchall())
                cursor.execute(
                    """SELECT d.sourceType, d.lotId, d.waferId, d.productId
                       FROM ingestion_datasets d JOIN users u ON u.id = d.ownerId
                       WHERE u.openId = %s
                       ORDER BY d.createdAt DESC, d.id DESC
                       LIMIT 500""",
                    (owner_open_id,),
                )
                facet_rows = cursor.fetchall()
        return {
            "datasets": datasets,
            "criteria": {
                "source_types": sorted({row["sourceType"] for row in facet_rows}),
                "lot_ids": sorted({row["lotId"] for row in facet_rows})[:100],
                "wafer_ids": sorted({row["waferId"] for row in facet_rows})[:100],
                "product_ids": sorted({row["productId"] for row in facet_rows})[:100],
            },
        }
