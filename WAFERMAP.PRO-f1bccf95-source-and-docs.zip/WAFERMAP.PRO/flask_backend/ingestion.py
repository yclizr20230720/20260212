"""Bounded, source-aware CP/WAT/KLA CSV ingestion for WAFERMAP.PRO.

Package validation previews every canonical identity. Package parsing can collect one
explicitly selected partition without collapsing a multi-wafer source into one dataset.
Legacy single-file persistence remains limited to exactly one LOT_ID/WAFER_ID partition.
"""

from __future__ import annotations

import csv
import hashlib
import io
import math
import os
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import Any, BinaryIO, Callable, Iterable

from openpyxl import load_workbook

SOURCE_TYPES = {"CP", "WAT", "KLA"}
PARSER_MAPPING_VERSION = "wafermap-real-csv-v1"
DEFAULT_MAX_FILE_BYTES = 128 * 1024 * 1024
DEFAULT_MAX_ROWS = 250_000
MAX_COORDINATE_MM = 250.0
MAX_DIAGNOSTICS = 50

PACKAGE_ROLES: dict[str, dict[str, Any]] = {
    "CP": {
        "allowed": {"cp_die", "cp_summary", "cp_bins", "cp_limits"},
        "required_any": ({"cp_die"},),
        "primary": ("cp_die",),
    },
    "WAT": {
        "allowed": {"wat_long", "wat_wide", "wat_summary", "wat_specs"},
        "required_any": ({"wat_long"}, {"wat_wide"}),
        "primary": ("wat_long", "wat_wide"),
    },
    "KLA": {
        "allowed": {"kla_defects", "kla_summary", "kla_classes"},
        "required_any": ({"kla_defects"},),
        "primary": ("kla_defects",),
    },
}

CP_MEASUREMENTS: dict[str, str] = {
    "VTH_NMOS_V": "V",
    "VTH_PMOS_V": "V",
    "IDDQ_UA": "uA",
    "RON_OHM": "ohm",
    "FMAX_MHZ": "MHz",
    "VDD_MIN_V": "V",
    "CONT_RES_OHM": "ohm",
    "ICC_ACTIVE_MA": "mA",
}

ROLE_REQUIRED_HEADERS: dict[str, set[str]] = {
    "cp_die": {
        "LOT_ID", "WAFER_ID", "PRODUCT_ID", "DIE_X", "DIE_Y",
        "DIE_CENTER_X_MM", "DIE_CENTER_Y_MM", "HARD_BIN", "SOFT_BIN",
        "BIN_NAME", "PASS_FAIL", *CP_MEASUREMENTS.keys(),
    },
    "cp_summary": {"LOT_ID", "WAFER_ID", "GROSS_DIE", "PASS_DIE", "YIELD_PCT"},
    "cp_bins": {"SOFT_BIN", "BIN_NAME", "HARD_BIN", "PASS_FAIL", "BIN_CATEGORY"},
    "cp_limits": {"TEST_NUM", "TEST_NAME", "UNIT", "LOW_LIMIT", "HIGH_LIMIT", "FAIL_SOFT_BIN"},
    "wat_long": {
        "LOT_ID", "WAFER_ID", "SITE_ID", "SITE_NAME", "SITE_X_MM", "SITE_Y_MM",
        "DIE_X", "DIE_Y", "PARAM_ID", "PARAM_NAME", "PARAM_GROUP", "MODULE",
        "TEST_STRUCTURE", "CRITICALITY", "UNIT", "VALUE", "TARGET", "SPEC_LOW",
        "SPEC_HIGH", "OOS_FLAG",
    },
    "wat_wide": {"LOT_ID", "WAFER_ID", "SITE_ID", "SITE_NAME", "SITE_X_MM", "SITE_Y_MM", "DIE_X", "DIE_Y"},
    "wat_summary": {"LOT_ID", "WAFER_ID", "OOS_SITE_PARAM_QTY"},
    "wat_specs": {"PARAM_ID", "PARAM_NAME", "UNIT", "TARGET", "SPEC_LOW", "SPEC_HIGH", "MODULE", "PARAM_GROUP", "TEST_STRUCTURE", "CRITICALITY"},
    "kla_defects": {
        "DEFECT_ID", "LOT_ID", "WAFER_ID", "DIE_X", "DIE_Y", "XREL_UM", "YREL_UM",
        "DEFECT_SIZE_UM", "CLASS_CODE", "CLASS_NAME", "CLASS_GROUP", "KILLER_FLAG",
        "INSPECTION_TOOL", "INSPECTION_RECIPE", "INSPECTION_STEP", "LAYER", "RETICLE_SHOT_ID",
    },
    "kla_summary": {"LOT_ID", "WAFER_ID", "TOTAL_DEFECTS", "KILLER_DEFECTS", "TOP_CLASS", "MEAN_SIZE_UM"},
    "kla_classes": {"CLASS_CODE", "CLASS_NAME", "CLASS_GROUP", "POLARITY", "KILLER_DEFAULT"},
}


class IngestionValidationError(ValueError):
    """Raised when source files cannot safely form canonical wafer partitions."""

    def __init__(self, message: str, diagnostics: list[dict[str, Any]] | None = None):
        super().__init__(message)
        self.diagnostics = list(diagnostics or [])[:MAX_DIAGNOSTICS]


@dataclass
class SourceFile:
    role: str
    filename: str
    stream: BinaryIO
    byte_size: int = 0
    checksum_sha256: str = ""
    row_count: int = 0
    headers: list[str] = field(default_factory=list)


@dataclass
class RunningStats:
    count: int = 0
    total: float = 0.0
    total_sq: float = 0.0
    minimum: float | None = None
    maximum: float | None = None
    oos_count: int = 0

    def add(self, value: float, *, oos: bool = False) -> None:
        self.count += 1
        self.total += value
        self.total_sq += value * value
        self.minimum = value if self.minimum is None else min(self.minimum, value)
        self.maximum = value if self.maximum is None else max(self.maximum, value)
        self.oos_count += int(oos)

    def as_dict(self) -> dict[str, Any]:
        mean = self.total / self.count if self.count else None
        variance = max(0.0, self.total_sq / self.count - mean * mean) if mean is not None else None
        return {
            "count": self.count,
            "mean": round(mean, 6) if mean is not None else None,
            "std_dev": round(math.sqrt(variance), 6) if variance is not None else None,
            "min": round(self.minimum, 6) if self.minimum is not None else None,
            "max": round(self.maximum, 6) if self.maximum is not None else None,
            "oos_count": self.oos_count,
        }


class Diagnostics:
    def __init__(self) -> None:
        self.items: list[dict[str, Any]] = []
        self.total_errors = 0
        self.total_warnings = 0

    def add(self, severity: str, code: str, message: str, *, role: str | None = None, row_number: int | None = None, partition: tuple[str, str] | None = None) -> None:
        if severity == "ERROR":
            self.total_errors += 1
        else:
            self.total_warnings += 1
        if len(self.items) >= MAX_DIAGNOSTICS:
            return
        item: dict[str, Any] = {"severity": severity, "code": code, "message": message}
        if role:
            item["role"] = role
        if row_number is not None:
            item["row_number"] = row_number
        if partition:
            item["partition"] = {"lot_id": partition[0], "wafer_id": partition[1]}
        self.items.append(item)

    def error(self, code: str, message: str, **context: Any) -> None:
        self.add("ERROR", code, message, **context)

    def warning(self, code: str, message: str, **context: Any) -> None:
        self.add("WARNING", code, message, **context)

    def as_dict(self) -> dict[str, Any]:
        return {
            "status": "INVALID" if self.total_errors else "VALID_WITH_WARNINGS" if self.total_warnings else "VALID",
            "error_count": self.total_errors,
            "warning_count": self.total_warnings,
            "items": self.items,
            "truncated": self.total_errors + self.total_warnings > len(self.items),
        }


def _header(value: Any) -> str:
    return re.sub(r"[^A-Z0-9]+", "_", str(value).strip().upper()).strip("_")


def _text(value: Any, field_name: str, *, required: bool = True, max_length: int = 256) -> str | None:
    result = str(value or "").strip()
    if required and not result:
        raise ValueError(f"{field_name} is required")
    if len(result) > max_length:
        raise ValueError(f"{field_name} exceeds {max_length} characters")
    return result or None


def _float(value: Any, field_name: str, *, required: bool = True) -> float | None:
    if value in (None, ""):
        if required:
            raise ValueError(f"{field_name} is required")
        return None
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field_name} must be numeric") from exc
    if not math.isfinite(result):
        raise ValueError(f"{field_name} must be finite")
    return result


def _int(value: Any, field_name: str, *, required: bool = True, default: int = 0) -> int:
    number = _float(value, field_name, required=required)
    if number is None:
        return default
    if not number.is_integer():
        raise ValueError(f"{field_name} must be an integer")
    return int(number)


def _bool_yn(value: Any, field_name: str) -> bool:
    normalized = str(value or "").strip().upper()
    if normalized in {"Y", "YES", "TRUE", "1"}:
        return True
    if normalized in {"N", "NO", "FALSE", "0"}:
        return False
    raise ValueError(f"{field_name} must be Y/N or true/false")


def _identity(row: dict[str, Any]) -> tuple[str, str]:
    return (
        str(_text(row.get("LOT_ID"), "LOT_ID", max_length=128)),
        str(_text(row.get("WAFER_ID"), "WAFER_ID", max_length=128)),
    )


def _as_source(role: str, value: Any) -> SourceFile:
    if isinstance(value, SourceFile):
        return value
    if isinstance(value, bytes):
        return SourceFile(role, f"{role}.csv", io.BytesIO(value))
    filename = os.path.basename(str(getattr(value, "filename", "") or f"{role}.csv"))
    stream = getattr(value, "stream", value)
    if not hasattr(stream, "read") or not hasattr(stream, "seek"):
        raise IngestionValidationError(f"File role '{role}' is not a readable upload.")
    return SourceFile(role, filename, stream)


def _fingerprint(source: SourceFile, max_file_bytes: int) -> None:
    if not source.filename.lower().endswith(".csv"):
        raise IngestionValidationError(f"File role '{source.role}' must be a .csv file.")
    digest = hashlib.sha256()
    size = 0
    source.stream.seek(0)
    while True:
        chunk = source.stream.read(1024 * 1024)
        if not chunk:
            break
        if isinstance(chunk, str):
            chunk = chunk.encode("utf-8")
        size += len(chunk)
        if size > max_file_bytes:
            raise IngestionValidationError(
                f"File role '{source.role}' exceeds the configured {max_file_bytes:,}-byte limit."
            )
        digest.update(chunk)
    if size == 0:
        raise IngestionValidationError(f"File role '{source.role}' is empty.")
    source.byte_size = size
    source.checksum_sha256 = digest.hexdigest()
    source.stream.seek(0)


def _consume_csv(
    source: SourceFile,
    required_headers: set[str],
    on_row: Callable[[dict[str, Any], int], None],
    *,
    max_rows: int,
) -> None:
    source.stream.seek(0)
    wrapper = io.TextIOWrapper(source.stream, encoding="utf-8-sig", errors="strict", newline="")
    try:
        reader = csv.DictReader(wrapper)
        if not reader.fieldnames:
            raise IngestionValidationError(f"File role '{source.role}' must include a CSV header row.")
        headers = [_header(value) for value in reader.fieldnames]
        if any(not value for value in headers) or len(set(headers)) != len(headers):
            raise IngestionValidationError(f"File role '{source.role}' contains blank or duplicate normalized headers.")
        source.headers = headers
        missing = sorted(required_headers - set(headers))
        if missing:
            raise IngestionValidationError(
                f"File role '{source.role}' is missing required headers: {', '.join(missing)}."
            )
        for row_number, raw_row in enumerate(reader, start=2):
            row = {_header(key): value for key, value in raw_row.items() if key is not None}
            if not any(str(value or "").strip() for value in row.values()):
                continue
            source.row_count += 1
            if source.row_count > max_rows:
                raise IngestionValidationError(
                    f"File role '{source.role}' exceeds the configured {max_rows:,}-row limit."
                )
            on_row(row, row_number)
        if source.row_count == 0:
            raise IngestionValidationError(f"File role '{source.role}' contains no data rows.")
    except UnicodeDecodeError as exc:
        raise IngestionValidationError(f"File role '{source.role}' must use UTF-8 encoding.") from exc
    except csv.Error as exc:
        raise IngestionValidationError(f"File role '{source.role}' is malformed CSV: {exc}.") from exc
    finally:
        try:
            wrapper.detach()
        except Exception:
            pass
        source.stream.seek(0)


def _partition_base(identity: tuple[str, str]) -> dict[str, Any]:
    return {
        "lot_id": identity[0],
        "wafer_id": identity[1],
        "row_count": 0,
        "valid_rows": 0,
        "invalid_rows": 0,
        "products": set(),
        "wafer_sizes": set(),
        "coordinate_frames": set(),
    }


def _safe_row(handler: Callable[[], None], diagnostics: Diagnostics, role: str, row_number: int, partition: tuple[str, str] | None = None) -> None:
    try:
        handler()
    except ValueError as exc:
        diagnostics.error("INVALID_ROW", str(exc), role=role, row_number=row_number, partition=partition)


def _parse_cp_companions(sources: dict[str, SourceFile], diagnostics: Diagnostics, max_rows: int) -> dict[str, Any]:
    result: dict[str, Any] = {"bins": {}, "limits": {}, "summary": {}}
    if "cp_bins" in sources:
        def bin_row(row: dict[str, Any], number: int) -> None:
            def apply() -> None:
                code = _int(row.get("SOFT_BIN"), "SOFT_BIN")
                assert code is not None
                pf = str(_text(row.get("PASS_FAIL"), "PASS_FAIL")).upper()
                if pf not in {"P", "PASS", "F", "FAIL"}:
                    raise ValueError("PASS_FAIL must be P/PASS or F/FAIL")
                if code in result["bins"]:
                    raise ValueError("SOFT_BIN must be unique in cp_bins")
                result["bins"][code] = {
                    "bin_name": _text(row.get("BIN_NAME"), "BIN_NAME"),
                    "hard_bin": _int(row.get("HARD_BIN"), "HARD_BIN"),
                    "pass_fail": "PASS" if pf in {"P", "PASS"} else "FAIL",
                    "category": _text(row.get("BIN_CATEGORY"), "BIN_CATEGORY"),
                }
            _safe_row(apply, diagnostics, "cp_bins", number)
        _consume_csv(sources["cp_bins"], ROLE_REQUIRED_HEADERS["cp_bins"], bin_row, max_rows=max_rows)
        pass_bins = sorted(code for code, item in result["bins"].items() if item["pass_fail"] == "PASS")
        if pass_bins != [1, 2, 3]:
            diagnostics.error("CP_PASS_BIN_DEFINITION", "CP bin definitions must identify soft bins 1, 2, and 3 as the pass bins.", role="cp_bins")

    if "cp_limits" in sources:
        def limit_row(row: dict[str, Any], number: int) -> None:
            def apply() -> None:
                name = str(_text(row.get("TEST_NAME"), "TEST_NAME", max_length=128)).upper()
                low = _float(row.get("LOW_LIMIT"), "LOW_LIMIT")
                high = _float(row.get("HIGH_LIMIT"), "HIGH_LIMIT")
                assert low is not None and high is not None
                if low > high:
                    raise ValueError("LOW_LIMIT cannot exceed HIGH_LIMIT")
                result["limits"][name] = {
                    "test_num": _int(row.get("TEST_NUM"), "TEST_NUM"),
                    "unit": _text(row.get("UNIT"), "UNIT", max_length=32),
                    "low": low,
                    "high": high,
                    "fail_soft_bin": _int(row.get("FAIL_SOFT_BIN"), "FAIL_SOFT_BIN"),
                }
            _safe_row(apply, diagnostics, "cp_limits", number)
        _consume_csv(sources["cp_limits"], ROLE_REQUIRED_HEADERS["cp_limits"], limit_row, max_rows=max_rows)
        missing_limits = sorted(set(CP_MEASUREMENTS) - set(result["limits"]))
        if missing_limits:
            diagnostics.error("CP_LIMITS_INCOMPLETE", f"CP limits do not define: {', '.join(missing_limits)}.", role="cp_limits")

    if "cp_summary" in sources:
        def summary_row(row: dict[str, Any], number: int) -> None:
            identity: tuple[str, str] | None = None
            def apply() -> None:
                nonlocal identity
                identity = _identity(row)
                if identity in result["summary"]:
                    raise ValueError("CP summary must contain one row per LOT_ID/WAFER_ID")
                result["summary"][identity] = {
                    "gross": _int(row.get("GROSS_DIE"), "GROSS_DIE"),
                    "pass": _int(row.get("PASS_DIE"), "PASS_DIE"),
                    "yield_pct": _float(row.get("YIELD_PCT"), "YIELD_PCT"),
                }
            _safe_row(apply, diagnostics, "cp_summary", number, identity)
        _consume_csv(sources["cp_summary"], ROLE_REQUIRED_HEADERS["cp_summary"], summary_row, max_rows=max_rows)
    return result


def _parse_wat_companions(sources: dict[str, SourceFile], diagnostics: Diagnostics, max_rows: int) -> dict[str, Any]:
    result: dict[str, Any] = {"specs_by_name": {}, "specs_by_id": {}, "summary": {}}
    if "wat_specs" in sources:
        def spec_row(row: dict[str, Any], number: int) -> None:
            def apply() -> None:
                param_id = str(_text(row.get("PARAM_ID"), "PARAM_ID", max_length=128))
                name = str(_text(row.get("PARAM_NAME"), "PARAM_NAME", max_length=128)).upper()
                spec = {
                    "param_id": param_id,
                    "param_name": name,
                    "unit": _text(row.get("UNIT"), "UNIT", max_length=32),
                    "target": _float(row.get("TARGET"), "TARGET"),
                    "low": _float(row.get("SPEC_LOW"), "SPEC_LOW"),
                    "high": _float(row.get("SPEC_HIGH"), "SPEC_HIGH"),
                    "module": _text(row.get("MODULE"), "MODULE", max_length=128),
                    "param_group": _text(row.get("PARAM_GROUP"), "PARAM_GROUP", max_length=128),
                    "test_structure": _text(row.get("TEST_STRUCTURE"), "TEST_STRUCTURE", max_length=128),
                    "criticality": _text(row.get("CRITICALITY"), "CRITICALITY", max_length=64),
                }
                if spec["low"] > spec["high"]:
                    raise ValueError("SPEC_LOW cannot exceed SPEC_HIGH")
                if name in result["specs_by_name"] or param_id in result["specs_by_id"]:
                    raise ValueError("PARAM_ID and PARAM_NAME must be unique in wat_specs")
                result["specs_by_name"][name] = spec
                result["specs_by_id"][param_id] = spec
            _safe_row(apply, diagnostics, "wat_specs", number)
        _consume_csv(sources["wat_specs"], ROLE_REQUIRED_HEADERS["wat_specs"], spec_row, max_rows=max_rows)

    if "wat_summary" in sources:
        def summary_row(row: dict[str, Any], number: int) -> None:
            identity: tuple[str, str] | None = None
            def apply() -> None:
                nonlocal identity
                identity = _identity(row)
                if identity in result["summary"]:
                    raise ValueError("WAT summary must contain one row per LOT_ID/WAFER_ID")
                result["summary"][identity] = {"oos_count": _int(row.get("OOS_SITE_PARAM_QTY"), "OOS_SITE_PARAM_QTY")}
            _safe_row(apply, diagnostics, "wat_summary", number, identity)
        _consume_csv(sources["wat_summary"], ROLE_REQUIRED_HEADERS["wat_summary"], summary_row, max_rows=max_rows)
    return result


def _parse_kla_companions(sources: dict[str, SourceFile], diagnostics: Diagnostics, max_rows: int) -> dict[str, Any]:
    result: dict[str, Any] = {"classes": {}, "summary": {}}
    if "kla_classes" in sources:
        def class_row(row: dict[str, Any], number: int) -> None:
            def apply() -> None:
                code = str(_text(row.get("CLASS_CODE"), "CLASS_CODE", max_length=64))
                if code in result["classes"]:
                    raise ValueError("CLASS_CODE must be unique in kla_classes")
                result["classes"][code] = {
                    "name": _text(row.get("CLASS_NAME"), "CLASS_NAME", max_length=128),
                    "group": _text(row.get("CLASS_GROUP"), "CLASS_GROUP", max_length=128),
                    "polarity": _text(row.get("POLARITY"), "POLARITY", max_length=32),
                    "killer_default": _bool_yn(row.get("KILLER_DEFAULT"), "KILLER_DEFAULT"),
                }
            _safe_row(apply, diagnostics, "kla_classes", number)
        _consume_csv(sources["kla_classes"], ROLE_REQUIRED_HEADERS["kla_classes"], class_row, max_rows=max_rows)

    if "kla_summary" in sources:
        def summary_row(row: dict[str, Any], number: int) -> None:
            identity: tuple[str, str] | None = None
            def apply() -> None:
                nonlocal identity
                identity = _identity(row)
                if identity in result["summary"]:
                    raise ValueError("KLA summary must contain one row per LOT_ID/WAFER_ID")
                result["summary"][identity] = {
                    "total": _int(row.get("TOTAL_DEFECTS"), "TOTAL_DEFECTS"),
                    "killer": _int(row.get("KILLER_DEFECTS"), "KILLER_DEFECTS"),
                    "top_class": _text(row.get("TOP_CLASS"), "TOP_CLASS", max_length=128),
                    "mean_size": _float(row.get("MEAN_SIZE_UM"), "MEAN_SIZE_UM"),
                }
            _safe_row(apply, diagnostics, "kla_summary", number, identity)
        _consume_csv(sources["kla_summary"], ROLE_REQUIRED_HEADERS["kla_summary"], summary_row, max_rows=max_rows)
    return result


def _parse_cp_primary(
    source: SourceFile,
    companions: dict[str, Any],
    diagnostics: Diagnostics,
    max_rows: int,
    *,
    collect_records: bool,
    selected_partition: tuple[str, str] | None = None,
) -> tuple[dict[tuple[str, str], dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    partitions: dict[tuple[str, str], dict[str, Any]] = {}
    records: list[dict[str, Any]] = []
    parametric_records: list[dict[str, Any]] = []

    def row_handler(row: dict[str, Any], row_number: int) -> None:
        identity: tuple[str, str] | None = None
        try:
            identity = _identity(row)
        except ValueError as exc:
            diagnostics.error("INVALID_IDENTITY", str(exc), role="cp_die", row_number=row_number)
            return
        part = partitions.setdefault(identity, {**_partition_base(identity), "pass": 0, "fail": 0, "bins": Counter(), "parameters": {}, "die_keys": set(), "coordinate_keys": {}, "duplicate_die_keys": 0, "duplicate_coordinates": 0})
        part["row_count"] += 1

        def apply() -> None:
            product = str(_text(row.get("PRODUCT_ID"), "PRODUCT_ID", max_length=128))
            die_x = _int(row.get("DIE_X"), "DIE_X")
            die_y = _int(row.get("DIE_Y"), "DIE_Y")
            x_mm = _float(row.get("DIE_CENTER_X_MM"), "DIE_CENTER_X_MM")
            y_mm = _float(row.get("DIE_CENTER_Y_MM"), "DIE_CENTER_Y_MM")
            assert x_mm is not None and y_mm is not None
            if abs(x_mm) > MAX_COORDINATE_MM or abs(y_mm) > MAX_COORDINATE_MM:
                raise ValueError("die center coordinates must be within +/-250 mm")
            hard_bin = _int(row.get("HARD_BIN"), "HARD_BIN")
            soft_bin = _int(row.get("SOFT_BIN"), "SOFT_BIN")
            raw_pf = str(_text(row.get("PASS_FAIL"), "PASS_FAIL")).upper()
            if raw_pf not in {"P", "PASS", "F", "FAIL"}:
                raise ValueError("PASS_FAIL must be P/PASS or F/FAIL")
            quality = "PASS" if raw_pf in {"P", "PASS"} else "FAIL"
            bin_name = str(_text(row.get("BIN_NAME"), "BIN_NAME", max_length=256))
            definition = companions["bins"].get(soft_bin)
            if companions["bins"] and definition is None:
                raise ValueError("SOFT_BIN is absent from cp_bins")
            if definition and (definition["pass_fail"] != quality or int(definition["hard_bin"]) != hard_bin or str(definition["bin_name"]) != bin_name):
                raise ValueError("CP event bin fields disagree with cp_bins")
            die_key = (die_x, die_y)
            coord_key = (round(x_mm, 6), round(y_mm, 6))
            if die_key in part["die_keys"]:
                part["duplicate_die_keys"] += 1
            else:
                part["die_keys"].add(die_key)
            prior_die = part["coordinate_keys"].get(coord_key)
            if prior_die is not None and prior_die != die_key:
                part["duplicate_coordinates"] += 1
            else:
                part["coordinate_keys"][coord_key] = die_key
            part["products"].add(product)
            wafer_size = _float(row.get("WAFER_SIZE_MM"), "WAFER_SIZE_MM", required=False)
            if wafer_size is not None:
                if wafer_size <= 0 or math.hypot(x_mm, y_mm) > wafer_size / 2 + 1:
                    raise ValueError("die coordinate is inconsistent with WAFER_SIZE_MM")
                part["wafer_sizes"].add(round(wafer_size, 6))
            part["coordinate_frames"].add("DIE_CENTER_XY_MM")
            part["pass"] += int(quality == "PASS")
            part["fail"] += int(quality == "FAIL")
            part["bins"][(soft_bin, hard_bin, bin_name, quality)] += 1
            collect_this_row = collect_records and (selected_partition is None or identity == selected_partition)
            normalized_params: list[dict[str, Any]] = []
            for name, default_unit in CP_MEASUREMENTS.items():
                value = _float(row.get(name), name)
                assert value is not None
                limit = companions["limits"].get(name)
                unit = str(limit["unit"] if limit else default_unit)
                oos = bool(limit and (value < limit["low"] or value > limit["high"]))
                stats = part["parameters"].setdefault((name, unit), RunningStats())
                stats.add(value, oos=oos)
                if collect_this_row:
                    normalized_params.append({
                        "param_name": name,
                        "value": value,
                        "unit": unit,
                        "spec_low": limit["low"] if limit else None,
                        "spec_high": limit["high"] if limit else None,
                        "is_oos": oos if limit else None,
                    })
            part["valid_rows"] += 1
            if collect_this_row:
                records.append({
                    "lot_id": identity[0], "wafer_id": identity[1],
                    "die_x": die_x, "die_y": die_y, "x_mm": round(x_mm, 6), "y_mm": round(y_mm, 6),
                    "hard_bin": hard_bin, "bin_code": soft_bin, "bin_name": bin_name, "bin_quality": quality,
                    "param_name": None, "param_value": None, "param_unit": None,
                    "test_freq_ghz": None, "leakage_ua": None,
                })
                for item in normalized_params:
                    parametric_records.append({
                        "lot_id": identity[0], "wafer_id": identity[1],
                        "die_x": die_x, "die_y": die_y, **item,
                    })
        before = diagnostics.total_errors
        _safe_row(apply, diagnostics, "cp_die", row_number, identity)
        if diagnostics.total_errors > before:
            part["invalid_rows"] += 1

    _consume_csv(source, ROLE_REQUIRED_HEADERS["cp_die"], row_handler, max_rows=max_rows)
    for identity, part in partitions.items():
        if part["duplicate_die_keys"]:
            diagnostics.error("CP_DUPLICATE_DIE_KEY", f"Partition contains {part['duplicate_die_keys']} duplicate DIE_X/DIE_Y keys.", role="cp_die", partition=identity)
        if part["duplicate_coordinates"]:
            diagnostics.error("CP_DUPLICATE_COORDINATE", f"Partition maps {part['duplicate_coordinates']} distinct die keys onto duplicate center coordinates.", role="cp_die", partition=identity)
        if len(part["products"]) != 1:
            diagnostics.error("CP_PRODUCT_HETEROGENEITY", "Each CP wafer partition must contain exactly one source PRODUCT_ID.", role="cp_die", partition=identity)
        if len(part["wafer_sizes"]) > 1:
            diagnostics.error("CP_GEOMETRY_HETEROGENEITY", "WAFER_SIZE_MM varies within one CP wafer partition.", role="cp_die", partition=identity)
    return partitions, records, parametric_records


def _check_wat_spec(row: dict[str, Any], spec: dict[str, Any]) -> None:
    comparisons = (
        ("PARAM_ID", spec["param_id"]), ("PARAM_NAME", spec["param_name"]), ("UNIT", spec["unit"]),
        ("MODULE", spec["module"]), ("PARAM_GROUP", spec["param_group"]),
        ("TEST_STRUCTURE", spec["test_structure"]), ("CRITICALITY", spec["criticality"]),
    )
    for key, expected in comparisons:
        actual = str(row.get(key, "")).strip()
        if key == "PARAM_NAME":
            actual = actual.upper()
        if actual != str(expected):
            raise ValueError(f"{key} disagrees with wat_specs")
    for key, spec_key in (("TARGET", "target"), ("SPEC_LOW", "low"), ("SPEC_HIGH", "high")):
        value = _float(row.get(key), key)
        if value is None or not math.isclose(value, float(spec[spec_key]), rel_tol=1e-9, abs_tol=1e-12):
            raise ValueError(f"{key} disagrees with wat_specs")


def _parse_wat_long(
    source: SourceFile,
    companions: dict[str, Any],
    diagnostics: Diagnostics,
    max_rows: int,
    *,
    collect_records: bool,
    selected_partition: tuple[str, str] | None = None,
) -> tuple[dict[tuple[str, str], dict[str, Any]], list[dict[str, Any]]]:
    partitions: dict[tuple[str, str], dict[str, Any]] = {}
    records: list[dict[str, Any]] = []

    def row_handler(row: dict[str, Any], row_number: int) -> None:
        identity: tuple[str, str] | None = None
        try:
            identity = _identity(row)
        except ValueError as exc:
            diagnostics.error("INVALID_IDENTITY", str(exc), role="wat_long", row_number=row_number)
            return
        part = partitions.setdefault(identity, {**_partition_base(identity), "parameters": {}, "oos": 0, "measurement_keys": set(), "duplicates": 0})
        part["row_count"] += 1

        def apply() -> None:
            product = _text(row.get("PRODUCT_ID"), "PRODUCT_ID", required=False, max_length=128)
            if product:
                part["products"].add(product)
            site_id = str(_text(row.get("SITE_ID"), "SITE_ID", max_length=128))
            site_name = str(_text(row.get("SITE_NAME"), "SITE_NAME", max_length=128))
            x_mm = _float(row.get("SITE_X_MM"), "SITE_X_MM")
            y_mm = _float(row.get("SITE_Y_MM"), "SITE_Y_MM")
            assert x_mm is not None and y_mm is not None
            if abs(x_mm) > MAX_COORDINATE_MM or abs(y_mm) > MAX_COORDINATE_MM:
                raise ValueError("site coordinates must be within +/-250 mm")
            die_x = _int(row.get("DIE_X"), "DIE_X")
            die_y = _int(row.get("DIE_Y"), "DIE_Y")
            param_id = str(_text(row.get("PARAM_ID"), "PARAM_ID", max_length=128))
            param_name = str(_text(row.get("PARAM_NAME"), "PARAM_NAME", max_length=128)).upper()
            unit = str(_text(row.get("UNIT"), "UNIT", max_length=32))
            value = _float(row.get("VALUE"), "VALUE")
            target = _float(row.get("TARGET"), "TARGET")
            low = _float(row.get("SPEC_LOW"), "SPEC_LOW")
            high = _float(row.get("SPEC_HIGH"), "SPEC_HIGH")
            assert value is not None and target is not None and low is not None and high is not None
            if low > high:
                raise ValueError("SPEC_LOW cannot exceed SPEC_HIGH")
            raw_oos = str(_text(row.get("OOS_FLAG"), "OOS_FLAG")).upper()
            if raw_oos not in {"PASS", "OOS"}:
                raise ValueError("OOS_FLAG must be PASS or OOS")
            spec = companions["specs_by_name"].get(param_name)
            if companions["specs_by_name"] and spec is None:
                raise ValueError("PARAM_NAME is absent from wat_specs")
            if spec:
                _check_wat_spec(row, spec)
            computed_oos = value < low or value > high
            if computed_oos != (raw_oos == "OOS"):
                diagnostics.warning("WAT_OOS_SPEC_DISAGREEMENT", "OOS_FLAG disagrees with the row's VALUE and specification limits; source OOS_FLAG is retained.", role="wat_long", row_number=row_number, partition=identity)
            key = (site_id, param_id)
            if key in part["measurement_keys"]:
                part["duplicates"] += 1
            else:
                part["measurement_keys"].add(key)
            part["coordinate_frames"].add("SITE_XY_MM")
            part["oos"] += int(raw_oos == "OOS")
            part["parameters"].setdefault((param_name, unit), RunningStats()).add(value, oos=raw_oos == "OOS")
            part["valid_rows"] += 1
            if collect_records and (selected_partition is None or identity == selected_partition):
                records.append({
                    "lot_id": identity[0], "wafer_id": identity[1],
                    "site_id": site_id, "site_name": site_name, "die_x": die_x, "die_y": die_y,
                    "x_mm": round(x_mm, 6), "y_mm": round(y_mm, 6), "param_id": param_id,
                    "param_name": param_name, "value": value, "unit": unit, "spec_low": low,
                    "spec_target": target, "spec_high": high, "status": raw_oos,
                    "module": _text(row.get("MODULE"), "MODULE", max_length=128),
                    "param_group": _text(row.get("PARAM_GROUP"), "PARAM_GROUP", max_length=128),
                    "test_structure": _text(row.get("TEST_STRUCTURE"), "TEST_STRUCTURE", max_length=128),
                    "criticality": _text(row.get("CRITICALITY"), "CRITICALITY", max_length=64),
                })
        before = diagnostics.total_errors
        _safe_row(apply, diagnostics, "wat_long", row_number, identity)
        if diagnostics.total_errors > before:
            part["invalid_rows"] += 1

    _consume_csv(source, ROLE_REQUIRED_HEADERS["wat_long"], row_handler, max_rows=max_rows)
    for identity, part in partitions.items():
        if part["duplicates"]:
            diagnostics.error("WAT_DUPLICATE_SITE_PARAMETER", f"Partition contains {part['duplicates']} duplicate SITE_ID/PARAM_ID keys.", role="wat_long", partition=identity)
    return partitions, records


def _parse_wat_wide(
    source: SourceFile,
    companions: dict[str, Any],
    diagnostics: Diagnostics,
    max_rows: int,
    *,
    collect_records: bool,
    selected_partition: tuple[str, str] | None = None,
) -> tuple[dict[tuple[str, str], dict[str, Any]], list[dict[str, Any]]]:
    specs = companions["specs_by_name"]
    if not specs:
        raise IngestionValidationError("WAT wide input requires file role 'wat_specs' so measurement columns can be safely identified and unpivoted.")
    partitions: dict[tuple[str, str], dict[str, Any]] = {}
    records: list[dict[str, Any]] = []
    measurement_columns: list[str] = []

    def row_handler(row: dict[str, Any], row_number: int) -> None:
        nonlocal measurement_columns
        if not measurement_columns:
            measurement_columns = sorted(set(source.headers) & set(specs))
            unknown_candidates = sorted(header for header in source.headers if header not in ROLE_REQUIRED_HEADERS["wat_wide"] and header not in {"PRODUCT_ID", "WAFER_NO", "RADIUS_MM", "ZONE", "IMPLANT_TOOL", "DIFFUSION_TOOL", "CMP_TOOL", "WAT_TESTER"} and header not in specs)
            if unknown_candidates:
                diagnostics.warning("WAT_WIDE_NONPARAM_COLUMNS", f"Ignored non-parameter wide columns: {', '.join(unknown_candidates[:12])}.", role="wat_wide")
            missing = sorted(set(specs) - set(measurement_columns))
            if missing:
                diagnostics.error("WAT_WIDE_MISSING_PARAMETERS", f"WAT wide input is missing spec-defined parameter columns: {', '.join(missing)}.", role="wat_wide")
        identity: tuple[str, str] | None = None
        try:
            identity = _identity(row)
        except ValueError as exc:
            diagnostics.error("INVALID_IDENTITY", str(exc), role="wat_wide", row_number=row_number)
            return
        part = partitions.setdefault(identity, {**_partition_base(identity), "parameters": {}, "oos": 0, "measurement_keys": set(), "duplicates": 0})
        part["row_count"] += 1

        def apply() -> None:
            product = _text(row.get("PRODUCT_ID"), "PRODUCT_ID", required=False, max_length=128)
            if product:
                part["products"].add(product)
            site_id = str(_text(row.get("SITE_ID"), "SITE_ID", max_length=128))
            site_name = str(_text(row.get("SITE_NAME"), "SITE_NAME", max_length=128))
            x_mm = _float(row.get("SITE_X_MM"), "SITE_X_MM")
            y_mm = _float(row.get("SITE_Y_MM"), "SITE_Y_MM")
            assert x_mm is not None and y_mm is not None
            if abs(x_mm) > MAX_COORDINATE_MM or abs(y_mm) > MAX_COORDINATE_MM:
                raise ValueError("site coordinates must be within +/-250 mm")
            die_x = _int(row.get("DIE_X"), "DIE_X")
            die_y = _int(row.get("DIE_Y"), "DIE_Y")
            for name in measurement_columns:
                spec = specs[name]
                value = _float(row.get(name), name)
                assert value is not None
                oos = value < spec["low"] or value > spec["high"]
                key = (site_id, spec["param_id"])
                if key in part["measurement_keys"]:
                    part["duplicates"] += 1
                else:
                    part["measurement_keys"].add(key)
                part["oos"] += int(oos)
                part["parameters"].setdefault((name, str(spec["unit"])), RunningStats()).add(value, oos=oos)
                if collect_records and (selected_partition is None or identity == selected_partition):
                    records.append({
                        "lot_id": identity[0], "wafer_id": identity[1],
                        "site_id": site_id, "site_name": site_name, "die_x": die_x, "die_y": die_y,
                        "x_mm": round(x_mm, 6), "y_mm": round(y_mm, 6), "param_id": spec["param_id"],
                        "param_name": name, "value": value, "unit": spec["unit"], "spec_low": spec["low"],
                        "spec_target": spec["target"], "spec_high": spec["high"], "status": "OOS" if oos else "PASS",
                        "module": spec["module"], "param_group": spec["param_group"],
                        "test_structure": spec["test_structure"], "criticality": spec["criticality"],
                    })
            part["coordinate_frames"].add("SITE_XY_MM")
            part["valid_rows"] += len(measurement_columns)
        before = diagnostics.total_errors
        _safe_row(apply, diagnostics, "wat_wide", row_number, identity)
        if diagnostics.total_errors > before:
            part["invalid_rows"] += 1

    _consume_csv(source, ROLE_REQUIRED_HEADERS["wat_wide"], row_handler, max_rows=max_rows)
    normalized_count = sum(part["valid_rows"] for part in partitions.values())
    if normalized_count > max_rows:
        diagnostics.error("WAT_WIDE_NORMALIZED_ROW_LIMIT", f"WAT wide unpivoting produces {normalized_count:,} measurements, above the {max_rows:,} normalized-row limit.", role="wat_wide")
    return partitions, records


def _parse_kla_primary(
    source: SourceFile,
    companions: dict[str, Any],
    diagnostics: Diagnostics,
    max_rows: int,
    *,
    collect_records: bool,
    selected_partition: tuple[str, str] | None = None,
) -> tuple[dict[tuple[str, str], dict[str, Any]], list[dict[str, Any]]]:
    partitions: dict[tuple[str, str], dict[str, Any]] = {}
    records: list[dict[str, Any]] = []

    def row_handler(row: dict[str, Any], row_number: int) -> None:
        identity: tuple[str, str] | None = None
        try:
            identity = _identity(row)
        except ValueError as exc:
            diagnostics.error("INVALID_IDENTITY", str(exc), role="kla_defects", row_number=row_number)
            return
        part = partitions.setdefault(identity, {**_partition_base(identity), "killer": 0, "classes": Counter(), "sizes": RunningStats(), "defect_ids": set(), "duplicates": 0, "killer_default_disagreements": 0})
        part["row_count"] += 1

        def apply() -> None:
            product = _text(row.get("PRODUCT_ID"), "PRODUCT_ID", required=False, max_length=128)
            if product:
                part["products"].add(product)
            defect_id = str(_text(row.get("DEFECT_ID"), "DEFECT_ID", max_length=128))
            if defect_id in part["defect_ids"]:
                part["duplicates"] += 1
            else:
                part["defect_ids"].add(defect_id)
            die_x = _int(row.get("DIE_X"), "DIE_X")
            die_y = _int(row.get("DIE_Y"), "DIE_Y")
            xrel_um = _float(row.get("XREL_UM"), "XREL_UM")
            yrel_um = _float(row.get("YREL_UM"), "YREL_UM")
            assert xrel_um is not None and yrel_um is not None
            x_mm, y_mm = xrel_um / 1000.0, yrel_um / 1000.0
            if abs(x_mm) > MAX_COORDINATE_MM or abs(y_mm) > MAX_COORDINATE_MM:
                raise ValueError("XREL_UM/YREL_UM convert outside +/-250 mm")
            class_code = str(_text(row.get("CLASS_CODE"), "CLASS_CODE", max_length=64))
            class_name = str(_text(row.get("CLASS_NAME"), "CLASS_NAME", max_length=128))
            class_group = str(_text(row.get("CLASS_GROUP"), "CLASS_GROUP", max_length=128))
            killer = _bool_yn(row.get("KILLER_FLAG"), "KILLER_FLAG")
            definition = companions["classes"].get(class_code)
            if companions["classes"] and definition is None:
                raise ValueError("CLASS_CODE is absent from kla_classes")
            if definition and (definition["name"] != class_name or definition["group"] != class_group):
                raise ValueError("KLA event class name/group disagrees with kla_classes")
            if definition and bool(definition["killer_default"]) != killer:
                part["killer_default_disagreements"] += 1
            size_um = _float(row.get("DEFECT_SIZE_UM"), "DEFECT_SIZE_UM")
            assert size_um is not None
            if size_um < 0:
                raise ValueError("DEFECT_SIZE_UM cannot be negative")
            part["killer"] += int(killer)
            part["classes"][(class_code, class_name, class_group)] += 1
            part["sizes"].add(size_um)
            part["coordinate_frames"].add("KLA_XREL_YREL_UM_TO_MM")
            part["valid_rows"] += 1
            if collect_records and (selected_partition is None or identity == selected_partition):
                records.append({
                    "lot_id": identity[0], "wafer_id": identity[1],
                    "defect_id": defect_id, "die_x": die_x, "die_y": die_y,
                    "x_mm": round(x_mm, 6), "y_mm": round(y_mm, 6), "xrel_um": xrel_um, "yrel_um": yrel_um,
                    "size_um": size_um, "class_code": class_code, "defect_class": class_name,
                    "class_group": class_group, "killer_flag": killer,
                    "layer": _text(row.get("LAYER"), "LAYER", max_length=128),
                    "cluster_id": 0, "is_repeater": "REPEATER" in class_name.upper(),
                    "inspection_tool": _text(row.get("INSPECTION_TOOL"), "INSPECTION_TOOL", max_length=128),
                    "inspection_recipe": _text(row.get("INSPECTION_RECIPE"), "INSPECTION_RECIPE", max_length=128),
                    "inspection_step": _text(row.get("INSPECTION_STEP"), "INSPECTION_STEP", max_length=128),
                    "reticle_shot_id": _text(row.get("RETICLE_SHOT_ID"), "RETICLE_SHOT_ID", max_length=128),
                })
        before = diagnostics.total_errors
        _safe_row(apply, diagnostics, "kla_defects", row_number, identity)
        if diagnostics.total_errors > before:
            part["invalid_rows"] += 1

    _consume_csv(source, ROLE_REQUIRED_HEADERS["kla_defects"], row_handler, max_rows=max_rows)
    for identity, part in partitions.items():
        if part["duplicates"]:
            diagnostics.error("KLA_DUPLICATE_DEFECT_ID", f"Partition contains {part['duplicates']} duplicate DEFECT_ID values.", role="kla_defects", partition=identity)
        if part["killer_default_disagreements"]:
            diagnostics.warning(
                "KLA_KILLER_DEFAULT_DISAGREEMENT",
                f"{part['killer_default_disagreements']} event killer flags differ from class defaults; event KILLER_FLAG remains authoritative.",
                role="kla_defects",
                partition=identity,
            )
    return partitions, records


def _reconcile_identity_sets(
    primary: dict[tuple[str, str], dict[str, Any]],
    companions: dict[str, Any],
    diagnostics: Diagnostics,
    source_type: str,
) -> None:
    primary_ids = set(primary)
    summary = companions.get("summary", {})
    if summary:
        missing = sorted(primary_ids - set(summary))
        extra = sorted(set(summary) - primary_ids)
        if missing or extra:
            diagnostics.error(
                f"{source_type}_SUMMARY_IDENTITY_MISMATCH",
                f"Summary identities differ from the primary file (missing={len(missing)}, extra={len(extra)}).",
            )

    for identity, part in primary.items():
        source_summary = summary.get(identity)
        if not source_summary:
            continue
        if source_type == "CP":
            if source_summary["gross"] != part["valid_rows"]:
                diagnostics.error("CP_SUMMARY_GROSS_MISMATCH", f"Summary GROSS_DIE={source_summary['gross']} but primary valid rows={part['valid_rows']}.", role="cp_summary", partition=identity)
            if source_summary["pass"] != part["pass"]:
                diagnostics.error("CP_SUMMARY_PASS_MISMATCH", f"Summary PASS_DIE={source_summary['pass']} but primary PASS_FAIL pass rows={part['pass']}.", role="cp_summary", partition=identity)
        elif source_type == "WAT":
            if source_summary["oos_count"] != part["oos"]:
                diagnostics.error("WAT_SUMMARY_OOS_MISMATCH", f"Summary OOS_SITE_PARAM_QTY={source_summary['oos_count']} but normalized OOS count={part['oos']}.", role="wat_summary", partition=identity)
        else:
            if source_summary["total"] != part["valid_rows"]:
                diagnostics.error("KLA_SUMMARY_TOTAL_MISMATCH", f"Summary TOTAL_DEFECTS={source_summary['total']} but primary valid rows={part['valid_rows']}.", role="kla_summary", partition=identity)
            if source_summary["killer"] != part["killer"]:
                diagnostics.error("KLA_SUMMARY_KILLER_MISMATCH", f"Summary KILLER_DEFECTS={source_summary['killer']} but event KILLER_FLAG count={part['killer']}.", role="kla_summary", partition=identity)


def _serialize_partition(source_type: str, part: dict[str, Any]) -> dict[str, Any]:
    products = sorted(part["products"])
    base: dict[str, Any] = {
        "partition_key": f"{part['lot_id']}::{part['wafer_id']}",
        "lot_id": part["lot_id"],
        "wafer_id": part["wafer_id"],
        "product_id": products[0] if len(products) == 1 else None,
        "product_provenance": "SOURCE" if len(products) == 1 else "UNAVAILABLE" if not products else "HETEROGENEOUS",
        "source_rows": part["row_count"],
        "valid_rows": part["valid_rows"],
        "invalid_rows": part["invalid_rows"],
        "coordinate_frames": sorted(part["coordinate_frames"]),
    }
    if source_type == "CP":
        parameters = []
        for (name, unit), stats in sorted(part["parameters"].items()):
            parameters.append({"param_name": name, "unit": unit, **stats.as_dict()})
        base.update({
            "pass_count": part["pass"],
            "fail_count": part["fail"],
            "yield_pct": round(part["pass"] / (part["pass"] + part["fail"]) * 100, 4) if part["pass"] + part["fail"] else None,
            "bins": [
                {"soft_bin": key[0], "hard_bin": key[1], "bin_name": key[2], "pass_fail": key[3], "count": count}
                for key, count in sorted(part["bins"].items())
            ],
            "parameters": parameters,
            "duplicate_die_keys": part["duplicate_die_keys"],
            "duplicate_coordinates": part["duplicate_coordinates"],
            "wafer_sizes_mm": sorted(part["wafer_sizes"]),
        })
    elif source_type == "WAT":
        base.update({
            "measurement_count": sum(stats.count for stats in part["parameters"].values()),
            "oos_count": part["oos"],
            "parameters": [
                {"param_name": name, "unit": unit, **stats.as_dict()}
                for (name, unit), stats in sorted(part["parameters"].items())
            ],
            "duplicate_site_parameter_keys": part["duplicates"],
        })
    else:
        base.update({
            "defect_count": part["valid_rows"],
            "killer_count": part["killer"],
            "size_um": part["sizes"].as_dict(),
            "classes": [
                {"class_code": key[0], "class_name": key[1], "class_group": key[2], "count": count}
                for key, count in sorted(part["classes"].items())
            ],
            "duplicate_defect_ids": part["duplicates"],
            "killer_default_disagreements": part["killer_default_disagreements"],
        })
    return base


def validate_ingestion_package(
    source_type: str,
    files: dict[str, Any],
    *,
    max_file_bytes: int = DEFAULT_MAX_FILE_BYTES,
    max_rows: int = DEFAULT_MAX_ROWS,
    collect_records: bool = False,
    selected_partition: tuple[str, str] | None = None,
) -> dict[str, Any]:
    """Validate a package while retaining one canonical result per LOT_ID/WAFER_ID."""
    source_type = str(source_type or "").strip().upper()
    if source_type not in SOURCE_TYPES:
        raise IngestionValidationError("source_type must be CP, WAT, or KLA.")
    if not isinstance(files, dict) or not files:
        raise IngestionValidationError("Attach package CSV files using explicit file-role field names.")
    role_spec = PACKAGE_ROLES[source_type]
    roles = set(files)
    unknown = sorted(roles - role_spec["allowed"])
    if unknown:
        raise IngestionValidationError(f"Unsupported {source_type} file roles: {', '.join(unknown)}.")
    if not any(required <= roles for required in role_spec["required_any"]):
        expected = " or ".join(" + ".join(sorted(required)) for required in role_spec["required_any"])
        raise IngestionValidationError(f"{source_type} package requires {expected}.")
    if source_type == "WAT" and {"wat_long", "wat_wide"} <= roles:
        raise IngestionValidationError("Provide either wat_long or wat_wide as the WAT primary, not both.")
    if max_file_bytes < 1 or max_rows < 1:
        raise IngestionValidationError("Configured file and row limits must be positive.")

    sources = {role: _as_source(role, value) for role, value in files.items()}
    for source in sources.values():
        _fingerprint(source, max_file_bytes)
    diagnostics = Diagnostics()
    records: list[dict[str, Any]] = []
    parametric_records: list[dict[str, Any]] = []

    if source_type == "CP":
        companions = _parse_cp_companions(sources, diagnostics, max_rows)
        partitions, records, parametric_records = _parse_cp_primary(
            sources["cp_die"], companions, diagnostics, max_rows,
            collect_records=collect_records, selected_partition=selected_partition,
        )
        primary_role = "cp_die"
    elif source_type == "WAT":
        companions = _parse_wat_companions(sources, diagnostics, max_rows)
        primary_role = "wat_long" if "wat_long" in sources else "wat_wide"
        if primary_role == "wat_long":
            partitions, records = _parse_wat_long(
                sources[primary_role], companions, diagnostics, max_rows,
                collect_records=collect_records, selected_partition=selected_partition,
            )
        else:
            partitions, records = _parse_wat_wide(
                sources[primary_role], companions, diagnostics, max_rows,
                collect_records=collect_records, selected_partition=selected_partition,
            )
    else:
        companions = _parse_kla_companions(sources, diagnostics, max_rows)
        partitions, records = _parse_kla_primary(
            sources["kla_defects"], companions, diagnostics, max_rows,
            collect_records=collect_records, selected_partition=selected_partition,
        )
        primary_role = "kla_defects"

    if not partitions:
        raise IngestionValidationError("No canonical LOT_ID/WAFER_ID partitions were found.", diagnostics.items)
    if source_type != "CP":
        for identity, part in partitions.items():
            if len(part["products"]) > 1:
                diagnostics.error(
                    f"{source_type}_PRODUCT_HETEROGENEITY",
                    f"Each {source_type} wafer partition may contain at most one source PRODUCT_ID.",
                    role=primary_role,
                    partition=identity,
                )
    _reconcile_identity_sets(partitions, companions, diagnostics, source_type)
    serialized = [_serialize_partition(source_type, partitions[key]) for key in sorted(partitions)]
    source_summaries = companions.get("summary", {})
    for partition in serialized:
        source_summary = source_summaries.get((partition["lot_id"], partition["wafer_id"]))
        if source_summary is not None:
            partition["source_summary"] = source_summary
    status = diagnostics.as_dict()
    files_meta = [
        {
            "role": source.role,
            "filename": source.filename,
            "byte_size": source.byte_size,
            "row_count": source.row_count,
            "checksum_sha256": source.checksum_sha256,
            "parser_mapping_version": PARSER_MAPPING_VERSION,
            "detected_headers": source.headers,
        }
        for source in sorted(sources.values(), key=lambda item: item.role)
    ]
    result: dict[str, Any] = {
        "source_type": source_type,
        "parser_mapping_version": PARSER_MAPPING_VERSION,
        "primary_role": primary_role,
        "status": status["status"],
        "valid": not status["error_count"],
        "partition_count": len(serialized),
        "partitions": serialized,
        "files": files_meta,
        "diagnostics": status,
        "persistence": {
            "safe": len(serialized) == 1 and not status["error_count"],
            "mode": "SINGLE_WAFER_NORMALIZED" if len(serialized) == 1 else "SELECTED_PARTITION_REQUIRED",
            "reason": None if len(serialized) == 1 else "This package contains multiple wafers. Submit it to /api/ingestion/packages/persist with one explicit selected_lot_id and selected_wafer_id; one request creates one wafer dataset.",
        },
    }
    if collect_records:
        result["records"] = records
        if selected_partition is not None:
            result["collected_partition"] = {
                "lot_id": selected_partition[0],
                "wafer_id": selected_partition[1],
            }
        if source_type == "CP":
            result["parametric_records"] = parametric_records
    return result


def parse_ingestion_package_partition(
    source_type: str,
    files: dict[str, Any],
    selected_lot_id: str,
    selected_wafer_id: str,
    *,
    max_file_bytes: int = DEFAULT_MAX_FILE_BYTES,
    max_rows: int = DEFAULT_MAX_ROWS,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Revalidate a whole package and normalize only one canonical partition."""
    try:
        selected = (
            str(_text(selected_lot_id, "selected_lot_id", max_length=128)),
            str(_text(selected_wafer_id, "selected_wafer_id", max_length=128)),
        )
    except ValueError as exc:
        raise IngestionValidationError(str(exc)) from exc
    package = validate_ingestion_package(
        source_type,
        files,
        max_file_bytes=max_file_bytes,
        max_rows=max_rows,
        collect_records=True,
        selected_partition=selected,
    )
    if not package["valid"]:
        raise IngestionValidationError(
            "Package failed real-data validation; no partition was persisted.",
            package["diagnostics"]["items"],
        )
    partition = next(
        (
            item for item in package["partitions"]
            if item["lot_id"] == selected[0] and item["wafer_id"] == selected[1]
        ),
        None,
    )
    if partition is None:
        raise IngestionValidationError(
            "The selected LOT_ID/WAFER_ID partition is absent from the validated primary source.",
            [{
                "severity": "ERROR",
                "code": "SELECTED_PARTITION_NOT_FOUND",
                "message": "The requested canonical partition was not found in the validated package.",
                "partition": {"lot_id": selected[0], "wafer_id": selected[1]},
            }],
        )

    primary_file = next(item for item in package["files"] if item["role"] == package["primary_role"])
    records = package["records"]
    if len(records) != partition["valid_rows"]:
        raise IngestionValidationError(
            "Selected partition normalization did not produce the validated number of records.",
            [{
                "severity": "ERROR",
                "code": "SELECTED_PARTITION_RECORD_MISMATCH",
                "message": "Collected normalized records do not match the selected partition summary.",
                "partition": {"lot_id": selected[0], "wafer_id": selected[1]},
            }],
        )
    if source_type == "WAT":
        # Existing SQL status uses PASS/WARN/FAIL; sourceStatus retains OOS.
        for record in records:
            record["status"] = "FAIL" if record["status"] == "OOS" else "PASS"

    role_manifest = [
        {
            **file_meta,
            "column_mapping": {header.lower(): header for header in file_meta["detected_headers"]},
        }
        for file_meta in package["files"]
    ]
    summary = {
        "data_type": source_type,
        "lot_id": partition["lot_id"],
        "wafer_id": partition["wafer_id"],
        "product_name": partition["product_id"] or "UNAVAILABLE",
        "product_provenance": partition["product_provenance"],
        "source_filename": primary_file["filename"],
        "file_format": "CSV",
        "total_rows": partition["source_rows"],
        "valid_rows": partition["valid_rows"],
        "error_rows": partition["invalid_rows"],
        "parameter_names": [item["param_name"] for item in partition.get("parameters", [])],
        "selected_parameter": partition.get("parameters", [{}])[0].get("param_name") if partition.get("parameters") else None,
        "stats": {
            "gross_items": partition["valid_rows"],
            "pass_count": partition.get("pass_count", 0),
            "fail_count": partition.get("fail_count", partition.get("oos_count", 0)),
            "yield_pct": partition.get("yield_pct"),
            "defect_count": partition.get("defect_count", 0),
            "killer_defect_count": partition.get("killer_count", 0),
        },
        "source_role": package["primary_role"],
        "source_checksum_sha256": primary_file["checksum_sha256"],
        "parser_mapping_version": package["parser_mapping_version"],
        "package_diagnostics": {
            "validation": package["diagnostics"],
            "role_manifest": role_manifest,
            "selected_partition": {"lot_id": selected[0], "wafer_id": selected[1]},
            "source_package_partition_count": package["partition_count"],
        },
        "partition_count": 1,
        "source_package_partition_count": package["partition_count"],
        "coordinate_frames": partition["coordinate_frames"],
        "source_summary": partition.get("source_summary"),
        "selected_partition": partition,
    }
    mapping = {header.lower(): header for header in primary_file["detected_headers"]}
    parsed = {
        "summary": summary,
        "records": records,
        "mapping": mapping,
        "partition": partition,
        "parametric_records": package.get("parametric_records", []),
    }
    return package, parsed


def parse_ingestion_file(source_type: str, filename: str, content: bytes) -> dict[str, Any]:
    """Legacy single-file adapter; rejects multi-wafer input rather than corrupting identity."""
    source_type = str(source_type or "").strip().upper()
    extension = os.path.splitext(filename.lower())[1]
    if extension == ".xlsx":
        # Keep a bounded compatibility path for prior uploads. Real package intake is CSV-only.
        if len(content) > DEFAULT_MAX_FILE_BYTES:
            raise IngestionValidationError(f"Source file exceeds the {DEFAULT_MAX_FILE_BYTES:,}-byte limit.")
        try:
            workbook = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
            values = workbook.active.iter_rows(values_only=True)
            headers = next(values, None)
            if not headers:
                raise IngestionValidationError("Excel file must include a header row.")
            output = io.StringIO(newline="")
            writer = csv.writer(output)
            writer.writerow(headers)
            count = 0
            for row in values:
                count += 1
                if count > DEFAULT_MAX_ROWS:
                    raise IngestionValidationError(f"Source file exceeds the {DEFAULT_MAX_ROWS:,}-row limit.")
                writer.writerow(row)
            content = output.getvalue().encode("utf-8")
            filename = os.path.splitext(filename)[0] + ".csv"
        except IngestionValidationError:
            raise
        except Exception as exc:
            raise IngestionValidationError("Excel file could not be read. Upload a valid .xlsx workbook.") from exc
    elif extension != ".csv":
        raise IngestionValidationError("Only .csv and .xlsx source files are supported by the legacy endpoint.")

    role = {"CP": "cp_die", "WAT": "wat_long", "KLA": "kla_defects"}.get(source_type)
    if not role:
        raise IngestionValidationError("source_type must be CP, WAT, or KLA.")
    package = validate_ingestion_package(source_type, {role: SourceFile(role, filename, io.BytesIO(content))}, collect_records=True)
    if package["partition_count"] != 1:
        raise IngestionValidationError(
            f"Legacy upload accepts one wafer only; this source contains {package['partition_count']} LOT_ID/WAFER_ID partitions. Use /api/ingestion/packages/validate.",
            package["diagnostics"]["items"],
        )
    if not package["valid"]:
        raise IngestionValidationError("Source file failed real-data validation.", package["diagnostics"]["items"])
    partition = package["partitions"][0]
    records = package["records"]
    if source_type == "WAT":
        # Existing normalized table uses PASS/WARN/FAIL; source OOS is semantically FAIL.
        for record in records:
            record["status"] = "FAIL" if record["status"] == "OOS" else "PASS"
    summary = {
        "data_type": source_type,
        "lot_id": partition["lot_id"],
        "wafer_id": partition["wafer_id"],
        "product_name": partition["product_id"] or "UNAVAILABLE",
        "product_provenance": partition["product_provenance"],
        "source_filename": filename,
        "file_format": "CSV",
        "total_rows": package["files"][0]["row_count"],
        "valid_rows": partition["valid_rows"],
        "error_rows": partition["invalid_rows"],
        "parameter_names": [item["param_name"] for item in partition.get("parameters", [])],
        "selected_parameter": partition.get("parameters", [{}])[0].get("param_name") if partition.get("parameters") else None,
        "stats": {
            "gross_items": partition["valid_rows"],
            "pass_count": partition.get("pass_count", 0),
            "fail_count": partition.get("fail_count", partition.get("oos_count", 0)),
            "yield_pct": partition.get("yield_pct"),
            "defect_count": partition.get("defect_count", 0),
            "killer_defect_count": partition.get("killer_count", 0),
        },
        "source_role": role,
        "source_checksum_sha256": package["files"][0]["checksum_sha256"],
        "parser_mapping_version": PARSER_MAPPING_VERSION,
        "package_diagnostics": package["diagnostics"],
        "partition_count": 1,
        "coordinate_frames": partition["coordinate_frames"],
    }
    mapping = {header.lower(): header for header in package["files"][0]["detected_headers"]}
    return {"summary": summary, "records": records, "mapping": mapping, "partition": partition, "parametric_records": package.get("parametric_records", [])}
