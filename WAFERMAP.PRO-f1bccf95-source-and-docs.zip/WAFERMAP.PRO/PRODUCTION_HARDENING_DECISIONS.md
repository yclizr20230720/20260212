# WAFERMAP.PRO Production Hardening Decisions

## Decision 1 — Owner-scoped access now; role expansion when business roles exist

### Status

**Implemented baseline:** authentication is mandatory for retained source data, package persistence, dataset/library access, analysis jobs, import history, and generated JSON report downloads.

The React public host performs the Manus OAuth callback and holds the signed, host-only session cookie. The private Flask service verifies that session for every protected request. It resolves the authenticated `openId` to the existing database user and performs every dataset/import/job/report query through the owner scope. A user-controlled `ownerId`, `ownerOpenId`, request header, or browser payload is not accepted as an authorization source.

### Access matrix

| Capability | Anonymous | Authenticated operator | Future role gate |
|---|---:|---:|---|
| Geometry-only wafer/reticle workspace | Allowed | Allowed | None |
| Download empty CSV templates | Allowed | Allowed | None |
| Validate local package structure before persistence | Allowed only if no source is retained | Allowed | Optional rate limit |
| Persist a selected CP/WAT/KLA partition | Denied | Own data only | `fab_operator` / entitlement |
| View datasets, import runs, job history, or JSON reports | Denied | Own records only | `fab_operator` |
| Queue CP/WAT/KLA aggregate analysis | Denied | Own retained datasets only | Per-user quota |
| Read another user's source or report | Denied | Denied | Explicit project/lot sharing grant only |
| Organization-wide audit, retention, and access review | Denied | Denied | `quality_admin` |

### Rationale

A single-operator ownership model is safer than introducing speculative admin roles. WAFERMAP.PRO has no approved organization, project, or delegation model yet. The operational boundary is therefore **owner-only by default**. Owner-less records from older releases are not silently adopted.

When the business provides a user-to-fab/project authorization source, add a `dataset_access_grants` table and a `role`/`organization` claim mapping. Keep the same authorization pipeline: authentication first, requested record lookup second, authorization predicate third. Do not use a client-side visibility rule as the security control.

### Required controls before future RBAC expansion

1. Define organization, project, product, lot, and wafer sharing policy.
2. Add immutable access-grant audit records and revocation timestamps.
3. Scope object-storage download URLs to the authorized operation and expiry.
4. Separate `quality_admin` review capabilities from source-data modification.
5. Test cross-owner denial, revoked access, and stale-session behavior for every endpoint.

## Decision 2 — Canvas remains the deterministic baseline; tiles/WebGL are a staged scale upgrade

### Current renderer

The application renders the interactive wafer using a React-controlled 2D Canvas. It uses direct drawing, finite viewport transforms, `ResizeObserver`, pointer capture, local-coordinate pan, device-pixel-ratio capping, and compact CP overlay transport. Geometry works without manufacturing data; imported CP/WAT/KLA records add measured overlays only after a retained source is selected.

This is the correct baseline for one active selected wafer and provides a reliable Canvas fallback even if a GPU context cannot be created.

### Scale gates

| Gate | Observable threshold | Action |
|---|---|---|
| **Canvas fast path** | One wafer, typical die count, one CP overlay, smooth interaction on reference hardware | Keep existing Canvas renderer. |
| **Tile API** | Payload transfer or initial paint dominates; repeated zoom/pan requests visit a small fraction of a dense wafer | Add server tile endpoints keyed by dataset, layer, level, tile X/Y, filter version, and source hash. |
| **WebGL2 instancing** | Visible drawn rectangles/markers exceed Canvas frame budget or simultaneous overlays are required | Add a WebGL2 wafer layer with instanced quads/points; retain Canvas fallback and shared transforms. |
| **Binary transport** | JSON parsing/object allocation is the bottleneck | Return compact binary/Arrow-compatible coordinate/value columns with explicit schema/version headers. |
| **Worker aggregation** | Hover selection or client filtering blocks the main thread | Move hit indexes, bin filters, and tile decoding to a Web Worker. |

### Tile contract

A future tile endpoint should be owner-scoped and aggregate-first:

```text
GET /api/ingestion/datasets/{datasetId}/tiles
  ?layer=cp_bin|cp_param|wat|kla
  &level={0..N}&x={tileX}&y={tileY}
  &filter_version={hash}
```

The response must contain only points/aggregates required for that viewport, plus retained dataset identity, selected LotID/WaferID, source hash, coordinate-frame declaration, and filter version. It must not expose raw source-file bytes or an unbounded all-wafer record set.

### WebGL2 implementation boundary

- One renderer owns the shared wafer-to-screen transform; Canvas and WebGL never compete for independent pan/zoom state.
- Use one instanced buffer for die cells and one for marker layers. Color maps and bin filters remain uniforms or compact attributes.
- Perform spatial selection through a CPU bucket index or GPU picking only after profiling demonstrates need.
- Use `OffscreenCanvas` where supported, but preserve an accessible non-WebGL Canvas path and reduced-motion behavior.
- Add explicit memory caps, LRU tile eviction, abortable fetches, and frame-time telemetry before enabling concurrent multi-wafer displays.

### Validation before rollout

A tile/WebGL release must benchmark first-paint time, interaction frame percentile, memory, source payload size, and parity of selected-die/bin results against the Canvas baseline. Correctness is more important than maximum die count: every tile must preserve selected source identity, coordinate system, filter state, and owner authorization.
