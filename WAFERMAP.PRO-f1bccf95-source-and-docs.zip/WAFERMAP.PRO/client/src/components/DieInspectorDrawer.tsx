import React from 'react';
import { Activity, Database, Layers, MapPin, X } from 'lucide-react';
import { CpDieRecord, DieInstance, ShotInstance } from '../types';

interface DieInspectorDrawerProps {
  die: DieInstance | null;
  shot: ShotInstance | null;
  cpRecord: CpDieRecord | null;
  onClose: () => void;
}

function valueOrUnavailable(value: number | null | undefined, unit = ''): string {
  return value == null || !Number.isFinite(value) ? 'Unavailable' : `${value}${unit ? ` ${unit}` : ''}`;
}

export const DieInspectorDrawer: React.FC<DieInspectorDrawerProps> = ({ die, shot, cpRecord, onClose }) => {
  if (!die && !cpRecord) return null;
  const hasCp = cpRecord != null;
  const dieX = cpRecord?.die_x ?? die!.global_x;
  const dieY = cpRecord?.die_y ?? die!.global_y;
  const centerX = cpRecord?.x_mm ?? die!.center_x_mm;
  const centerY = cpRecord?.y_mm ?? die!.center_y_mm;

  return (
    <aside id="die-inspector-drawer" className="fixed bottom-0 right-0 z-40 flex w-full flex-col gap-4 border-t border-[#222] bg-[#0C0C0C] p-5 text-xs text-[#E5E5E5] shadow-2xl sm:w-96 sm:border-l sm:border-t-0">
      <header className="flex items-center justify-between border-b border-[#222] pb-3">
        <div className="flex items-center gap-2.5"><div className={`rounded-xs border p-1.5 ${hasCp ? 'border-[#00FF9C]/40 bg-[#00331f] text-[#00FF9C]' : 'border-[#333] bg-[#111] text-[#777]'}`}><Database className="h-4 w-4" /></div><div><h3 className="font-mono text-sm font-bold">Die ({dieX}, {dieY})</h3><div className="font-mono text-[10px] text-[#666]">{hasCp ? 'Retained CP record' : 'Geometry only · no CP record'}</div></div></div>
        <button type="button" onClick={onClose} className="rounded p-1.5 text-[#666] hover:bg-[#1A1A1A] hover:text-white" aria-label="Close die inspector"><X className="h-4 w-4" /></button>
      </header>

      {cpRecord ? (
        <section className={`flex items-center justify-between rounded-sm border p-3 font-mono ${cpRecord.bin_quality === 'PASS' ? 'border-[#00FF9C]/40 bg-[#002214]' : cpRecord.bin_quality === 'FAIL' ? 'border-[#FF3E3E]/40 bg-[#260a0a]' : 'border-[#333] bg-[#111]'}`}>
          <div><div className="text-[9px] uppercase tracking-[0.2em] text-[#888]">Imported probe result</div><div className={`mt-0.5 text-sm font-bold ${cpRecord.bin_quality === 'PASS' ? 'text-[#00FF9C]' : cpRecord.bin_quality === 'FAIL' ? 'text-[#FF5A52]' : 'text-[#AAA]'}`}>{cpRecord.bin_name}</div></div>
          <div className="text-right"><div className="text-[9px] uppercase tracking-[0.2em] text-[#888]">Bin code</div><div className="text-base font-bold">{cpRecord.bin_code}</div></div>
        </section>
      ) : (
        <section className="rounded-sm border border-[#FFAE00]/35 bg-[#FFAE00]/[0.04] p-3"><div className="font-mono text-[10px] font-bold uppercase tracking-wider text-[#FFAE00]">Measurement values unavailable</div><p className="mt-1.5 text-[10px] leading-relaxed text-[#777]">This cell belongs to the editable geometry template. No pass/fail, bin, electrical, or defect result is inferred.</p></section>
      )}

      <section className="flex flex-col gap-2 rounded-sm border border-[#222] bg-[#111] p-3 font-mono text-[11px]">
        <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.2em] text-[#888]"><MapPin className="h-3 w-3 text-[#00FF9C]" />Physical geometry</div>
        <div className="mt-1 grid grid-cols-2 gap-2"><div><span className="text-[#666]">Center X:</span> <strong>{centerX} mm</strong></div><div><span className="text-[#666]">Center Y:</span> <strong>{centerY} mm</strong></div><div><span className="text-[#666]">Radial:</span> <strong className="text-[#FFAE00]">{Math.hypot(centerX, centerY).toFixed(3)} mm</strong></div><div><span className="text-[#666]">Coordinate:</span> <strong>{hasCp ? 'Imported' : 'Computed'}</strong></div></div>
      </section>

      {die && <section className="flex flex-col gap-2 rounded-sm border border-[#222] bg-[#111] p-3 font-mono text-[11px]">
        <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.2em] text-[#888]"><Layers className="h-3 w-3 text-[#00FF9C]" />Placement hierarchy</div>
        <div className="mt-1 grid grid-cols-2 gap-2"><div><span className="text-[#666]">Shot:</span> <strong>S({die.shot_row},{die.shot_col})</strong></div><div><span className="text-[#666]">Reticle:</span> <strong className="text-[#00FF9C]">R({die.reticle_row},{die.reticle_col})</strong></div><div><span className="text-[#666]">Type:</span> <strong>{die.die_type}</strong></div><div><span className="text-[#666]">Usability:</span> <strong>{die.status}</strong></div></div>
      </section>}

      <section className="flex flex-col gap-2 rounded-sm border border-[#222] bg-[#111] p-3 font-mono text-[11px]">
        <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.2em] text-[#888]"><Activity className="h-3 w-3 text-[#00FF9C]" />Imported CP measurements</div>
        <div className="mt-1 grid grid-cols-2 gap-2"><div><span className="text-[#666]">Parameter:</span> <strong className="text-[#00FF9C]">{valueOrUnavailable(cpRecord?.param_value, cpRecord?.param_unit ?? '')}</strong></div><div><span className="text-[#666]">Frequency:</span> <strong>{valueOrUnavailable(cpRecord?.test_freq_ghz, 'GHz')}</strong></div><div><span className="text-[#666]">Leakage:</span> <strong className="text-[#FFAE00]">{valueOrUnavailable(cpRecord?.leakage_ua, 'µA')}</strong></div><div><span className="text-[#666]">Defects:</span> <strong className="text-[#777]">Use KLA source</strong></div></div>
      </section>

      {shot && <section className="rounded-sm border border-[#222] bg-[#111] p-3 font-mono text-[11px]"><div className="text-[9px] uppercase tracking-[0.2em] text-[#666]">Parent shot geometry</div><div className="mt-1 font-bold text-white">{shot.total_dies} placed cells · {shot.status}</div><div className="mt-1 text-[10px] text-[#666]">Shot yield is shown only when calculated from matching retained CP records.</div></section>}
    </aside>
  );
};
