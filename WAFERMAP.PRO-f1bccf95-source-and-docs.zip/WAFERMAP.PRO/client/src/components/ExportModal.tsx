import React from 'react';
import { Database, Download, FileJson, ShieldAlert, X } from 'lucide-react';
import { IngestedDataType, IngestedWaferData, WaferLayoutResponse } from '../types';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  layoutData: WaferLayoutResponse | null;
  activeDatasets: Partial<Record<IngestedDataType, IngestedWaferData>>;
}

function downloadGeometry(layoutData: WaferLayoutResponse) {
  const { metadata, dies, shots } = layoutData;
  const payload = {
    artifact_type: 'WAFERMAP.PRO_GEOMETRY_CONFIGURATION',
    scope: 'Deterministic geometry only. Contains no manufacturing measurements or SEMI/KLARF source representation.',
    geometry: {
      diameter_mm: metadata.diameter_mm,
      edge_exclusion_mm: metadata.edge_exclusion_mm,
      notch_angle_deg: metadata.notch_angle_deg,
      center_offset_x_mm: metadata.center_offset_x_mm,
      center_offset_y_mm: metadata.center_offset_y_mm,
      reticle_rows: metadata.reticle_rows,
      reticle_cols: metadata.reticle_cols,
      reticle_field_w_mm: metadata.reticle_field_w_mm,
      reticle_field_h_mm: metadata.reticle_field_h_mm,
      shot_pitch_x_mm: metadata.shot_pitch_x_mm,
      shot_pitch_y_mm: metadata.shot_pitch_y_mm,
      placed_full_dies: metadata.gross_die_count,
      partial_edge_cells: metadata.partial_die_count,
      shot_fields: metadata.total_shots,
    },
    dies: dies.map(({ global_x, global_y, center_x_mm, center_y_mm, width_mm, height_mm, shot_row, shot_col, reticle_row, reticle_col, die_type, status, is_fully_inside_usable_area }) => ({ global_x, global_y, center_x_mm, center_y_mm, width_mm, height_mm, shot_row, shot_col, reticle_row, reticle_col, die_type, status, is_fully_inside_usable_area })),
    shots,
  };
  const url = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' }));
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = 'wafer_geometry_configuration.json';
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 0);
}

export const ExportModal: React.FC<ExportModalProps> = ({ isOpen, onClose, layoutData, activeDatasets }) => {
  if (!isOpen || !layoutData) return null;
  const activeSources = (Object.keys(activeDatasets) as IngestedDataType[]).filter((type) => activeDatasets[type]);

  return (
    <div id="export-standards-modal" className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md" role="dialog" aria-modal="true" aria-label="Export availability">
      <section className="w-full max-w-3xl overflow-hidden rounded-sm border border-[#222] bg-[#0C0C0C] text-[#E5E5E5] shadow-2xl">
        <header className="flex items-center justify-between border-b border-[#222] bg-[#111] px-6 py-4"><div className="flex items-center gap-3.5"><div className="rounded-sm border border-[#222] bg-[#080808] p-2 text-[#00FF9C]"><Download className="h-5 w-5" /></div><div><h2 className="text-base font-extrabold tracking-tight">EXPORT.GOVERNANCE</h2><p className="mt-1 font-mono text-[11px] text-[#666]">Source records are never replaced with generated E142, G85, KLARF, bin, or defect content.</p></div></div><button type="button" onClick={onClose} className="rounded p-1.5 text-[#666] hover:bg-[#1A1A1A] hover:text-white" aria-label="Close export"><X className="h-5 w-5" /></button></header>

        <div className="space-y-4 p-6">
          <section className="rounded-sm border border-[#FFAE00]/35 bg-[#FFAE00]/[0.04] p-5"><div className="flex items-center gap-2 text-[#FFAE00]"><ShieldAlert className="h-5 w-5" /><h3 className="text-sm font-bold">Manufacturing exports unavailable</h3></div><p className="mt-2 text-xs leading-relaxed text-[#999]">The frontend does not have a source-preserving export endpoint for normalized retained records. Standards exports remain disabled until the backend can serialize the original source-backed CP/WAT/KLA dataset with provenance and full-record coverage.</p></section>

          <section className="rounded-sm border border-[#222] bg-[#111] p-5"><div className="flex items-center justify-between gap-4"><div><div className="flex items-center gap-2 text-sm font-bold"><Database className="h-4 w-4 text-[#00E5FF]" />Active retained sources</div><p className="mt-1 text-xs text-[#777]">{activeSources.length ? activeSources.map((type) => `${type} #${activeDatasets[type]!.dataset.dataset_id}`).join(' · ') : 'No real data loaded · geometry-only workspace'}</p></div><span className="rounded border border-[#333] bg-[#080808] px-2 py-1 font-mono text-[10px] text-[#777]">READ ONLY</span></div>
            <div className="mt-4 grid gap-2 sm:grid-cols-2">{['SEMI E142 wafer map', 'SEMI G85 map', 'KLARF inspection data', 'Normalized manufacturing CSV'].map((label) => <div key={label} className="flex items-center justify-between rounded border border-[#292929] bg-[#0b0b0b] px-3 py-2.5 text-xs"><span className="text-[#AAA]">{label}</span><span className="font-mono text-[9px] uppercase text-[#666]">Backend required</span></div>)}</div>
          </section>

          <section className="rounded-sm border border-[#00E5FF]/25 bg-[#00E5FF]/[0.03] p-5"><div className="flex items-center gap-2 text-sm font-bold text-[#00E5FF]"><FileJson className="h-4 w-4" />Geometry configuration JSON</div><p className="mt-2 text-xs leading-relaxed text-[#888]">This optional frontend download contains only wafer dimensions, deterministic placement coordinates, shot topology, and editable reticle labels. It intentionally omits source identity and all process, bin, yield, electrical, and defect values.</p><button type="button" onClick={() => downloadGeometry(layoutData)} className="mt-4 flex items-center gap-2 rounded-sm border border-[#00E5FF]/45 bg-[#00E5FF]/10 px-4 py-2 text-xs font-bold uppercase tracking-wider text-[#00E5FF] hover:bg-[#00E5FF]/20"><Download className="h-4 w-4" />Download geometry JSON</button></section>
        </div>

        <footer className="flex justify-end border-t border-[#222] bg-[#111] px-6 py-3.5"><button type="button" onClick={onClose} className="rounded-sm border border-[#222] bg-[#080808] px-5 py-2 text-xs font-bold uppercase tracking-widest text-[#888] hover:text-white">Close</button></footer>
      </section>
    </div>
  );
};
