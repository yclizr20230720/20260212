import { useCallback, useEffect, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Clock3,
  CloudDownload,
  FileText,
  History,
  Loader2,
  RefreshCw,
  ShieldAlert,
  X,
} from 'lucide-react';
import {
  AnalysisJobRecord,
  AnalysisJobsResponse,
  AnalysisReportRecord,
  AnalysisReportsResponse,
} from '../types';

interface AnalysisHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type HistoryState = 'ready' | 'authentication-required' | 'service-unavailable' | 'error';

function formatTimestamp(value?: string | null): string {
  if (!value) return 'Not reported';
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? value : parsed.toLocaleString();
}

function asRecord(value: unknown): Record<string, unknown> | null {
  return value && typeof value === 'object' ? value as Record<string, unknown> : null;
}

function normalizeJob(value: unknown): AnalysisJobRecord | null {
  const item = asRecord(value);
  if (!item) return null;
  const jobId = item.job_id ?? item.id;
  if ((typeof jobId !== 'string' && typeof jobId !== 'number') || typeof item.status !== 'string') return null;
  return {
    job_id: jobId,
    status: item.status,
    cp_dataset_id: item.cp_dataset_id == null ? null : Number(item.cp_dataset_id),
    wat_dataset_id: item.wat_dataset_id == null ? null : Number(item.wat_dataset_id),
    kla_dataset_id: item.kla_dataset_id == null ? null : Number(item.kla_dataset_id),
    created_at: item.created_at == null ? null : String(item.created_at),
    queued_at: item.queued_at == null ? null : String(item.queued_at),
    started_at: item.started_at == null ? null : String(item.started_at),
    completed_at: item.completed_at == null ? null : String(item.completed_at),
    updated_at: item.updated_at == null ? null : String(item.updated_at),
  };
}

function normalizeReport(value: unknown): AnalysisReportRecord | null {
  const item = asRecord(value);
  if (!item) return null;
  const id = item.id ?? item.report_id;
  const filename = item.filename ?? item.report_filename;
  if ((typeof id !== 'string' && typeof id !== 'number') || typeof filename !== 'string' || !filename.trim()) return null;
  return {
    id,
    filename,
    job_id: item.job_id == null ? null : item.job_id as number | string,
    cp_dataset_id: item.cp_dataset_id == null ? null : Number(item.cp_dataset_id),
    wat_dataset_id: item.wat_dataset_id == null ? null : Number(item.wat_dataset_id),
    kla_dataset_id: item.kla_dataset_id == null ? null : Number(item.kla_dataset_id),
    created_at: item.created_at == null ? null : String(item.created_at),
    completed_at: item.completed_at == null ? null : String(item.completed_at),
  };
}

function recordsFromPayload<T>(payload: unknown, key: 'jobs' | 'reports', normalize: (value: unknown) => T | null): T[] {
  const body = asRecord(payload);
  const values = Array.isArray(payload) ? payload : body && Array.isArray(body[key]) ? body[key] : [];
  return values.map(normalize).filter((item): item is T => item !== null);
}

function datasetReferences(record: Pick<AnalysisJobRecord, 'cp_dataset_id' | 'wat_dataset_id' | 'kla_dataset_id'>): string {
  const references = [
    record.cp_dataset_id ? `CP #${record.cp_dataset_id}` : null,
    record.wat_dataset_id ? `WAT #${record.wat_dataset_id}` : null,
    record.kla_dataset_id ? `KLA #${record.kla_dataset_id}` : null,
  ].filter(Boolean);
  return references.length ? references.join(' · ') : 'No source dataset references returned';
}

function safeDownloadFilename(header: string | null, fallback: string): string {
  const encoded = header?.match(/filename\*=UTF-8''([^;]+)/i)?.[1];
  const plain = header?.match(/filename="?([^";]+)"?/i)?.[1];
  const candidate = encoded ? decodeURIComponent(encoded) : plain || fallback;
  return candidate.replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').slice(0, 180) || fallback;
}

function statusClass(status: string): string {
  const normalized = status.toUpperCase();
  if (normalized === 'COMPLETED') return 'border-[#00FF9C]/40 bg-[#00FF9C]/10 text-[#00FF9C]';
  if (normalized === 'QUEUED' || normalized === 'PENDING' || normalized === 'PROCESSING' || normalized === 'RUNNING') return 'border-[#00E5FF]/40 bg-[#00E5FF]/10 text-[#00E5FF]';
  if (normalized === 'FAILED' || normalized === 'REJECTED') return 'border-red-700/60 bg-red-950/30 text-red-300';
  return 'border-neutral-600 bg-neutral-800 text-neutral-300';
}

export function AnalysisHistoryModal({ isOpen, onClose }: AnalysisHistoryModalProps) {
  const [jobs, setJobs] = useState<AnalysisJobRecord[]>([]);
  const [reports, setReports] = useState<AnalysisReportRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [downloadingId, setDownloadingId] = useState<number | string | null>(null);
  const [state, setState] = useState<HistoryState>('ready');
  const [message, setMessage] = useState<string | null>(null);

  const loadHistory = useCallback(async () => {
    setLoading(true);
    setMessage(null);
    try {
      const [jobsResponse, reportsResponse] = await Promise.all([
        fetch('/api/analysis/jobs', { credentials: 'same-origin' }),
        fetch('/api/analysis/reports', { credentials: 'same-origin' }),
      ]);
      if (jobsResponse.status === 401 || jobsResponse.status === 403 || reportsResponse.status === 401 || reportsResponse.status === 403) {
        setJobs([]);
        setReports([]);
        setState('authentication-required');
        return;
      }
      if (jobsResponse.status === 404 || reportsResponse.status === 404) {
        setJobs([]);
        setReports([]);
        setState('service-unavailable');
        return;
      }
      const [jobsPayload, reportsPayload] = await Promise.all([
        jobsResponse.json().catch(() => null) as Promise<AnalysisJobsResponse | unknown>,
        reportsResponse.json().catch(() => null) as Promise<AnalysisReportsResponse | unknown>,
      ]);
      if (!jobsResponse.ok || !reportsResponse.ok) {
        const errorPayload = asRecord(!jobsResponse.ok ? jobsPayload : reportsPayload);
        throw new Error(typeof errorPayload?.message === 'string' ? errorPayload.message : 'Analysis history could not be loaded.');
      }
      setJobs(recordsFromPayload(jobsPayload, 'jobs', normalizeJob));
      setReports(recordsFromPayload(reportsPayload, 'reports', normalizeReport));
      setState('ready');
    } catch (caught) {
      setJobs([]);
      setReports([]);
      setState('error');
      setMessage(caught instanceof Error ? caught.message : 'Analysis history could not be loaded.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (isOpen) void loadHistory();
  }, [isOpen, loadHistory]);

  const downloadReport = async (report: AnalysisReportRecord) => {
    setDownloadingId(report.id);
    setMessage(null);
    try {
      const response = await fetch(`/api/analysis/reports/${encodeURIComponent(String(report.id))}/download`, {
        credentials: 'same-origin',
      });
      if (response.status === 401 || response.status === 403) {
        setState('authentication-required');
        return;
      }
      if (response.status === 404) throw new Error('The selected report is unavailable for download.');
      if (!response.ok) {
        const payload = await response.json().catch(() => null) as { message?: string } | null;
        throw new Error(payload?.message || 'The selected report could not be downloaded.');
      }
      const blob = await response.blob();
      const href = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = href;
      anchor.download = safeDownloadFilename(response.headers.get('Content-Disposition'), report.filename);
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      window.setTimeout(() => URL.revokeObjectURL(href), 0);
    } catch (caught) {
      setMessage(caught instanceof Error ? caught.message : 'The selected report could not be downloaded.');
    } finally {
      setDownloadingId(null);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[55] flex items-center justify-center bg-black/85 p-3 backdrop-blur-md sm:p-6" role="dialog" aria-modal="true" aria-label="Analysis job and report history">
      <section className="flex max-h-[94vh] w-full max-w-7xl flex-col overflow-hidden rounded-xl border border-[#2b3533] bg-[#0d0f0e] text-[#ddd] shadow-2xl">
        <header className="flex flex-wrap items-center justify-between gap-3 border-b border-[#26302e] bg-[#121615] px-5 py-4 sm:px-6">
          <div className="flex min-w-0 items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-[#00FF9C]/30 bg-[#00FF9C]/10 text-[#00FF9C]"><History className="h-5 w-5" /></div>
            <div><h2 className="text-base font-black tracking-wide text-white sm:text-lg">ANALYSIS JOB &amp; REPORT HISTORY</h2><p className="mt-0.5 text-xs text-neutral-400">Authenticated, server-backed queue and generated-report records. Refresh is manual.</p></div>
          </div>
          <div className="flex items-center gap-2"><button type="button" onClick={() => void loadHistory()} disabled={loading} className="flex items-center gap-1.5 rounded border border-neutral-700 bg-neutral-900 px-3 py-2 text-xs font-bold text-neutral-200 hover:border-[#00E5FF] hover:text-[#00E5FF] disabled:opacity-50"><RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />Refresh</button><button type="button" onClick={onClose} className="rounded-lg p-2 text-neutral-400 hover:bg-neutral-800 hover:text-white" aria-label="Close analysis history"><X className="h-5 w-5" /></button></div>
        </header>

        <div className="flex-1 overflow-y-auto p-5 sm:p-6">
          {message && <div role="alert" className="mb-4 flex items-start gap-2 rounded-lg border border-red-800 bg-red-950/35 p-3 text-xs text-red-300"><AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />{message}</div>}
          {loading && jobs.length === 0 && reports.length === 0 ? <div className="flex min-h-64 items-center justify-center gap-2 text-sm text-neutral-400"><Loader2 className="h-5 w-5 animate-spin text-[#00E5FF]" />Loading authenticated analysis history…</div> : state === 'authentication-required' ? <StatePanel icon={ShieldAlert} title="Authentication required" detail="Sign in through the application's configured authentication flow, then manually refresh. No user identity or historical records are fabricated in this state." /> : state === 'service-unavailable' ? <StatePanel icon={AlertTriangle} title="Analysis history service unavailable" detail="The jobs or reports endpoint returned 404. No analysis history is available from this environment yet." /> : state === 'error' && jobs.length === 0 && reports.length === 0 ? <StatePanel icon={AlertTriangle} title="Analysis history unavailable" detail="The server did not return a usable jobs and reports index. Use manual refresh after the service recovers." /> : <div className="grid gap-5 xl:grid-cols-2">
            <HistorySection title="Queue history" detail={`${jobs.length} server job${jobs.length === 1 ? '' : 's'}`} icon={Clock3}>{jobs.length === 0 ? <EmptyState text="No server-backed analysis jobs were returned." /> : <div className="space-y-3">{jobs.map((job) => <article key={String(job.job_id)} className="rounded-lg border border-[#29302f] bg-[#131716] p-4"><div className="flex flex-wrap items-start justify-between gap-3"><div><div className="font-mono text-xs font-bold text-white">Job {String(job.job_id)}</div><div className="mt-1 font-mono text-[10px] text-neutral-500">{datasetReferences(job)}</div></div><span className={`rounded border px-2 py-1 font-mono text-[10px] font-bold uppercase ${statusClass(job.status)}`}>{job.status}</span></div><dl className="mt-3 grid gap-2 border-t border-[#252d2b] pt-3 text-[10px] sm:grid-cols-2"><div><dt className="uppercase text-neutral-600">Queued / created</dt><dd className="mt-0.5 font-mono text-neutral-300">{formatTimestamp(job.queued_at ?? job.created_at)}</dd></div><div><dt className="uppercase text-neutral-600">Completed / updated</dt><dd className="mt-0.5 font-mono text-neutral-300">{formatTimestamp(job.completed_at ?? job.updated_at)}</dd></div></dl></article>)}</div>}</HistorySection>
            <HistorySection title="Generated reports" detail={`${reports.length} server report${reports.length === 1 ? '' : 's'}`} icon={FileText}>{reports.length === 0 ? <EmptyState text="No generated reports were returned." /> : <div className="space-y-3">{reports.map((report) => <article key={String(report.id)} className="rounded-lg border border-[#29302f] bg-[#131716] p-4"><div className="flex items-start justify-between gap-3"><div className="min-w-0"><div className="truncate font-mono text-xs font-bold text-white" title={report.filename}>{report.filename}</div><div className="mt-1 font-mono text-[10px] text-neutral-500">Report {String(report.id)}{report.job_id != null ? ` · Job ${String(report.job_id)}` : ''}</div></div><button type="button" onClick={() => void downloadReport(report)} disabled={downloadingId !== null} className="flex shrink-0 items-center gap-1.5 rounded border border-[#00FF9C]/45 bg-[#00FF9C]/10 px-2.5 py-1.5 text-[11px] font-bold text-[#00FF9C] hover:bg-[#00FF9C]/20 disabled:opacity-50">{downloadingId === report.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CloudDownload className="h-3.5 w-3.5" />}Download</button></div><div className="mt-3 border-t border-[#252d2b] pt-3 font-mono text-[10px] text-neutral-400"><div>{datasetReferences(report)}</div><div className="mt-1">{formatTimestamp(report.completed_at ?? report.created_at)}</div></div></article>)}</div>}</HistorySection>
          </div>}
        </div>
        <footer className="flex items-center gap-2 border-t border-[#26302e] bg-[#121615] px-5 py-3 text-[10px] text-neutral-500 sm:px-6"><CheckCircle2 className="h-3.5 w-3.5 text-[#00FF9C]" />Read-only server history · report payloads are downloaded as files · raw storage URLs are never displayed</footer>
      </section>
    </div>
  );
}

function HistorySection({ title, detail, icon: Icon, children }: { title: string; detail: string; icon: typeof Clock3; children: React.ReactNode }) {
  return <section className="overflow-hidden rounded-xl border border-[#252c2a] bg-[#101312]"><header className="flex items-center justify-between border-b border-[#252c2a] px-4 py-3"><h3 className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-white"><Icon className="h-4 w-4 text-[#00E5FF]" />{title}</h3><span className="font-mono text-[10px] text-neutral-500">{detail}</span></header><div className="p-4">{children}</div></section>;
}

function EmptyState({ text }: { text: string }) {
  return <div className="flex min-h-40 items-center justify-center rounded-lg border border-dashed border-[#303735] p-6 text-center text-xs text-neutral-500">{text}</div>;
}

function StatePanel({ icon: Icon, title, detail }: { icon: typeof AlertTriangle; title: string; detail: string }) {
  return <div className="flex min-h-64 flex-col items-center justify-center rounded-xl border border-dashed border-[#353c3a] bg-[#111413] p-8 text-center"><Icon className="mb-3 h-8 w-8 text-[#FFAE00]" /><h3 className="text-sm font-bold text-white">{title}</h3><p className="mt-2 max-w-xl text-xs leading-relaxed text-neutral-400">{detail}</p></div>;
}
