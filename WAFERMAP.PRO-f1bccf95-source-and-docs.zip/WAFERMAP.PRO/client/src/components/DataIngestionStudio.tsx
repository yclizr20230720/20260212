import { useRef, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  ClipboardCheck,
  Cpu,
  Database,
  Download,
  FileCheck2,
  FileSpreadsheet,
  FlaskConical,
  Info,
  Loader2,
  Microscope,
  Save,
  Search,
  X,
} from 'lucide-react';
import {
  CpDieRecord,
  IngestedDataType,
  IngestedWaferData,
  IngestionOverlayResponse,
  IngestionPackageDiagnostic,
  IngestionPackagePartition,
  IngestionPackagePersistenceResponse,
  IngestionPackageValidationResponse,
  KlaDefectItem,
  WatMeasurementItem,
} from '../types';
import { INGESTION_PRODUCT_PRESETS, IngestionProductPreset } from '../data/productPresets';
import {
  createCsvTemplate,
  createPackageReadme,
  getPrimaryRoleIds,
  getRealDataFileRoles,
  RealDataFileRole,
  RealDataFileRoleId,
} from '../data/realDataPackageTemplates';
import {
  abandonStagedPackage,
  ActivePackageUploadSession,
  createPackageUploadSession,
  persistStagedPackage,
  StagedPackageFile,
  uploadPackageFiles,
  validateStagedPackage,
} from '../utils/stagedPackageUpload';

const MAX_PACKAGE_FILE_BYTES = 128 * 1024 * 1024;
const HEADER_READ_BYTES = 64 * 1024;
const MAX_RENDERED_DIAGNOSTICS = 12;

const CATEGORY_META: Record<IngestedDataType, { title: string; detail: string; accent: string; icon: typeof Cpu }> = {
  CP: { title: 'CP Wafer Sort', detail: 'Die result, wafer reconciliation, bin semantics, and test-limit provenance.', accent: '#00FF9C', icon: Cpu },
  WAT: { title: 'WAT Metrology', detail: 'Site measurements, wafer median reconciliation, and parameter-limit provenance.', accent: '#00E5FF', icon: Microscope },
  KLA: { title: 'KLA Defect Inspection', detail: 'Defect detail, wafer defect reconciliation, and class-definition provenance.', accent: '#FF5A52', icon: Search },
};

type ClientSchemaState = 'valid' | 'invalid';

interface SelectedPackageFile {
  file: File;
  schemaState: ClientSchemaState;
  schemaMessage: string;
}

interface DataIngestionStudioProps {
  isOpen: boolean;
  onClose: () => void;
  onApply: (data: IngestedWaferData, preset: IngestionProductPreset) => void | Promise<void>;
}

function downloadText(filename: string, content: string): void {
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 0);
}

function normalizeHeader(value: string): string {
  return value.trim().toUpperCase().replace(/[^A-Z0-9]+/g, '_').replace(/^_+|_+$/g, '');
}

function extractCsvHeaderLine(content: string): string | null {
  const csv = content.replace(/^\uFEFF/, '');
  let quoted = false;
  for (let index = 0; index < csv.length; index += 1) {
    if (csv[index] === '"') {
      if (quoted && csv[index + 1] === '"') {
        index += 1;
      } else {
        quoted = !quoted;
      }
    } else if (csv[index] === '\n' && !quoted) {
      return csv.slice(0, index).replace(/\r$/, '');
    }
  }
  return null;
}

function parseCsvHeader(line: string): string[] {
  const headers: string[] = [];
  let value = '';
  let quoted = false;
  for (let index = 0; index < line.length; index += 1) {
    const character = line[index];
    if (character === '"') {
      if (quoted && line[index + 1] === '"') {
        value += '"';
        index += 1;
      } else {
        quoted = !quoted;
      }
    } else if (character === ',' && !quoted) {
      headers.push(normalizeHeader(value));
      value = '';
    } else {
      value += character;
    }
  }
  headers.push(normalizeHeader(value));
  return headers.filter(Boolean);
}

async function validateCsvHeaders(role: RealDataFileRole, file: File): Promise<Pick<SelectedPackageFile, 'schemaState' | 'schemaMessage'>> {
  const headerSlice = await file.slice(0, HEADER_READ_BYTES).text();
  const headerLine = extractCsvHeaderLine(headerSlice);
  if (headerLine === null) {
    return {
      schemaState: 'invalid',
      schemaMessage: `No complete CSV header row was found in the first ${HEADER_READ_BYTES / 1024} KiB.`,
    };
  }

  const headers = parseCsvHeader(headerLine);
  if (headers.length === 0) {
    return { schemaState: 'invalid', schemaMessage: 'No CSV header row was found.' };
  }

  const hasDynamicColumns = Boolean(role.dynamicColumnHint);
  const requiredHeaders = (role.validationHeaders ?? role.headers).map(normalizeHeader);
  const dynamicPlaceholder = hasDynamicColumns ? normalizeHeader(role.headers[role.headers.length - 1]) : null;
  const missingHeaders = requiredHeaders.filter((header) => !headers.includes(header));
  const namedParameterColumns = hasDynamicColumns
    ? headers.filter((header) => !requiredHeaders.includes(header) && header !== dynamicPlaceholder)
    : [];
  const hasRequiredDynamicColumn = !hasDynamicColumns || namedParameterColumns.length > 0;

  if (missingHeaders.length > 0 || !hasRequiredDynamicColumn) {
    const missing = missingHeaders.length > 0 ? `Missing: ${missingHeaders.slice(0, 4).join(', ')}${missingHeaders.length > 4 ? '…' : ''}.` : '';
    const dynamic = !hasRequiredDynamicColumn ? ' Add at least one named parameter column.' : '';
    return { schemaState: 'invalid', schemaMessage: `${missing}${dynamic}`.trim() };
  }

  return {
    schemaState: 'valid',
    schemaMessage: hasDynamicColumns
      ? `Required metadata columns and ${namedParameterColumns.length} named parameter column${namedParameterColumns.length === 1 ? '' : 's'} detected.`
      : `${requiredHeaders.length} contract headers detected.`,
  };
}

function numberOrZero(value: unknown): number {
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
}

function packageResultFrom(value: unknown): IngestionPackageValidationResponse | null {
  return value && typeof value === 'object' ? value as IngestionPackageValidationResponse : null;
}

function partitionKey(partition: Pick<IngestionPackagePartition, 'lot_id' | 'wafer_id'>): string {
  return JSON.stringify([partition.lot_id, partition.wafer_id]);
}

function unpackRecords(payload: IngestionOverlayResponse): Record<string, unknown>[] {
  if (Array.isArray(payload.records)) return payload.records as Record<string, unknown>[];
  if (!Array.isArray(payload.columns) || !Array.isArray(payload.rows)) return [];
  return payload.rows.map((row) => Object.fromEntries(payload.columns!.map((column, index) => [column, row[index]])));
}

function responseMessage(payload: unknown, fallback: string): string {
  if (!payload || typeof payload !== 'object') return fallback;
  const body = payload as { message?: unknown; error?: unknown };
  if (typeof body.message === 'string') return body.message;
  if (typeof body.error === 'string') return body.error;
  return fallback;
}

export function DataIngestionStudio({ isOpen, onClose, onApply }: DataIngestionStudioProps) {
  const [category, setCategory] = useState<IngestedDataType>('CP');
  const [selectedFiles, setSelectedFiles] = useState<Partial<Record<RealDataFileRoleId, SelectedPackageFile>>>({});
  const [validating, setValidating] = useState(false);
  const [persisting, setPersisting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [packageStatus, setPackageStatus] = useState<string | null>(null);
  const [persistenceStatus, setPersistenceStatus] = useState<string | null>(null);
  const [persistenceDiagnostics, setPersistenceDiagnostics] = useState<IngestionPackageDiagnostic[]>([]);
  const [validationResult, setValidationResult] = useState<IngestionPackageValidationResponse | null>(null);
  const [selectedPartitionKey, setSelectedPartitionKey] = useState<string | null>(null);
  const [displayPresetId, setDisplayPresetId] = useState('');
  const [stagedSession, setStagedSession] = useState<ActivePackageUploadSession | null>(null);
  const [uploadProgress, setUploadProgress] = useState<{ completedBytes: number; totalBytes: number; filename: string } | null>(null);
  const uploadAbortRef = useRef<AbortController | null>(null);

  if (!isOpen) return null;

  const meta = CATEGORY_META[category];
  const CategoryIcon = meta.icon;
  const roles = getRealDataFileRoles(category);
  const primaryRoleIds = getPrimaryRoleIds(category);
  const selectedPrimaryRoles = primaryRoleIds.filter((roleId) => selectedFiles[roleId]);
  const hasPrimaryConflict = category === 'WAT' && selectedPrimaryRoles.length > 1;

  const clearValidationResult = () => {
    uploadAbortRef.current?.abort();
    uploadAbortRef.current = null;
    if (stagedSession) void abandonStagedPackage(stagedSession);
    setStagedSession(null);
    setUploadProgress(null);
    setError(null);
    setPackageStatus(null);
    setPersistenceStatus(null);
    setPersistenceDiagnostics([]);
    setValidationResult(null);
    setSelectedPartitionKey(null);
  };

  const resetForCategory = (next: IngestedDataType) => {
    setCategory(next);
    clearValidationResult();
  };

  const selectRoleFile = async (role: RealDataFileRole, file: File) => {
    if (!/\.csv$/i.test(file.name)) {
      setError('Attach a CSV source file. Real Data Package validation accepts CSV only.');
      return;
    }
    if (file.size === 0 || file.size > MAX_PACKAGE_FILE_BYTES) {
      setError('Each CSV source file must be from 1 byte through 128 MiB.');
      return;
    }

    clearValidationResult();
    try {
      const schema = await validateCsvHeaders(role, file);
      setSelectedFiles((current) => ({ ...current, [role.id]: { file, ...schema } }));
    } catch {
      setSelectedFiles((current) => ({
        ...current,
        [role.id]: { file, schemaState: 'invalid', schemaMessage: 'The CSV header could not be read in this browser.' },
      }));
    }
  };

  const removeRoleFile = (roleId: RealDataFileRoleId) => {
    setSelectedFiles((current) => {
      const next = { ...current };
      delete next[roleId];
      return next;
    });
    clearValidationResult();
  };

  const validatePackage = async () => {
    clearValidationResult();
    const requiredRoleIds = roles.filter((role) => role.requirement === 'required').map((role) => role.id);
    const missingRequired = requiredRoleIds.filter((roleId) => !selectedFiles[roleId]);
    if (missingRequired.length > 0) {
      setPackageStatus(`Package incomplete: attach ${roles.filter((role) => missingRequired.includes(role.id)).map((role) => role.label).join(', ')}.`);
      return;
    }
    if (selectedPrimaryRoles.length === 0) {
      setPackageStatus(category === 'WAT'
        ? 'Package incomplete: attach one WAT site-level primary (long or wide).'
        : 'Package incomplete: attach the required primary file.');
      return;
    }
    if (hasPrimaryConflict) {
      setPackageStatus('WAT package conflict: choose either site-level long primary or site-level wide primary, not both.');
      return;
    }
    if (category === 'WAT' && selectedFiles['wat-wide-primary'] && !selectedFiles['wat-spec-definitions']) {
      setPackageStatus('Package incomplete: WAT wide primary requires the Parameter spec definition CSV.');
      return;
    }
    const invalidSelections = roles.filter((role) => selectedFiles[role.id]?.schemaState === 'invalid');
    if (invalidSelections.length > 0) {
      setPackageStatus(`Header review needed: ${invalidSelections.map((role) => role.label).join(', ')} does not match its CSV contract.`);
      return;
    }

    const stagedFiles: StagedPackageFile[] = roles.flatMap((role) => {
      const selection = selectedFiles[role.id];
      return selection ? [{ role: role.multipartField, file: selection.file }] : [];
    });
    setValidating(true);
    setPackageStatus('Local role coverage and CSV-header preflight passed. Creating a bounded upload session…');
    let activeSession: ActivePackageUploadSession | null = null;
    try {
      const session = await createPackageUploadSession(category, stagedFiles);
      activeSession = session;
      setStagedSession(session);
      const controller = new AbortController();
      uploadAbortRef.current = controller;
      setPackageStatus(`Uploading ${stagedFiles.length} CSV file${stagedFiles.length === 1 ? '' : 's'} in ${Math.round(session.chunkBytes / (1024 * 1024))} MiB gateway-safe chunks…`);
      await uploadPackageFiles(session, stagedFiles, (completedBytes, totalBytes, filename) => {
        setUploadProgress({ completedBytes, totalBytes, filename });
        setPackageStatus(`Uploading ${filename}: ${Math.round((completedBytes / Math.max(totalBytes, 1)) * 100)}% complete. Source data remains temporary until you explicitly persist one selected wafer.`);
      }, controller.signal);
      setPackageStatus('All source chunks received. Validating canonical identities and package roles with the server…');
      const body = await validateStagedPackage(session);
      const result = packageResultFrom(body);
      if (result?.partitions || result?.diagnostics || typeof result?.valid === 'boolean') {
        setValidationResult(result);
        setSelectedPartitionKey(null);
        setPackageStatus(null);
        return;
      }
      throw new Error('The staged package validation service returned an unexpected response.');
    } catch (caught) {
      if (activeSession) {
        void abandonStagedPackage(activeSession);
        setStagedSession(null);
      }
      setPackageStatus(null);
      setError(caught instanceof DOMException && caught.name === 'AbortError'
        ? 'The staged upload was cancelled. No source data was persisted.'
        : caught instanceof Error
          ? caught.message
          : 'The package validation operation failed.');
    } finally {
      uploadAbortRef.current = null;
      setValidating(false);
    }
  };

  const partitions = validationResult?.partitions ?? [];
  const partitionCount = validationResult ? numberOrZero(validationResult.partition_count ?? partitions.length) : 0;
  const primaryRows = partitions.reduce((total, partition) => total + numberOrZero(partition.source_rows), 0);
  const normalizedRows = partitions.reduce((total, partition) => total + numberOrZero(partition.valid_rows), 0);
  const diagnostics = validationResult?.diagnostics;
  const diagnosticItems = diagnostics?.items?.slice(0, MAX_RENDERED_DIAGNOSTICS) ?? [];
  const selectedPartition = partitions.find((partition) => partitionKey(partition) === selectedPartitionKey) ?? null;
  const selectedDisplayPreset = INGESTION_PRODUCT_PRESETS.find((preset) => preset.id === displayPresetId) ?? null;
  const canPersist = Boolean(validationResult?.valid && selectedPartition && selectedDisplayPreset && stagedSession && !persisting && !validating);

  const persistSelectedPartition = async () => {
    if (!validationResult?.valid || !selectedPartition || !selectedDisplayPreset || !stagedSession) {
      setError('Validate the selected package, choose one LOT_ID and WAFER_ID partition, and choose display geometry before persistence.');
      return;
    }

    setPersisting(true);
    setError(null);
    setPersistenceDiagnostics([]);
    setPersistenceStatus(`Revalidating and persisting ${selectedPartition.lot_id} / ${selectedPartition.wafer_id}…`);
    try {
      const persistenceBody = await persistStagedPackage(stagedSession, selectedPartition.lot_id, selectedPartition.wafer_id);
      if (!persistenceBody || typeof persistenceBody !== 'object') {
        throw new Error('The staged persistence service returned an unexpected completion response.');
      }
      const stagedResponse = persistenceBody as Partial<IngestionPackagePersistenceResponse>;
      if (stagedResponse.status !== 'COMPLETED' || stagedResponse.persistent !== true) {
        const responseDiagnostics = persistenceBody && typeof persistenceBody === 'object' && Array.isArray((persistenceBody as { diagnostics?: unknown }).diagnostics)
          ? (persistenceBody as { diagnostics: IngestionPackageDiagnostic[] }).diagnostics.slice(0, MAX_RENDERED_DIAGNOSTICS)
          : [];
        setPersistenceDiagnostics(responseDiagnostics);
        throw new Error(responseMessage(persistenceBody, 'The selected wafer could not be persisted from the staged upload.'));
      }

      const persisted = persistenceBody as Partial<IngestionPackagePersistenceResponse> | null;
      const datasetId = Number(persisted?.dataset?.dataset_id);
      const importRunId = Number(persisted?.import_run_id);
      if (persisted?.status !== 'COMPLETED' || persisted.persistent !== true || !Number.isInteger(datasetId) || datasetId < 1 || !Number.isInteger(importRunId) || importRunId < 1) {
        throw new Error('The staged persistence service returned an unexpected completion response.');
      }

      setPersistenceStatus(`Dataset #${datasetId} persisted under import run #${importRunId}. Loading its retained overlay…`);
      const overlayResponse = await fetch(`/api/ingestion/datasets/${datasetId}/overlay`, { credentials: 'same-origin' });
      const overlayBody: unknown = await overlayResponse.json().catch(() => null);
      if (!overlayResponse.ok) throw new Error(responseMessage(overlayBody, 'The persisted dataset overlay could not be loaded.'));
      const overlay = overlayBody as IngestionOverlayResponse;
      const sourceType = overlay.dataset?.source_type;
      if ((sourceType !== 'CP' && sourceType !== 'WAT' && sourceType !== 'KLA') || !overlay.dataset?.summary) {
        throw new Error('The persisted dataset overlay returned an unsupported data shape.');
      }
      const records = unpackRecords(overlay);
      const ingested: IngestedWaferData = {
        dataset: {
          dataset_id: Number(overlay.dataset.id),
          source_type: sourceType,
          summary: overlay.dataset.summary,
        },
        ...(sourceType === 'CP' ? { cpRecords: records as unknown as CpDieRecord[] } : {}),
        ...(sourceType === 'WAT' ? { watRecords: records as unknown as WatMeasurementItem[] } : {}),
        ...(sourceType === 'KLA' ? { klaRecords: records as unknown as KlaDefectItem[] } : {}),
      };

      setPersistenceStatus(`Dataset #${datasetId} loaded. Applying the selected display geometry…`);
      await onApply(ingested, selectedDisplayPreset);
      setStagedSession(null);
      setUploadProgress(null);
      onClose();
    } catch (caught) {
      setPersistenceStatus(null);
      setError(caught instanceof Error ? caught.message : 'The selected wafer persistence operation failed.');
    } finally {
      setPersisting(false);
    }
  };

  const abandonCurrentUpload = () => {
    uploadAbortRef.current?.abort();
    uploadAbortRef.current = null;
    if (stagedSession) void abandonStagedPackage(stagedSession);
    setStagedSession(null);
    setUploadProgress(null);
  };

  const closeStudio = () => {
    abandonCurrentUpload();
    onClose();
  };

  const uploadPercent = uploadProgress
    ? Math.min(100, Math.round((uploadProgress.completedBytes / Math.max(uploadProgress.totalBytes, 1)) * 100))
    : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-3 backdrop-blur-md sm:p-6" role="dialog" aria-modal="true" aria-label="Fab metrology and defect ingestion studio">
      <section className="flex max-h-[94vh] w-full max-w-7xl flex-col overflow-hidden rounded-xl border border-[#252525] bg-[#0e0e0e] text-[#ddd] shadow-2xl">
        <header className="flex items-center justify-between border-b border-[#242424] bg-[#141414] px-5 py-4 sm:px-6">
          <div className="flex min-w-0 items-center gap-3">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-[#00FF9C]/30 bg-[#00FF9C]/10 text-[#00FF9C]"><FileSpreadsheet className="h-5 w-5" /></div>
            <div className="min-w-0">
              <h2 className="flex flex-wrap items-center gap-2 text-base font-bold tracking-wide text-white sm:text-lg">REAL DATA PACKAGE STUDIO <span className="rounded border border-[#00FF9C]/35 bg-[#00FF9C]/15 px-2 py-0.5 font-mono text-[10px] uppercase text-[#00FF9C]">CP · WAT · KLA</span></h2>
              <p className="mt-0.5 text-xs text-neutral-400">Attach source CSV files by role, validate canonical partitions, then explicitly persist one selected wafer.</p>
            </div>
          </div>
          <button type="button" onClick={closeStudio} disabled={persisting} className="rounded-lg p-2 text-neutral-400 transition-colors hover:bg-neutral-800 hover:text-white disabled:cursor-wait disabled:opacity-40" aria-label="Close data ingestion studio"><X className="h-5 w-5" /></button>
        </header>

        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#242424] bg-[#111] px-5 py-3 sm:px-6">
          <div className="flex min-w-0 items-center gap-2 overflow-x-auto">
            <span className="shrink-0 font-mono text-[10px] uppercase text-neutral-500">Source family:</span>
            <div className="flex rounded-lg border border-[#292929] bg-black/60 p-1">
              {(Object.keys(CATEGORY_META) as IngestedDataType[]).map((type) => {
                const entry = CATEGORY_META[type];
                const Icon = entry.icon;
                const active = category === type;
                return <button key={type} type="button" onClick={() => resetForCategory(type)} className={`flex shrink-0 items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs transition-colors ${active ? 'font-bold text-black' : 'text-neutral-300 hover:bg-neutral-800 hover:text-white'}`} style={active ? { backgroundColor: entry.accent } : undefined}><Icon className="h-3.5 w-3.5" />{entry.title}</button>;
              })}
            </div>
          </div>
          <button type="button" onClick={() => downloadText(`wafermap-pro_${category.toLowerCase()}_real_data_package_README.txt`, createPackageReadme(category))} className="flex items-center gap-1.5 rounded border border-neutral-700 bg-neutral-900 px-3 py-1.5 text-xs text-neutral-300 transition-colors hover:bg-neutral-800 hover:text-white"><Download className="h-3.5 w-3.5" />Download {category} package README</button>
        </div>

        <div className="flex-1 space-y-5 overflow-y-auto p-5 sm:p-6">
          <section className="rounded-xl border border-[#00E5FF]/25 bg-[#00E5FF]/[0.035] p-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="flex items-start gap-2.5"><Info className="mt-0.5 h-4 w-4 shrink-0 text-[#00E5FF]" /><div><h3 className="text-xs font-bold uppercase tracking-wider text-white">Source identity and persistence boundary</h3><p className="mt-1 max-w-3xl text-xs leading-relaxed text-neutral-300"><strong className="text-white">LOT_ID, WAFER_ID, and source PRODUCT_ID remain authoritative provenance.</strong> Validation discovers canonical partitions. Persistence revalidates the complete role package and retains only the explicitly selected wafer; companion files remain role-separated.</p></div></div>
              <span className="rounded border border-[#00E5FF]/30 bg-[#00E5FF]/10 px-2 py-1 font-mono text-[10px] uppercase text-[#00E5FF]">CSV only · 128 MiB per file</span>
            </div>
          </section>

          <section className="rounded-xl border border-[#242424] bg-[#121212] p-4">
            <div className="mb-3 flex items-center justify-between gap-3"><div className="flex items-center gap-2"><FlaskConical className="h-4 w-4 text-[#00FF9C]" /><h3 className="text-xs font-bold uppercase tracking-wider text-white">{meta.title} package roles</h3></div><span className="hidden text-[11px] text-neutral-500 sm:block">{meta.detail}</span></div>
            <ol className="grid gap-2 text-[11px] text-neutral-400 sm:grid-cols-3"><li className="flex gap-2 rounded border border-[#292929] bg-[#161616] p-2.5"><span className="font-mono text-[#00FF9C]">01</span><span>Download the matching empty CSV header template.</span></li><li className="flex gap-2 rounded border border-[#292929] bg-[#161616] p-2.5"><span className="font-mono text-[#00FF9C]">02</span><span>Fill it with approved production source records and attach by role.</span></li><li className="flex gap-2 rounded border border-[#292929] bg-[#161616] p-2.5"><span className="font-mono text-[#00FF9C]">03</span><span>Validate, explicitly select one identity partition, then persist that wafer.</span></li></ol>
          </section>

          <section className="rounded-xl border border-[#242424] bg-[#121212] p-4">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-3"><div className="flex items-center gap-2"><ClipboardCheck className="h-4 w-4" style={{ color: meta.accent }} /><h3 className="text-xs font-bold uppercase tracking-wider text-white">File-role checklist</h3></div><span className="font-mono text-[10px] uppercase text-neutral-500">{category === 'WAT' ? 'Select one primary layout; wide requires spec definition' : 'Primary file required; reconciliation roles optional'}</span></div>
            <div className="grid gap-3 lg:grid-cols-2">
              {roles.map((role) => {
                const selection = selectedFiles[role.id];
                const requiredLabel = role.requirement === 'required' ? 'Required' : role.requirement === 'choose-one-primary' ? 'Choose one' : 'Optional';
                const statusClass = selection?.schemaState === 'invalid' ? 'border-red-800/70 bg-red-950/20' : selection ? 'border-[#00FF9C]/35 bg-[#00FF9C]/[0.035]' : 'border-[#303030] bg-[#161616]';
                return <article key={role.id} className={`rounded-lg border p-3.5 ${statusClass}`}>
                  <div className="flex items-start justify-between gap-3"><div><div className="flex flex-wrap items-center gap-2"><h4 className="text-xs font-bold text-white">{role.label}</h4><span className={`rounded border px-1.5 py-0.5 font-mono text-[9px] uppercase ${role.requirement === 'optional' ? 'border-neutral-700 text-neutral-400' : 'border-[#00FF9C]/35 bg-[#00FF9C]/10 text-[#00FF9C]'}`}>{requiredLabel}</span><span className="rounded border border-neutral-700 px-1.5 py-0.5 font-mono text-[9px] uppercase text-neutral-400">{role.multipartField}</span></div><p className="mt-1.5 text-[11px] leading-relaxed text-neutral-400">{role.description}</p>{role.dynamicColumnHint && <p className="mt-1.5 rounded border border-amber-500/25 bg-amber-500/[0.06] p-2 text-[10px] leading-relaxed text-amber-200">{role.dynamicColumnHint}</p>}</div></div>
                  <div className="mt-3 flex flex-wrap items-center gap-2"><button type="button" onClick={() => downloadText(role.filename, createCsvTemplate(role))} className="flex items-center gap-1.5 rounded border border-neutral-700 bg-[#101010] px-2.5 py-1.5 text-[11px] text-neutral-300 transition-colors hover:border-neutral-500 hover:text-white"><Download className="h-3.5 w-3.5" />Template CSV</button><input id={`package-file-${role.id}`} type="file" accept=".csv,text/csv" className="hidden" onChange={(event) => { const file = event.target.files?.[0]; if (file) void selectRoleFile(role, file); event.currentTarget.value = ''; }} /><label htmlFor={`package-file-${role.id}`} className="flex cursor-pointer items-center gap-1.5 rounded border border-[#00E5FF]/40 bg-[#00E5FF]/[0.08] px-2.5 py-1.5 text-[11px] font-semibold text-[#00E5FF] transition-colors hover:bg-[#00E5FF]/15"><FileSpreadsheet className="h-3.5 w-3.5" />{selection ? 'Replace CSV' : 'Attach CSV'}</label></div>
                  {selection ? <div className="mt-3 flex items-start justify-between gap-3 rounded border border-[#2d2d2d] bg-black/25 p-2.5"><div className="flex min-w-0 gap-2"><FileCheck2 className={`mt-0.5 h-4 w-4 shrink-0 ${selection.schemaState === 'invalid' ? 'text-red-400' : 'text-[#00FF9C]'}`} /><div className="min-w-0"><div className="truncate font-mono text-[10px] font-semibold text-white">{selection.file.name}</div><div className="mt-0.5 text-[10px] leading-relaxed text-neutral-400">{selection.schemaMessage}</div></div></div><button type="button" onClick={() => removeRoleFile(role.id)} className="shrink-0 rounded p-1 text-neutral-500 hover:bg-neutral-800 hover:text-white" aria-label={`Remove ${role.label} file`}><X className="h-3.5 w-3.5" /></button></div> : <div className="mt-3 font-mono text-[10px] uppercase text-neutral-600">No CSV selected</div>}
                </article>;
              })}
            </div>
          </section>

          {error && <section role="alert" className="flex items-start gap-2 rounded-xl border border-red-800 bg-red-950/40 p-4 text-xs text-red-300"><AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />{error}</section>}

          {uploadProgress && <section className="rounded-xl border border-[#00E5FF]/30 bg-[#00E5FF]/[0.045] p-4" aria-live="polite"><div className="flex items-start justify-between gap-3"><div><h3 className="text-xs font-bold uppercase tracking-wider text-white">Gateway-safe staged upload</h3><p className="mt-1 text-xs leading-relaxed text-neutral-300">{uploadProgress.filename} · {uploadPercent}% · {(uploadProgress.completedBytes / (1024 * 1024)).toFixed(1)} / {(uploadProgress.totalBytes / (1024 * 1024)).toFixed(1)} MiB transferred in bounded chunks.</p></div><button type="button" onClick={abandonCurrentUpload} disabled={!validating || persisting} className="shrink-0 rounded border border-neutral-700 bg-neutral-900 px-2.5 py-1.5 text-[11px] font-semibold text-neutral-300 hover:bg-neutral-800 disabled:cursor-not-allowed disabled:opacity-40">Cancel upload</button></div><div className="mt-3 h-2 overflow-hidden rounded bg-black/40"><div className="h-full rounded bg-[#00E5FF] transition-[width] duration-150" style={{ width: `${uploadPercent}%` }} /></div><p className="mt-2 font-mono text-[10px] text-neutral-500">Temporary source chunks expire automatically and are removed after successful persistence or cancellation.</p></section>}

          {packageStatus && <section className="rounded-xl border border-[#00E5FF]/30 bg-[#00E5FF]/[0.045] p-4" aria-live="polite"><div className="flex items-start gap-2"><ClipboardCheck className="mt-0.5 h-4 w-4 shrink-0 text-[#00E5FF]" /><div><h3 className="text-xs font-bold uppercase tracking-wider text-white">Package validation result</h3><p className="mt-1 text-xs leading-relaxed text-neutral-300">{packageStatus}</p></div></div></section>}

          {persistenceStatus && <section className="rounded-xl border border-[#00FF9C]/30 bg-[#00FF9C]/[0.045] p-4" aria-live="polite"><div className="flex items-start gap-2">{persisting ? <Loader2 className="mt-0.5 h-4 w-4 shrink-0 animate-spin text-[#00FF9C]" /> : <Database className="mt-0.5 h-4 w-4 shrink-0 text-[#00FF9C]" />}<div><h3 className="text-xs font-bold uppercase tracking-wider text-white">Selected-wafer persistence</h3><p className="mt-1 text-xs leading-relaxed text-neutral-300">{persistenceStatus}</p></div></div></section>}

          {persistenceDiagnostics.length > 0 && <section className="rounded-xl border border-red-800/60 bg-red-950/20 p-4"><h3 className="font-mono text-[10px] font-bold uppercase tracking-wider text-red-200">Persistence diagnostics</h3><ul className="mt-2 space-y-2">{persistenceDiagnostics.map((item, index) => <li key={`${item.code ?? 'persistence'}-${index}`} className="rounded border border-red-800/50 bg-black/20 p-2.5 text-[11px] text-red-200"><div className="font-mono font-semibold">{item.code ?? 'SERVER_DIAGNOSTIC'}{item.role ? ` · ${item.role}` : ''}</div><p className="mt-1 leading-relaxed">{item.message ?? 'No diagnostic message was returned.'}</p></li>)}</ul></section>}

          {validationResult && <section className="space-y-4 rounded-xl border border-[#00E5FF]/30 bg-[#00E5FF]/[0.045] p-4" aria-live="polite">
            <div className="flex flex-wrap items-start justify-between gap-3"><div className="flex items-start gap-2"><CheckCircle2 className={`mt-0.5 h-4 w-4 shrink-0 ${validationResult.valid ? 'text-[#00FF9C]' : 'text-amber-300'}`} /><div><h3 className="text-xs font-bold uppercase tracking-wider text-white">Server package-validation result</h3><p className="mt-1 text-xs leading-relaxed text-neutral-300">Status: <strong className="text-white">{validationResult.status ?? diagnostics?.status ?? (validationResult.valid ? 'VALID' : 'INVALID')}</strong> · {validationResult.source_type ?? category} package · select one partition to persist.</p></div></div><span className={`rounded border px-2 py-1 font-mono text-[10px] uppercase ${validationResult.valid ? 'border-[#00FF9C]/35 bg-[#00FF9C]/10 text-[#00FF9C]' : 'border-amber-400/35 bg-amber-400/10 text-amber-200'}`}>{validationResult.valid ? 'Selection required' : 'Validation issues'}</span></div>

            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4"><div className="rounded border border-[#2d2d2d] bg-[#131313] p-2.5"><div className="font-mono text-[9px] uppercase tracking-wider text-neutral-500">Partitions</div><div className="mt-1 font-mono text-lg font-bold text-white">{partitionCount.toLocaleString()}</div></div><div className="rounded border border-[#2d2d2d] bg-[#131313] p-2.5"><div className="font-mono text-[9px] uppercase tracking-wider text-neutral-500">Primary source rows</div><div className="mt-1 font-mono text-lg font-bold text-white">{primaryRows.toLocaleString()}</div></div><div className="rounded border border-[#2d2d2d] bg-[#131313] p-2.5"><div className="font-mono text-[9px] uppercase tracking-wider text-neutral-500">Normalized valid rows</div><div className="mt-1 font-mono text-lg font-bold text-white">{normalizedRows.toLocaleString()}</div></div><div className="rounded border border-[#2d2d2d] bg-[#131313] p-2.5"><div className="font-mono text-[9px] uppercase tracking-wider text-neutral-500">Diagnostics</div><div className="mt-1 font-mono text-lg font-bold text-white">{numberOrZero(diagnostics?.error_count).toLocaleString()} <span className="text-xs text-red-300">errors</span> · {numberOrZero(diagnostics?.warning_count).toLocaleString()} <span className="text-xs text-amber-200">warnings</span></div></div></div>

            {validationResult.valid && partitions.length > 0 && <fieldset className="rounded-lg border border-[#00FF9C]/30 bg-[#0f1713] p-3"><legend className="px-1 font-mono text-[10px] font-bold uppercase tracking-wider text-[#00FF9C]">Choose one canonical LOT_ID + WAFER_ID partition</legend><p className="mb-3 text-[11px] leading-relaxed text-neutral-400">No partition is preselected. A positive choice is required even when the package contains one wafer.</p><div className="overflow-x-auto rounded border border-[#2d3933]"><table className="w-full min-w-[760px] text-left text-[11px]"><thead className="bg-[#141b17] font-mono text-[10px] uppercase text-neutral-400"><tr><th className="px-3 py-2">Select</th><th className="px-3 py-2">LOT_ID</th><th className="px-3 py-2">WAFER_ID</th><th className="px-3 py-2">Source product</th><th className="px-3 py-2 text-right">Source rows</th><th className="px-3 py-2 text-right">Valid</th><th className="px-3 py-2 text-right">Invalid</th><th className="px-3 py-2">Observed summary</th></tr></thead><tbody>{partitions.map((partition) => { const key = partitionKey(partition); const checked = selectedPartitionKey === key; const observedSummary = category === 'CP' ? `${numberOrZero(partition.pass_count).toLocaleString()} pass / ${numberOrZero(partition.fail_count).toLocaleString()} fail` : category === 'WAT' ? `${numberOrZero(partition.measurement_count).toLocaleString()} measurements / ${numberOrZero(partition.oos_count).toLocaleString()} OOS` : `${numberOrZero(partition.defect_count).toLocaleString()} defects / ${numberOrZero(partition.killer_count).toLocaleString()} killer`; return <tr key={key} className={`border-t border-[#27312c] ${checked ? 'bg-[#00FF9C]/10' : 'bg-[#101310]'}`}><td className="px-3 py-2.5"><input type="radio" name="package-partition" value={key} checked={checked} onChange={() => setSelectedPartitionKey(key)} aria-label={`Select lot ${partition.lot_id}, wafer ${partition.wafer_id}`} className="h-4 w-4 accent-[#00FF9C]" /></td><td className="px-3 py-2.5 font-mono font-semibold text-white">{partition.lot_id}</td><td className="px-3 py-2.5 font-mono font-semibold text-white">{partition.wafer_id}</td><td className="px-3 py-2.5 font-mono text-neutral-300">{partition.product_id ?? 'Unavailable from source'}</td><td className="px-3 py-2.5 text-right font-mono text-neutral-300">{numberOrZero(partition.source_rows).toLocaleString()}</td><td className="px-3 py-2.5 text-right font-mono text-[#00FF9C]">{numberOrZero(partition.valid_rows).toLocaleString()}</td><td className="px-3 py-2.5 text-right font-mono text-red-300">{numberOrZero(partition.invalid_rows).toLocaleString()}</td><td className="px-3 py-2.5 font-mono text-neutral-400">{observedSummary}</td></tr>; })}</tbody></table></div></fieldset>}

            {validationResult.valid && <label className="block rounded-lg border border-[#00E5FF]/25 bg-[#0d1517] p-3"><span className="block text-xs font-bold uppercase tracking-wider text-white">Display geometry template <span className="font-normal normal-case text-neutral-500">— non-authoritative</span></span><span className="mt-1 block text-[11px] leading-relaxed text-neutral-400">Controls wafer-map die and reticle drawing only. It never replaces source LOT_ID, WAFER_ID, or PRODUCT_ID.</span><select value={displayPresetId} onChange={(event) => setDisplayPresetId(event.target.value)} className="mt-3 w-full rounded border border-[#315057] bg-[#0a1011] px-3 py-2 text-xs text-white outline-none focus:border-[#00E5FF]"><option disabled value="">Choose display geometry</option>{INGESTION_PRODUCT_PRESETS.map((preset) => <option key={preset.id} value={preset.id}>{preset.label} · {preset.dieWidthMm} × {preset.dieHeightMm} mm die</option>)}</select></label>}

            {validationResult.files && validationResult.files.length > 0 && <div><h4 className="mb-2 font-mono text-[10px] font-bold uppercase tracking-wider text-neutral-400">Server file metadata</h4><div className="overflow-x-auto rounded border border-[#2d2d2d]"><table className="w-full min-w-[620px] text-left font-mono text-[10px]"><thead className="bg-[#161616] text-neutral-400"><tr><th className="px-3 py-2 font-medium">Role</th><th className="px-3 py-2 font-medium">Filename</th><th className="px-3 py-2 font-medium">Rows</th><th className="px-3 py-2 font-medium">SHA-256</th></tr></thead><tbody>{validationResult.files.map((file, index) => <tr key={`${file.role ?? 'file'}-${index}`} className="border-t border-[#242424] text-neutral-300"><td className="whitespace-nowrap px-3 py-2">{file.role ?? '—'}</td><td className="max-w-[210px] truncate px-3 py-2">{file.filename ?? '—'}</td><td className="whitespace-nowrap px-3 py-2">{numberOrZero(file.row_count).toLocaleString()}</td><td className="max-w-[250px] truncate px-3 py-2 text-neutral-400" title={file.checksum_sha256}>{file.checksum_sha256 ?? '—'}</td></tr>)}</tbody></table></div></div>}

            <div><div className="mb-2 flex items-center justify-between gap-3"><h4 className="font-mono text-[10px] font-bold uppercase tracking-wider text-neutral-400">Diagnostics</h4><span className="font-mono text-[10px] text-neutral-500">Showing up to {MAX_RENDERED_DIAGNOSTICS}{diagnostics?.truncated || (diagnostics?.items?.length ?? 0) > MAX_RENDERED_DIAGNOSTICS ? '+' : ''} items</span></div>{diagnosticItems.length > 0 ? <ul className="space-y-2">{diagnosticItems.map((item, index) => <li key={`${item.code ?? 'diagnostic'}-${index}`} className={`rounded border p-2.5 text-[11px] ${item.severity === 'ERROR' ? 'border-red-800/60 bg-red-950/20 text-red-200' : 'border-amber-500/35 bg-amber-500/[0.06] text-amber-100'}`}><div className="font-mono font-semibold">{item.severity ?? 'INFO'} · {item.code ?? 'SERVER_DIAGNOSTIC'}{item.role ? ` · ${item.role}` : ''}{item.row_number !== undefined ? ` · row ${item.row_number}` : ''}</div><p className="mt-1 leading-relaxed">{item.message ?? 'No diagnostic message was returned.'}</p></li>)}</ul> : <p className="rounded border border-[#2d2d2d] bg-[#131313] p-2.5 text-[11px] text-neutral-400">No server diagnostics were returned.</p>}</div>
          </section>}
        </div>

        <footer className="flex flex-wrap items-center justify-between gap-3 border-t border-[#242424] bg-[#141414] px-5 py-4 sm:px-6"><div className="hidden items-center gap-2 font-mono text-xs text-neutral-400 sm:flex"><Database className="h-4 w-4 text-[#00FF9C]" />One selected source partition per retained dataset</div><div className="ml-auto flex flex-wrap justify-end gap-3"><button type="button" onClick={closeStudio} disabled={persisting} className="rounded-lg border border-neutral-700 bg-neutral-900 px-4 py-2 text-xs font-semibold text-neutral-300 transition-colors hover:bg-neutral-800 hover:text-white disabled:cursor-wait disabled:opacity-40">Cancel</button><button id="btn-validate-package" type="button" onClick={() => void validatePackage()} disabled={validating || persisting} className="flex items-center gap-2 rounded-lg border border-[#00E5FF]/60 bg-[#00E5FF]/10 px-4 py-2 text-xs font-bold text-[#00E5FF] transition-colors hover:bg-[#00E5FF]/20 disabled:cursor-not-allowed disabled:border-neutral-800 disabled:bg-neutral-900 disabled:text-neutral-500"><span>{validating ? 'Validating package…' : 'Validate package schema'}</span>{validating ? <Loader2 className="h-4 w-4 animate-spin" /> : <ClipboardCheck className="h-4 w-4" />}</button><button id="btn-persist-selected-wafer" type="button" onClick={() => void persistSelectedPartition()} disabled={!canPersist} className="flex items-center gap-2 rounded-lg bg-[#00FF9C] px-4 py-2 text-xs font-bold text-black transition-colors hover:bg-[#00e58c] disabled:cursor-not-allowed disabled:bg-neutral-800 disabled:text-neutral-500"><span>{persisting ? 'Persisting selected wafer…' : 'Persist selected wafer'}</span>{persisting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}</button></div></footer>
      </section>
    </div>
  );
}
