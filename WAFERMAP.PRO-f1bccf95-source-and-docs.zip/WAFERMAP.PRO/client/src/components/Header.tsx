import React from 'react';
import {
  Activity,
  BarChart3,
  Cpu,
  Database,
  Download,
  Eye,
  Grid,
  History,
  Layers,
  LogIn,
  RotateCcw,
  Search,
  Upload,
  Zap,
} from 'lucide-react';
import { ColormapMode, IngestedDataType, IngestedWaferData, ViewDisplayMode, WaferMetadata } from '../types';

interface HeaderProps {
  metadata: WaferMetadata;
  viewMode: ViewDisplayMode;
  setViewMode: (mode: ViewDisplayMode) => void;
  colormap: ColormapMode;
  setColormap: (map: ColormapMode) => void;
  onOpenOptimizer: () => void;
  onOpenAnalytics: () => void;
  onOpenExport: () => void;
  onOpenReticleStudio: () => void;
  onOpenIngestion: () => void;
  onOpenDataLibrary: () => void;
  onOpenCpAnalysis: () => void;
  onOpenDataCriteria: () => void;
  onOpenAnalysisHistory: () => void;
  onOpenImportHistory: () => void;
  onResetView: () => void;
  isOptimizing?: boolean;
  sessionStatus?: string | null;
  availableDataTypes?: IngestedDataType[];
  hasCpData?: boolean;
  activeDatasets: Partial<Record<IngestedDataType, IngestedWaferData>>;
}

export const Header: React.FC<HeaderProps> = ({
  metadata,
  viewMode,
  setViewMode,
  onOpenOptimizer,
  onOpenAnalytics,
  onOpenExport,
  onOpenReticleStudio,
  onOpenIngestion,
  onOpenDataLibrary,
  onOpenCpAnalysis,
  onOpenDataCriteria,
  onOpenAnalysisHistory,
  onOpenImportHistory,
  onResetView,
  isOptimizing = false,
  sessionStatus,
  availableDataTypes = [],
  hasCpData = false,
  activeDatasets,
}) => {
  const cpSummary = activeDatasets.CP?.dataset.summary;
  const hasWatData = availableDataTypes.includes('WAT');
  const hasKlaData = availableDataTypes.includes('KLA');
  const hasRealData = availableDataTypes.length > 0;
  const oauthPortalUrl = import.meta.env.VITE_OAUTH_PORTAL_URL;
  const appId = import.meta.env.VITE_APP_ID;

  const startSignIn = () => {
    if (!oauthPortalUrl || !appId) {
      window.alert('Authentication is not configured for this deployment.');
      return;
    }
    const redirectUri = `${window.location.origin}/api/oauth/callback`;
    const nonce = crypto.randomUUID();
    // This host-only cookie binds the OAuth response to the browser that began
    // the sign-in flow. The Node host verifies it before redeeming the code.
    document.cookie = `__Host-oauth_state=${nonce}; Path=/; Max-Age=600; SameSite=None; Secure`;
    const state = btoa(JSON.stringify({ redirectUri, nonce }));
    const query = new URLSearchParams({ app_id: appId, redirect_url: redirectUri, state });
    window.location.assign(`${oauthPortalUrl.replace(/\/$/, '')}/login?${query.toString()}`);
  };

  const viewButton = (
    mode: ViewDisplayMode,
    label: string,
    title: string,
    icon: React.ReactNode,
    enabled = true,
  ) => (
    <button
      type="button"
      id={`btn-view-${mode}`}
      onClick={() => enabled && setViewMode(mode)}
      disabled={!enabled}
      className={`flex items-center gap-1.5 rounded-xs px-3 py-1.5 font-mono text-xs uppercase tracking-wider transition-all ${viewMode === mode ? 'bg-[#E5E5E5] font-bold text-black' : enabled ? 'text-[#888] hover:bg-[#111] hover:text-white' : 'cursor-not-allowed text-[#333]'}`}
      title={enabled ? title : `${title} — retained source required`}
    >
      {icon}{label}
    </button>
  );

  return (
    <header id="main-app-header" className="sticky top-0 z-30 flex flex-wrap items-center justify-between gap-4 border-b border-[#222] bg-[#0C0C0C] px-6 py-3.5">
      <div className="flex items-center gap-4">
        <div className="flex h-10 w-10 items-center justify-center rounded-sm border border-[#222] bg-[#111] text-[#00FF9C]"><Cpu className="h-5 w-5" /></div>
        <div>
          <span className="text-[9px] font-bold uppercase tracking-[0.3em] text-[#555]">Precision geometry / retained fab data</span>
          <div className="flex items-baseline gap-2.5"><h1 className="text-2xl font-extrabold italic leading-none tracking-tighter">WAFERMAP<span className="text-[#00FF9C]">.PRO</span></h1><span className="rounded-sm border border-[#222] bg-[#111] px-2 py-0.5 font-mono text-[10px] text-[#00FF9C]">{metadata.diameter_mm}mm</span></div>
        </div>
      </div>

      <div className="hidden items-center gap-5 rounded-sm border border-[#222] bg-[#111] px-4 py-2 font-mono text-xs lg:flex">
        {cpSummary ? <>
          <div><span className="block text-[9px] uppercase tracking-[0.2em] text-[#555]">CP tested dies</span><strong className="text-sm text-white">{cpSummary.stats.gross_items.toLocaleString()}</strong></div>
          <div className="h-6 w-px bg-[#222]" />
          <div><span className="block text-[9px] uppercase tracking-[0.2em] text-[#555]">Pass / fail</span><strong className="text-sm"><span className="text-[#00FF9C]">{cpSummary.stats.pass_count.toLocaleString()}</span><span className="text-[#444]"> / </span><span className="text-[#FF5A52]">{cpSummary.stats.fail_count.toLocaleString()}</span></strong></div>
          <div className="h-6 w-px bg-[#222]" />
          <div><span className="block text-[9px] uppercase tracking-[0.2em] text-[#555]">Observed yield</span><strong className="text-sm text-[#00E5FF]">{cpSummary.stats.yield_pct}%</strong></div>
          <div className="h-6 w-px bg-[#222]" />
          <div><span className="block text-[9px] uppercase tracking-[0.2em] text-[#555]">Source</span><strong className="text-sm text-[#AAA]">Dataset #{activeDatasets.CP!.dataset.dataset_id}</strong></div>
        </> : <div className="min-w-72"><span className="block text-[9px] uppercase tracking-[0.2em] text-[#FFAE00]">No real data loaded</span><strong className="text-xs font-normal text-[#777]">Geometry-only · manufacturing KPIs unavailable</strong></div>}
      </div>

      <div className="flex items-center gap-1 rounded-sm border border-[#222] bg-[#080808] p-1">
        {viewButton('bin_category', 'Bin map', 'Imported CP bin map', <Grid className="h-3.5 w-3.5" />, hasCpData)}
        {viewButton('parametric_heatmap', 'Parametric', 'Imported CP parametric map', <Activity className="h-3.5 w-3.5" />, Boolean(activeDatasets.CP?.cpRecords?.some((record) => record.param_value != null)))}
        {viewButton('shot_grid', 'Shot grid', 'Geometry shot grid with observed CP aggregation', <Layers className="h-3.5 w-3.5" />, hasCpData)}
        {hasWatData && viewButton('wat_sites', 'WAT', 'Imported WAT site overlay', <Activity className="h-3.5 w-3.5" />)}
        {hasKlaData && viewButton('kla_defects', 'KLA', 'Imported KLA defect overlay', <Eye className="h-3.5 w-3.5" />)}
      </div>

      <div className="flex items-center gap-2">
        <div className="mr-1 hidden max-w-40 flex-col items-end xl:flex"><span className="text-[8px] uppercase tracking-[0.16em] text-[#555]">Workspace</span><span className={`max-w-40 truncate font-mono text-[9px] ${hasRealData ? 'text-[#00FF9C]' : 'text-[#FFAE00]'}`}>{sessionStatus || (hasRealData ? 'Retained source active' : 'Geometry only')}</span></div>
        <button id="btn-open-ingestion" type="button" onClick={onOpenIngestion} className="flex items-center gap-1.5 rounded-sm border border-[#222] bg-[#111] px-3 py-1.5 text-xs font-bold uppercase tracking-widest hover:border-[#00E5FF] hover:text-[#00E5FF]" title="Prepare a CP, WAT, or KLA real-data package"><Upload className="h-3.5 w-3.5 text-[#00E5FF]" />Real data</button>
        <button id="btn-start-sign-in" type="button" onClick={startSignIn} className="flex items-center gap-1.5 rounded-sm border border-[#00FF9C]/35 bg-[#00FF9C]/10 px-3 py-1.5 text-xs font-bold uppercase tracking-widest text-[#00FF9C] hover:bg-[#00FF9C]/20" title="Sign in to retain source data, queue jobs, and access owner-scoped reports"><LogIn className="h-3.5 w-3.5" />Sign in</button>
        <button id="btn-open-data-criteria" type="button" onClick={onOpenDataCriteria} className="flex items-center gap-1.5 rounded-sm border border-[#00E5FF]/40 bg-[#00E5FF]/10 px-3 py-1.5 text-xs font-bold uppercase tracking-widest text-[#00E5FF] hover:bg-[#00E5FF]/20"><Search className="h-3.5 w-3.5" />Data criteria</button>
        <button id="btn-open-dataset-library" type="button" onClick={onOpenDataLibrary} className="flex items-center gap-1.5 rounded-sm border border-[#222] bg-[#111] px-3 py-1.5 text-xs font-bold uppercase tracking-widest hover:border-[#00E5FF] hover:text-[#00E5FF]"><Database className="h-3.5 w-3.5 text-[#00E5FF]" />Data library</button>
        <button id="btn-open-cp-analysis" type="button" onClick={onOpenCpAnalysis} className="flex items-center gap-1.5 rounded-sm border border-[#222] bg-[#111] px-3 py-1.5 text-xs font-bold uppercase tracking-widest hover:border-[#00FF9C] hover:text-[#00FF9C]"><Activity className="h-3.5 w-3.5 text-[#00FF9C]" />CP analysis</button>
        <button id="btn-open-import-history" type="button" onClick={onOpenImportHistory} className="rounded-sm border border-[#222] bg-[#111] p-2 hover:border-[#00FF9C] hover:text-[#00FF9C]" title="Open authenticated import-run history" aria-label="Open authenticated import-run history"><History className="h-4 w-4" /></button>
        <button id="btn-open-analysis-history" type="button" onClick={onOpenAnalysisHistory} className="rounded-sm border border-[#222] bg-[#111] p-2 hover:border-[#00E5FF] hover:text-[#00E5FF]" title="Open authenticated analysis job and report history" aria-label="Open analysis job and report history"><History className="h-4 w-4" /></button>
        <button id="btn-open-reticle-studio" type="button" onClick={onOpenReticleStudio} className="flex items-center gap-1.5 rounded-sm border border-[#222] bg-[#111] px-3 py-1.5 text-xs font-bold uppercase tracking-widest hover:border-[#00FF9C] hover:text-[#00FF9C]"><Cpu className="h-3.5 w-3.5 text-[#00FF9C]" />Reticle</button>
        <button id="btn-open-optimizer" type="button" onClick={onOpenOptimizer} disabled={isOptimizing} className="flex items-center gap-1.5 rounded-sm bg-[#00FF9C] px-3.5 py-1.5 text-xs font-bold uppercase tracking-widest text-black disabled:opacity-50" title="Deterministic center-offset grid search using geometry and GDPW only"><Zap className="h-3.5 w-3.5" />Geometry search</button>
        <button id="btn-open-analytics" type="button" onClick={onOpenAnalytics} className="rounded-sm border border-[#222] bg-[#111] p-2 hover:border-[#00FF9C] hover:text-[#00FF9C]" title="Open the retained-source spatial analysis gate"><BarChart3 className="h-4 w-4" /></button>
        <button id="btn-open-export" type="button" onClick={onOpenExport} className="rounded-sm border border-[#222] bg-[#111] p-2 hover:border-[#00FF9C] hover:text-[#00FF9C]" title="Review source-backed export availability"><Download className="h-4 w-4" /></button>
        <button id="btn-reset-view" type="button" onClick={onResetView} className="rounded-sm border border-[#222] bg-[#111] p-2 text-[#888] hover:text-white" title="Reset zoom and center"><RotateCcw className="h-4 w-4" /></button>
      </div>
    </header>
  );
};
