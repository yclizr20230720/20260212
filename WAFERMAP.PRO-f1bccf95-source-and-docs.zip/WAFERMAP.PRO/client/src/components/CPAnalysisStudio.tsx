import React, { useEffect, useMemo, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  BarChart3,
  CheckCircle2,
  ChevronRight,
  ClipboardList,
  CloudDownload,
  Crosshair,
  Database,
  FileJson,
  FlaskConical,
  Layers,
  Loader2,
  Microscope,
  Network,
  RadioTower,
  RefreshCw,
  ShieldAlert,
  SlidersHorizontal,
  Sparkles,
  Upload,
  X,
} from 'lucide-react';
import {
  AnalysisJobRecord,
  IngestedDataType,
  IngestedWaferData,
  IngestionAnalysisResponse,
  QueueAnalysisJobRequest,
  QueueAnalysisJobResponse,
} from '../types';

interface CPAnalysisStudioProps {
  isOpen: boolean;
  onClose: () => void;
  activeDatasets: Partial<Record<IngestedDataType, IngestedWaferData>>;
  selectedBin: number | null;
  onFilterBin: (bin: number | null) => void;
  onOpenIngestion: () => void;
  onOpenDatasetLibrary: () => void;
  onOpenAnalysisHistory: () => void;
}

type AnalysisTab = 'criteria' | 'pareto' | 'killRatio' | 'spatial' | 'ocap' | 'process' | 'telemetry' | 'whatIf' | 'crossDomain' | 'lineage';

const TAB_ITEMS = [
  { key: 'criteria', label: 'Data criteria', icon: Database, accent: 'cyan' },
  { key: 'pareto', label: 'Bin Pareto', icon: BarChart3, accent: 'green' },
  { key: 'killRatio', label: 'KLA overlap trace', icon: ShieldAlert, accent: 'rose' },
  { key: 'spatial', label: 'Spatial screening', icon: Crosshair, accent: 'cyan' },
  { key: 'ocap', label: 'OCAP triage', icon: ClipboardList, accent: 'amber' },
  { key: 'process', label: 'Process window', icon: SlidersHorizontal, accent: 'amber' },
  { key: 'telemetry', label: 'Test signals', icon: RadioTower, accent: 'violet' },
  { key: 'whatIf', label: 'Observed scenarios', icon: Activity, accent: 'green' },
  { key: 'crossDomain', label: 'Cross-domain', icon: Microscope, accent: 'rose' },
  { key: 'lineage', label: 'Data lineage', icon: Layers, accent: 'neutral' },
] as const;

function sourceLabel(sourceType: IngestedDataType): string {
  return sourceType === 'CP' ? 'CP wafer sort' : sourceType === 'WAT' ? 'WAT metrology' : 'KLA defect inspection';
}

function metric(value: number | null | undefined, decimals = 2): string {
  return value === null || value === undefined || !Number.isFinite(value) ? '—' : value.toLocaleString(undefined, { maximumFractionDigits: decimals });
}

function badgeClass(accent: (typeof TAB_ITEMS)[number]['accent']): string {
  if (accent === 'cyan') return 'border-[#00E5FF]/40 bg-[#00E5FF]/10 text-[#00E5FF]';
  if (accent === 'green') return 'border-[#00FF9C]/40 bg-[#00FF9C]/10 text-[#00FF9C]';
  if (accent === 'rose') return 'border-[#FF5A52]/40 bg-[#FF5A52]/10 text-[#FF8b85]';
  if (accent === 'amber') return 'border-[#FFAE00]/40 bg-[#FFAE00]/10 text-[#FFAE00]';
  if (accent === 'violet') return 'border-[#B779FF]/40 bg-[#B779FF]/10 text-[#caa2ff]';
  return 'border-neutral-600 bg-neutral-800/70 text-neutral-300';
}

export function buildCpYmsReport(analysis: IngestionAnalysisResponse, activeDatasets: Partial<Record<IngestedDataType, IngestedWaferData>>) {
  return {
    report_type: 'WAFERMAP.PRO_CP_YMS_LOCAL_SESSION_PREVIEW',
    generated_at_utc: new Date().toISOString(),
    data_governance: {
      scope: 'Aggregates are calculated from retained normalized CP, WAT, and KLA measurements only.',
      exclusions: ['No synthetic VEDA lot records', 'No inferred tester or tool telemetry', 'No causal root-cause assertion', 'No simulated yield recovery'],
    },
    active_sources: (Object.keys(activeDatasets) as IngestedDataType[])
      .filter((sourceType) => activeDatasets[sourceType])
      .map((sourceType) => ({
        source_type: sourceType,
        dataset_id: activeDatasets[sourceType]!.dataset.dataset_id,
        source_filename: activeDatasets[sourceType]!.dataset.summary.source_filename,
        lot_id: activeDatasets[sourceType]!.dataset.summary.lot_id,
        wafer_id: activeDatasets[sourceType]!.dataset.summary.wafer_id,
        product_id: activeDatasets[sourceType]!.dataset.summary.product_name,
      })),
    analysis,
  };
}

function downloadJson(filename: string, payload: unknown) {
  const href = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' }));
  const anchor = document.createElement('a');
  anchor.href = href;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(href), 0);
}

export function CPAnalysisStudio({ isOpen, onClose, activeDatasets, selectedBin, onFilterBin, onOpenIngestion, onOpenDatasetLibrary, onOpenAnalysisHistory }: CPAnalysisStudioProps) {
  const [tab, setTab] = useState<AnalysisTab>('criteria');
  const [analysis, setAnalysis] = useState<IngestionAnalysisResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showJsonPreview, setShowJsonPreview] = useState(false);
  const [queueing, setQueueing] = useState(false);
  const [queuedJob, setQueuedJob] = useState<AnalysisJobRecord | null>(null);
  const [queueError, setQueueError] = useState<string | null>(null);
  const cpId = activeDatasets.CP?.dataset.dataset_id ?? null;
  const watId = activeDatasets.WAT?.dataset.dataset_id ?? null;
  const klaId = activeDatasets.KLA?.dataset.dataset_id ?? null;

  useEffect(() => {
    if (!isOpen || !cpId) {
      if (!cpId) setAnalysis(null);
      return;
    }
    const controller = new AbortController();
    const load = async () => {
      setLoading(true);
      setError(null);
      try {
        const params = new URLSearchParams();
        if (watId) params.set('wat_dataset_id', String(watId));
        if (klaId) params.set('kla_dataset_id', String(klaId));
        const response = await fetch(`/api/ingestion/datasets/${cpId}/analysis?${params.toString()}`, { signal: controller.signal });
        const payload = await response.json();
        if (!response.ok) throw new Error(payload.message || 'The CP and YMS analysis service is unavailable.');
        setAnalysis(payload as IngestionAnalysisResponse);
      } catch (caught) {
        if (!controller.signal.aborted) setError(caught instanceof Error ? caught.message : 'Unable to load the CP and YMS analysis.');
      } finally {
        if (!controller.signal.aborted) setLoading(false);
      }
    };
    void load();
    return () => controller.abort();
  }, [isOpen, cpId, watId, klaId]);

  const activeSourceTypes = (Object.keys(activeDatasets) as IngestedDataType[]).filter((sourceType) => activeDatasets[sourceType]);
  const maxBinCount = useMemo(() => Math.max(1, ...(analysis?.cp.bins.map((bin) => bin.count) || [1])), [analysis]);
  const report = useMemo(() => (analysis ? buildCpYmsReport(analysis, activeDatasets) : null), [analysis, activeDatasets]);

  if (!isOpen) return null;

  const openIngestion = () => {
    onClose();
    onOpenIngestion();
  };
  const openLibrary = () => {
    onClose();
    onOpenDatasetLibrary();
  };

  const queueSourceBackedAnalysis = async () => {
    if (!cpId) return;
    setQueueing(true);
    setQueueError(null);
    setQueuedJob(null);
    try {
      const request: QueueAnalysisJobRequest = {
        cp_dataset_id: cpId,
        ...(watId ? { wat_dataset_id: watId } : {}),
        ...(klaId ? { kla_dataset_id: klaId } : {}),
      };
      const response = await fetch('/api/analysis/jobs', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(request),
      });
      const payload = await response.json().catch(() => null) as QueueAnalysisJobResponse & { message?: string } | null;
      if (response.status === 401 || response.status === 403) throw new Error('Authentication is required to queue a source-backed analysis job.');
      if (response.status === 404) throw new Error('The analysis queue service is unavailable in this environment.');
      if (!response.ok) throw new Error(payload?.message || 'The source-backed analysis job could not be queued.');
      const record = payload?.job ?? (payload?.job_id != null && payload.status ? {
        job_id: payload.job_id,
        status: payload.status,
        cp_dataset_id: cpId,
        wat_dataset_id: watId,
        kla_dataset_id: klaId,
      } : null);
      if (!record) throw new Error('The analysis queue returned an unexpected response.');
      setQueuedJob(record);
    } catch (caught) {
      setQueueError(caught instanceof Error ? caught.message : 'The source-backed analysis job could not be queued.');
    } finally {
      setQueueing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-3 backdrop-blur-md sm:p-5" role="dialog" aria-modal="true" aria-label="CP and YMS analysis studio">
      <section className="flex max-h-[94vh] w-full max-w-[96rem] flex-col overflow-hidden rounded-xl border border-[#2a2a2a] bg-[#0d0d0d] text-[#ddd] shadow-2xl">
        <header className="flex flex-wrap items-center justify-between gap-3 border-b border-[#242424] bg-[#141414] px-5 py-4 sm:px-6">
          <div className="flex min-w-0 items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-[#00FF9C]/30 bg-[#00FF9C]/10 text-[#00FF9C]"><BarChart3 className="h-5 w-5" /></div>
            <div className="min-w-0">
              <h2 className="flex flex-wrap items-center gap-2 text-base font-black tracking-wide text-white sm:text-lg">CP WAFER SORT &amp; YMS ANALYSIS STUDIO <span className="rounded border border-[#00FF9C]/35 bg-[#00FF9C]/15 px-2 py-0.5 font-mono text-[10px] text-[#00FF9C]">GOVERNED • SOURCE-BACKED • TRACEABLE</span></h2>
              <p className="mt-0.5 text-xs text-neutral-400">CP, WAT, and KLA aggregates; coordinate screening; OCAP decision support; and retained-source analysis export.</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {cpId && <button id="btn-queue-source-analysis" type="button" onClick={() => void queueSourceBackedAnalysis()} disabled={queueing} className="flex items-center gap-1.5 rounded-lg bg-[#00FF9C] px-3 py-2 text-xs font-black text-black shadow-[0_0_15px_rgba(0,255,156,0.22)] transition-colors hover:bg-[#00e58c] disabled:cursor-wait disabled:opacity-50">{queueing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}Queue source-backed analysis</button>}
            {report && <button type="button" onClick={() => setShowJsonPreview(true)} className="flex items-center gap-1.5 rounded-lg border border-[#383838] bg-[#1a1a1a] px-3 py-2 text-xs font-bold text-white transition-colors hover:border-[#00E5FF] hover:text-[#00E5FF]"><FileJson className="h-3.5 w-3.5 text-[#00E5FF]" />Local session preview</button>}
            {report && <button type="button" onClick={() => downloadJson(`${analysis!.cp.dataset.lot_id}_${analysis!.cp.dataset.wafer_id}_CP_YMS_Local_Session_Preview.json`, report)} className="flex items-center gap-1.5 rounded-lg border border-[#00E5FF]/45 bg-[#00E5FF]/10 px-3 py-2 text-xs font-bold text-[#00E5FF] transition-colors hover:bg-[#00E5FF]/20"><CloudDownload className="h-3.5 w-3.5" />Save local preview</button>}
            <button type="button" onClick={onClose} className="rounded-lg p-2 text-neutral-400 transition-colors hover:bg-neutral-800 hover:text-white" aria-label="Close CP and YMS analysis studio"><X className="h-5 w-5" /></button>
          </div>
        </header>

        <div className="border-b border-[#242424] bg-[#0f0f0f] px-5 py-2.5 sm:px-6">
          <div className="flex overflow-x-auto rounded-lg border border-[#292929] bg-black/60 p-1">
            {TAB_ITEMS.map(({ key, label, icon: Icon, accent }) => <button key={key} type="button" onClick={() => setTab(key)} className={`flex shrink-0 items-center gap-1.5 rounded-md border px-3 py-1.5 text-xs font-semibold transition-colors ${tab === key ? badgeClass(accent) : 'border-transparent text-neutral-300 hover:bg-neutral-800 hover:text-white'}`}><Icon className="h-3.5 w-3.5" />{label}</button>)}
          </div>
          <div className="mt-2 flex flex-wrap items-center justify-between gap-2 font-mono text-[10px] text-neutral-500">
            <span>Active sources: {activeSourceTypes.length ? activeSourceTypes.map(sourceLabel).join(' · ') : 'none selected'}</span>
            {analysis && <span className="text-[#00FF9C]">Lot {analysis.cp.dataset.lot_id} · Wafer {analysis.cp.dataset.wafer_id} · Yield {metric(analysis.cp.yield_pct)}%</span>}
          </div>
          {queuedJob && <div className="mt-2 flex flex-wrap items-center justify-between gap-2 rounded border border-[#00FF9C]/30 bg-[#00FF9C]/[0.06] px-3 py-2 text-[11px] text-neutral-300" aria-live="polite"><span>Server job <strong className="font-mono text-white">{String(queuedJob.job_id)}</strong> returned <strong className="font-mono uppercase text-[#00FF9C]">{queuedJob.status}</strong>.</span><button type="button" onClick={onOpenAnalysisHistory} className="font-bold text-[#00E5FF] hover:underline">Open job &amp; report history</button></div>}
          {queueError && <div role="alert" className="mt-2 rounded border border-red-800/60 bg-red-950/30 px-3 py-2 text-[11px] text-red-300">{queueError}</div>}
        </div>

        <div className="flex-1 overflow-y-auto p-5 sm:p-6">
          {!cpId ? <CpRequiredState onOpenIngestion={openIngestion} onOpenLibrary={openLibrary} /> : loading ? <div className="flex min-h-80 items-center justify-center gap-2 text-sm text-neutral-400"><Loader2 className="h-5 w-5 animate-spin text-[#00FF9C]" />Calculating source-backed CP and YMS aggregates…</div> : error ? <div role="alert" className="flex min-h-56 flex-col items-center justify-center rounded-xl border border-red-800 bg-red-950/30 p-6 text-center"><AlertTriangle className="mb-3 h-7 w-7 text-red-300" /><h3 className="font-bold text-red-200">Analysis unavailable</h3><p className="mt-1 max-w-xl text-xs text-red-300">{error}</p><button type="button" onClick={openLibrary} className="mt-4 rounded border border-red-700 px-3 py-1.5 text-xs text-red-200 hover:bg-red-950">Review loaded datasets</button></div> : analysis && <>
            {tab === 'criteria' && <CriteriaPanel activeDatasets={activeDatasets} onOpenIngestion={openIngestion} onOpenLibrary={openLibrary} />}
            {tab === 'pareto' && <ParetoPanel analysis={analysis} maxBinCount={maxBinCount} selectedBin={selectedBin} onFilterBin={onFilterBin} />}
            {tab === 'killRatio' && <KillRatioPanel analysis={analysis} onOpenIngestion={openIngestion} />}
            {tab === 'spatial' && <SpatialPanel analysis={analysis} />}
            {tab === 'ocap' && <OcapPanel analysis={analysis} />}
            {tab === 'process' && <ProcessPanel analysis={analysis} onOpenIngestion={openIngestion} />}
            {tab === 'telemetry' && <TelemetryPanel analysis={analysis} />}
            {tab === 'whatIf' && <ObservedScenarioPanel analysis={analysis} />}
            {tab === 'crossDomain' && <CrossDomainPanel analysis={analysis} onOpenIngestion={openIngestion} />}
            {tab === 'lineage' && <LineagePanel activeDatasets={activeDatasets} onOpenLibrary={openLibrary} />}
          </>}
        </div>
      </section>

      {showJsonPreview && report && <JsonPreview report={report} onClose={() => setShowJsonPreview(false)} onDownload={() => downloadJson(`${analysis!.cp.dataset.lot_id}_${analysis!.cp.dataset.wafer_id}_CP_YMS_Local_Session_Preview.json`, report)} />}
    </div>
  );
}

function Kpi({ label, value, detail, tone = 'neutral' }: { label: string; value: string; detail: string; tone?: 'neutral' | 'good' | 'bad' | 'cyan' | 'amber' }) {
  const colour = tone === 'good' ? 'text-[#00FF9C]' : tone === 'bad' ? 'text-[#FF5A52]' : tone === 'cyan' ? 'text-[#00E5FF]' : tone === 'amber' ? 'text-[#FFAE00]' : 'text-white';
  return <div className="rounded-xl border border-[#242424] bg-[#121212] p-4"><div className="font-mono text-[10px] uppercase tracking-wider text-neutral-500">{label}</div><div className={`mt-1 font-mono text-2xl font-black ${colour}`}>{value}</div><div className="mt-1 text-[10px] leading-relaxed text-neutral-500">{detail}</div></div>;
}

function Section({ title, detail, children, icon: Icon = Layers }: { title: string; detail: string; children: React.ReactNode; icon?: React.ComponentType<{ className?: string }> }) {
  return <section className="overflow-hidden rounded-xl border border-[#242424] bg-[#121212]"><div className="border-b border-[#242424] p-4 sm:p-5"><h3 className="flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-white"><Icon className="h-4 w-4 text-[#00FF9C]" />{title}</h3><p className="mt-1 text-xs leading-relaxed text-neutral-400">{detail}</p></div>{children}</section>;
}

function CpRequiredState({ onOpenIngestion, onOpenLibrary }: { onOpenIngestion: () => void; onOpenLibrary: () => void }) {
  return <div className="flex min-h-80 flex-col items-center justify-center rounded-xl border border-dashed border-[#353535] bg-[#121212] p-8 text-center"><Database className="mb-3 h-10 w-10 text-[#00E5FF]" /><h3 className="text-base font-bold text-white">Select a retained CP source</h3><p className="mt-2 max-w-xl text-xs leading-relaxed text-neutral-400">The CP &amp; YMS studio is available now. Select a retained CP wafer-sort dataset to calculate its Pareto, spatial screening, OCAP evidence, process statistics, and source-backed report. WAT and KLA are optional add-ons.</p><div className="mt-5 flex flex-wrap justify-center gap-3"><button type="button" onClick={onOpenLibrary} className="flex items-center gap-2 rounded-lg border border-[#00E5FF]/50 bg-[#00E5FF]/10 px-4 py-2 text-xs font-bold text-[#00E5FF] hover:bg-[#00E5FF]/20"><Database className="h-4 w-4" />Choose retained CP data</button><button type="button" onClick={onOpenIngestion} className="flex items-center gap-2 rounded-lg bg-[#00FF9C] px-4 py-2 text-xs font-bold text-black hover:bg-[#00e58c]"><Upload className="h-4 w-4" />Ingest CP data</button></div></div>;
}

function CriteriaPanel({ activeDatasets, onOpenIngestion, onOpenLibrary }: { activeDatasets: Partial<Record<IngestedDataType, IngestedWaferData>>; onOpenIngestion: () => void; onOpenLibrary: () => void }) {
  return <div className="space-y-5"><div className="grid gap-3 sm:grid-cols-3">{(['CP', 'WAT', 'KLA'] as IngestedDataType[]).map((sourceType) => { const data = activeDatasets[sourceType]; return <div key={sourceType} className={`rounded-xl border p-4 ${data ? 'border-[#303030] bg-[#121212]' : 'border-dashed border-[#303030] bg-[#101010]'}`}><div className="flex items-center justify-between"><span className="font-mono text-sm font-bold text-white">{sourceType}</span>{data ? <CheckCircle2 className="h-4 w-4 text-[#00FF9C]" /> : <span className="text-[10px] text-neutral-600">optional</span>}</div>{data ? <><div className="mt-3 text-xs font-medium text-neutral-200">{sourceLabel(sourceType)}</div><div className="mt-2 truncate font-mono text-[10px] text-neutral-500" title={data.dataset.summary.source_filename}>{data.dataset.summary.source_filename}</div><div className="mt-3 text-xs text-[#00E5FF]">Dataset #{data.dataset.dataset_id}</div><div className="mt-1 text-[10px] text-neutral-500">{data.dataset.summary.valid_rows.toLocaleString()} validated rows</div></> : <p className="mt-3 text-[11px] leading-relaxed text-neutral-500">No active {sourceType} dataset is selected.</p>}</div>; })}</div><Section title="Stage 1 — retained source selection" detail="Choose a CP wafer-sort source first. WAT and KLA are compatible when their stored LOT_ID and WAFER_ID match the active CP source; PRODUCT_ID is retained as provenance but is not a compatibility gate." icon={Database}><div className="flex flex-wrap items-center justify-between gap-3 p-5"><div className="text-xs leading-relaxed text-neutral-400">The full retained data library offers product, lot, wafer, and source-type criteria without exposing arbitrary database tables.</div><div className="flex gap-2"><button type="button" onClick={onOpenLibrary} className="rounded border border-[#00E5FF]/50 bg-[#00E5FF]/10 px-3 py-2 text-xs font-bold text-[#00E5FF] hover:bg-[#00E5FF]/20">Open retained data library</button><button type="button" onClick={onOpenIngestion} className="rounded bg-[#00FF9C] px-3 py-2 text-xs font-black text-black hover:bg-[#00e58c]">Ingest fab data</button></div></div></Section></div>;
}

function ParetoPanel({ analysis, maxBinCount, selectedBin, onFilterBin }: { analysis: IngestionAnalysisResponse; maxBinCount: number; selectedBin: number | null; onFilterBin: (bin: number | null) => void }) {
  const topBin = analysis.cp.bins[0];
  return <div className="space-y-5"><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4"><Kpi label="Total tested dies" value={analysis.cp.total_dies.toLocaleString()} detail={`Dataset #${analysis.cp.dataset.id}`} /><Kpi label="Passing yield" value={`${metric(analysis.cp.yield_pct)}%`} detail={`${analysis.cp.pass_dies.toLocaleString()} passing dies`} tone="good" /><Kpi label="Total failures" value={analysis.cp.fail_dies.toLocaleString()} detail={`${analysis.cp.bins.length} observed fail bins`} tone="bad" /><Kpi label="Top detractor" value={topBin ? `B${topBin.bin_code}` : 'None'} detail={topBin ? `${topBin.percent_of_fails}% of fails` : 'No failing bins'} tone="amber" /></div><Section title="Bin yield detractor Pareto & cumulative loss" detail="Bar height is the observed fail volume. Cumulative loss uses the selected CP source only; click a bar or row to cross-filter the wafer canvas." icon={BarChart3}><div className="p-4 sm:p-5"><div className="grid min-h-64 grid-cols-2 items-end gap-2 rounded-lg border border-[#2c2c2c] bg-[#0b0b0b] p-4 sm:grid-cols-4 lg:grid-cols-8">{analysis.cp.bins.map((bin) => { const active = selectedBin === bin.bin_code; const height = Math.max(8, Math.round((bin.count / maxBinCount) * 100)); return <button type="button" key={bin.bin_code} onClick={() => onFilterBin(active ? null : bin.bin_code)} className={`group flex h-full flex-col justify-end rounded p-1 text-center transition-colors ${active ? 'bg-[#00FF9C]/15 ring-1 ring-[#00FF9C]' : 'hover:bg-white/[0.04]'}`}><span className="mb-1 text-[10px] font-mono text-neutral-500">{bin.count.toLocaleString()}</span><span className="block w-full rounded-t" style={{ height: `${height}%`, minHeight: '12px', backgroundColor: active ? '#00FF9C' : '#FF5A52' }} /><span className="mt-2 font-mono text-[10px] text-neutral-300">B{bin.bin_code}</span><span className="font-mono text-[9px] text-[#FFAE00]">{bin.cumulative_percent}%</span></button>; })}</div><div className="mt-4 overflow-x-auto"><table className="w-full text-left text-xs"><thead className="border-b border-[#2b2b2b] font-mono text-[10px] uppercase text-neutral-500"><tr><th className="pb-2 pr-3">Bin</th><th className="pb-2 pr-3">Classification</th><th className="pb-2 text-right">Count</th><th className="pb-2 text-right">% of fails</th><th className="pb-2 text-right">Cumulative</th><th className="pb-2 text-right">Map</th></tr></thead><tbody>{analysis.cp.bins.map((bin) => <tr key={bin.bin_code} className={`border-b border-[#202020] ${selectedBin === bin.bin_code ? 'bg-[#00FF9C]/10' : 'hover:bg-white/[0.025]'}`}><td className="py-2.5 pr-3 font-mono font-bold text-white">{bin.bin_code}</td><td className="py-2.5 pr-3 text-neutral-300">{bin.bin_name}</td><td className="py-2.5 text-right font-mono text-white">{bin.count.toLocaleString()}</td><td className="py-2.5 text-right font-mono text-[#FF5A52]">{metric(bin.percent_of_fails)}%</td><td className="py-2.5 text-right font-mono text-[#FFAE00]">{metric(bin.cumulative_percent)}%</td><td className="py-2.5 text-right"><button type="button" onClick={() => onFilterBin(selectedBin === bin.bin_code ? null : bin.bin_code)} className="rounded border border-neutral-700 px-2 py-1 text-[10px] text-neutral-300 hover:border-[#00FF9C] hover:text-[#00FF9C]">{selectedBin === bin.bin_code ? 'Active' : 'Highlight'}</button></td></tr>)}</tbody></table></div></div></Section></div>;
}

function KillRatioPanel({ analysis, onOpenIngestion }: { analysis: IngestionAnalysisResponse; onOpenIngestion: () => void }) {
  if (!analysis.kla.available) return <EmptyAnalysis title="Add a matching KLA source" detail="Coordinate screening requires a persisted KLA defect source with the same LOT_ID and WAFER_ID as the active CP source. The result is direct DIE_X/DIE_Y overlap, not proof of a causal mechanism." action="Ingest KLA data" onAction={onOpenIngestion} />;
  return <div className="space-y-5"><div className="grid gap-3 sm:grid-cols-3"><Kpi label="Imported KLA defects" value={analysis.kla.total_defects.toLocaleString()} detail={`Dataset #${analysis.kla.dataset?.id ?? '—'}`} tone="bad" /><Kpi label="Repeater records" value={analysis.kla.repeater_defects.toLocaleString()} detail="Flags retained from source records" tone="cyan" /><Kpi label="Screened defect classes" value={analysis.kla.correlations.length.toLocaleString()} detail="Compared with CP DIE_X/DIE_Y coordinates" /></div><Section title="KLA-to-CP coordinate-overlap screening" detail="CP failure overlap counts unique CP dies whose imported DIE_X/DIE_Y equals an affected KLA die coordinate. Defect events are not counted as dies, and overlap does not assign root cause." icon={ShieldAlert}>{analysis.kla.correlations.length ? <div className="overflow-x-auto"><table className="w-full text-left text-xs"><thead className="bg-[#151515] font-mono text-[10px] uppercase text-neutral-500"><tr><th className="px-4 py-3">Defect class</th><th className="px-4 py-3 text-right">Defect events</th><th className="px-4 py-3 text-right">Distinct affected dies</th><th className="px-4 py-3 text-right">Matched CP dies</th><th className="px-4 py-3 text-right">CP failure overlap</th><th className="px-4 py-3 text-right">Failure overlap rate</th><th className="px-4 py-3 text-right">Repeaters</th></tr></thead><tbody>{analysis.kla.correlations.map((item) => <tr key={item.defect_class} className="border-t border-[#242424] text-neutral-300"><td className="px-4 py-3 font-medium text-white">{item.defect_class}</td><td className="px-4 py-3 text-right font-mono">{item.total_defects.toLocaleString()}</td><td className="px-4 py-3 text-right font-mono">{item.distinct_affected_dies.toLocaleString()}</td><td className="px-4 py-3 text-right font-mono">{item.matched_cp_dies.toLocaleString()}</td><td className="px-4 py-3 text-right font-mono text-[#FF5A52]">{item.killed_dies.toLocaleString()}</td><td className="px-4 py-3 text-right font-mono text-[#FFAE00]">{metric(item.kill_ratio_pct)}%</td><td className="px-4 py-3 text-right font-mono text-[#00E5FF]">{item.repeater_defects.toLocaleString()}</td></tr>)}</tbody></table></div> : <p className="p-5 text-xs text-neutral-500">The selected KLA source contains no defect-class rows to screen.</p>}</Section></div>;
}

function SpatialPanel({ analysis }: { analysis: IngestionAnalysisResponse }) {
  const spatial = analysis.cp.spatial;
  return <div className="space-y-5"><div className="grid gap-3 sm:grid-cols-4"><Kpi label="Failure components" value={spatial.failure_components.component_count.toLocaleString()} detail="8-neighbor die-coordinate grouping" tone="cyan" /><Kpi label="Multi-die clusters" value={spatial.failure_components.cluster_count.toLocaleString()} detail="Components with ≥2 failed dies" tone="amber" /><Kpi label="Clustered failed dies" value={spatial.failure_components.clustered_failure_dies.toLocaleString()} detail="Failed coordinates in multi-die components" tone="bad" /><Kpi label="Isolated failed dies" value={spatial.failure_components.isolated_failure_dies.toLocaleString()} detail="Single-coordinate components" /></div><Section title="Spatial screening & radial zones" detail={spatial.coordinate_note} icon={Crosshair}><div className="grid gap-5 p-4 sm:grid-cols-2 sm:p-5"><div className="overflow-x-auto"><table className="w-full text-left text-xs"><thead className="border-b border-[#2b2b2b] font-mono text-[10px] uppercase text-neutral-500"><tr><th className="pb-2">Zone</th><th className="pb-2 text-right">Dies</th><th className="pb-2 text-right">Pass</th><th className="pb-2 text-right">Fail</th><th className="pb-2 text-right">Yield</th></tr></thead><tbody>{spatial.radial_zones.map((zone) => <tr key={zone.zone} className="border-b border-[#202020]"><td className="py-3 text-neutral-200">{zone.zone}</td><td className="py-3 text-right font-mono">{zone.total_dies.toLocaleString()}</td><td className="py-3 text-right font-mono text-[#00FF9C]">{zone.pass_dies.toLocaleString()}</td><td className="py-3 text-right font-mono text-[#FF5A52]">{zone.fail_dies.toLocaleString()}</td><td className="py-3 text-right font-mono text-[#00E5FF]">{metric(zone.yield_pct)}%</td></tr>)}</tbody></table></div><div><h4 className="mb-3 text-xs font-bold uppercase tracking-wider text-white">Largest connected failure components</h4>{spatial.failure_components.top_clusters.length ? <div className="space-y-2">{spatial.failure_components.top_clusters.map((cluster, index) => <div key={`${cluster.die_x_min}-${cluster.die_y_min}-${cluster.dominant_bin}`} className="rounded-lg border border-[#2a2a2a] bg-[#0d0d0d] p-3"><div className="flex items-center justify-between"><span className="font-mono text-xs font-bold text-white">Component {index + 1}</span><span className="font-mono text-xs text-[#FF5A52]">{cluster.die_count} dies</span></div><div className="mt-1 text-[11px] text-neutral-400">Dominant bin {cluster.dominant_bin}: {cluster.dominant_bin_name}</div><div className="mt-2 font-mono text-[10px] text-[#00E5FF]">X {cluster.die_x_min}…{cluster.die_x_max} · Y {cluster.die_y_min}…{cluster.die_y_max}</div></div>)}</div> : <p className="rounded-lg border border-dashed border-[#303030] p-4 text-xs text-neutral-500">No multi-die connected failure component was found in the active CP source.</p>}</div></div></Section></div>;
}

function OcapPanel({ analysis }: { analysis: IngestionAnalysisResponse }) {
  const tone = analysis.ocap.status === 'ATTENTION' ? 'bad' : analysis.ocap.status === 'REVIEW' ? 'amber' : 'good';
  return <div className="space-y-5"><div className="grid gap-3 sm:grid-cols-3"><Kpi label="OCAP triage status" value={analysis.ocap.status} detail="Decision-support screening state" tone={tone} /><Kpi label="Evidence streams" value={analysis.ocap.evidence.length.toLocaleString()} detail="Retained CP/WAT/KLA aggregates" tone="cyan" /><Kpi label="Recommended reviews" value={analysis.ocap.recommendations.length.toLocaleString()} detail="No process actions are auto-issued" /></div><Section title="Observed-condition action plan" detail={analysis.ocap.scope_note} icon={ClipboardList}><div className="grid gap-4 p-4 lg:grid-cols-[1.05fr_0.95fr] sm:p-5"><div className="space-y-3">{analysis.ocap.evidence.length ? analysis.ocap.evidence.map((item) => <div key={`${item.category}-${item.label}`} className="rounded-lg border border-[#2d2d2d] bg-[#0c0c0c] p-4"><div className="flex items-center justify-between gap-3"><span className="rounded border border-[#00E5FF]/30 bg-[#00E5FF]/10 px-2 py-0.5 font-mono text-[10px] font-bold text-[#00E5FF]">{item.category}</span><span className="font-mono text-xs text-[#FFAE00]">{item.value}</span></div><div className="mt-2 text-sm font-bold text-white">{item.label}</div><div className="mt-1 text-xs leading-relaxed text-neutral-400">{item.detail}</div></div>) : <p className="text-xs text-neutral-500">No evidence streams require review.</p>}</div><div className="rounded-xl border border-[#00FF9C]/25 bg-[#00FF9C]/[0.04] p-4"><h4 className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#00FF9C]"><CheckCircle2 className="h-4 w-4" />Review actions</h4><ol className="mt-3 space-y-3">{analysis.ocap.recommendations.map((recommendation, index) => <li key={recommendation} className="flex gap-3 text-xs leading-relaxed text-neutral-300"><span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full border border-[#00FF9C]/40 font-mono text-[10px] text-[#00FF9C]">{index + 1}</span><span>{recommendation}</span></li>)}</ol></div></div></Section></div>;
}

function ProcessPanel({ analysis, onOpenIngestion }: { analysis: IngestionAnalysisResponse; onOpenIngestion: () => void }) {
  return <div className="space-y-5"><div className="grid gap-3 sm:grid-cols-3"><Kpi label="CP parameter groups" value={analysis.cp.parametrics.length.toLocaleString()} detail="Grouped by persisted parameter and unit" tone="cyan" /><Kpi label="WAT source" value={analysis.wat.available ? 'Matched' : 'Not loaded'} detail={analysis.wat.available ? 'LOT_ID and WAFER_ID identities match' : 'Optional for capability statistics'} tone={analysis.wat.available ? 'good' : 'amber'} /><Kpi label="Inferred limits" value="Disabled" detail="CP capability is never inferred without imported specs" /></div><Section title="CP measured process window" detail="Descriptive CP statistics are calculated from non-null Test_Value records. Limits, Cp, and Cpk are not fabricated for CP measurements." icon={SlidersHorizontal}><ParametricTable parametrics={analysis.cp.parametrics} onOpenIngestion={onOpenIngestion} /></Section>{analysis.wat.available ? <Section title="WAT specification capability" detail="Cp and Cpk appear only where imported WAT limits and measured variation are available." icon={FlaskConical}><div className="overflow-x-auto"><table className="w-full text-left text-xs"><thead className="bg-[#151515] font-mono text-[10px] uppercase text-neutral-500"><tr><th className="px-4 py-3">Parameter</th><th className="px-4 py-3 text-right">N</th><th className="px-4 py-3 text-right">Mean</th><th className="px-4 py-3 text-right">σ</th><th className="px-4 py-3 text-right">LSL / USL</th><th className="px-4 py-3 text-right">Cp</th><th className="px-4 py-3 text-right">Cpk</th><th className="px-4 py-3 text-right">Fail</th></tr></thead><tbody>{analysis.wat.parameters.map((parameter) => <tr key={`${parameter.param_name}-${parameter.unit}`} className="border-t border-[#242424] text-neutral-300"><td className="px-4 py-3"><div className="font-medium text-white">{parameter.param_name}</div><div className="font-mono text-[10px] text-neutral-500">{parameter.unit || 'unit unavailable'}</div></td><td className="px-4 py-3 text-right font-mono">{parameter.count.toLocaleString()}</td><td className="px-4 py-3 text-right font-mono">{metric(parameter.mean, 4)}</td><td className="px-4 py-3 text-right font-mono">{metric(parameter.std_dev, 4)}</td><td className="px-4 py-3 text-right font-mono">{metric(parameter.spec_low, 4)} / {metric(parameter.spec_high, 4)}</td><td className="px-4 py-3 text-right font-mono text-[#00E5FF]">{metric(parameter.cp)}</td><td className="px-4 py-3 text-right font-mono text-[#00FF9C]">{metric(parameter.cpk)}</td><td className={`px-4 py-3 text-right font-mono ${parameter.fail_count ? 'text-[#FF5A52]' : 'text-neutral-400'}`}>{parameter.fail_count.toLocaleString()}</td></tr>)}</tbody></table></div></Section> : <EmptyAnalysis title="Add matching WAT capability data" detail="Load a WAT dataset for the same LOT_ID and WAFER_ID to calculate specification coverage, Cp, and Cpk from actual metrology values." action="Ingest WAT data" onAction={onOpenIngestion} />}</div>;
}

function ParametricTable({ parametrics, onOpenIngestion }: { parametrics: IngestionAnalysisResponse['cp']['parametrics']; onOpenIngestion: () => void }) {
  if (!parametrics.length) return <EmptyAnalysis title="No CP parametric values are available" detail="The active source contains bin results but no Test_Value / parameter records. Upload CP data with parameter-name, value, and unit columns to view measured statistics." action="Ingest CP data" onAction={onOpenIngestion} />;
  return <div className="overflow-x-auto"><table className="w-full text-left text-xs"><thead className="bg-[#151515] font-mono text-[10px] uppercase text-neutral-500"><tr><th className="px-4 py-3">Parameter</th><th className="px-4 py-3 text-right">N</th><th className="px-4 py-3 text-right">Mean</th><th className="px-4 py-3 text-right">σ</th><th className="px-4 py-3 text-right">Min</th><th className="px-4 py-3 text-right">Max</th></tr></thead><tbody>{parametrics.map((item) => <tr key={`${item.param_name}-${item.param_unit}`} className="border-t border-[#242424] text-neutral-300"><td className="px-4 py-3"><div className="font-medium text-white">{item.param_name}</div><div className="font-mono text-[10px] text-neutral-500">{item.param_unit || 'unit unavailable'}</div></td><td className="px-4 py-3 text-right font-mono">{item.measured_rows.toLocaleString()}</td><td className="px-4 py-3 text-right font-mono text-[#00E5FF]">{metric(item.mean, 6)}</td><td className="px-4 py-3 text-right font-mono">{metric(item.std_dev, 6)}</td><td className="px-4 py-3 text-right font-mono">{metric(item.min, 6)}</td><td className="px-4 py-3 text-right font-mono">{metric(item.max, 6)}</td></tr>)}</tbody></table></div>;
}

function TelemetryPanel({ analysis }: { analysis: IngestionAnalysisResponse }) {
  return <div className="space-y-5"><div className="grid gap-3 sm:grid-cols-3"><Kpi label="Source telemetry fields" value={analysis.cp.telemetry.filter((item) => item.measured_rows > 0).length.toLocaleString()} detail="Frequency and leakage if present in CP source" tone="cyan" /><Kpi label="Tester telemetry" value="Not provided" detail="No tester, site, probe-card, or tool data is inferred" tone="amber" /><Kpi label="Trace state" value="Source-bound" detail="Statistics retain the CP dataset identity" tone="good" /></div><Section title="Imported CP test signals" detail="Only scalar Test_Frequency_GHz and Leakage_uA columns that are actually present in the CP source are summarized here. Hardware health requires explicit test-equipment telemetry." icon={RadioTower}><div className="grid gap-4 p-4 sm:grid-cols-2 sm:p-5">{analysis.cp.telemetry.map((item) => <div key={item.name} className="rounded-xl border border-[#2a2a2a] bg-[#0c0c0c] p-4"><div className="flex items-center justify-between"><h4 className="text-sm font-bold text-white">{item.name}</h4><span className="font-mono text-xs text-[#00E5FF]">{item.unit}</span></div>{item.measured_rows ? <><div className="mt-4 grid grid-cols-2 gap-3"><MetricCell label="Measured rows" value={item.measured_rows.toLocaleString()} /><MetricCell label="Mean" value={metric(item.mean, 5)} /><MetricCell label="σ" value={metric(item.std_dev, 5)} /><MetricCell label="Range" value={`${metric(item.min, 4)} – ${metric(item.max, 4)}`} /></div></> : <p className="mt-4 text-xs leading-relaxed text-neutral-500">This CP source does not contain a valid {item.name.toLowerCase()} field.</p>}</div>)}</div></Section></div>;
}

function MetricCell({ label, value }: { label: string; value: string }) {
  return <div><div className="font-mono text-[9px] uppercase tracking-wider text-neutral-500">{label}</div><div className="mt-1 font-mono text-sm text-white">{value}</div></div>;
}

function ObservedScenarioPanel({ analysis }: { analysis: IngestionAnalysisResponse }) {
  const baseline = analysis.cp.observed_edge_scenarios.find((scenario) => scenario.edge_exclusion_mm === 3) ?? analysis.cp.observed_edge_scenarios[0];
  return <div className="space-y-5"><div className="grid gap-3 sm:grid-cols-3"><Kpi label="Baseline source view" value={`${baseline?.edge_exclusion_mm ?? '—'} mm`} detail="Observed die inclusion at selected radial cutoff" tone="cyan" /><Kpi label="No yield recovery model" value="Disabled" detail="The studio does not predict repair, reprobe, guardband, or profit outcomes" tone="amber" /><Kpi label="Scenario rows" value={analysis.cp.observed_edge_scenarios.length.toLocaleString()} detail="Recomputed from imported CP coordinates" /></div><Section title="Observed edge-exclusion scenarios" detail="This is a sensitivity view over real imported die coordinates. Each row recomputes observed yield after excluding coordinates beyond 150 mm minus the stated edge exclusion. It is not a simulated yield forecast." icon={Activity}><div className="overflow-x-auto"><table className="w-full text-left text-xs"><thead className="bg-[#151515] font-mono text-[10px] uppercase text-neutral-500"><tr><th className="px-4 py-3">Edge exclusion</th><th className="px-4 py-3 text-right">Included dies</th><th className="px-4 py-3 text-right">Excluded dies</th><th className="px-4 py-3 text-right">Pass</th><th className="px-4 py-3 text-right">Fail</th><th className="px-4 py-3 text-right">Observed yield</th></tr></thead><tbody>{analysis.cp.observed_edge_scenarios.map((scenario) => <tr key={scenario.edge_exclusion_mm} className={`border-t border-[#242424] ${scenario.edge_exclusion_mm === baseline?.edge_exclusion_mm ? 'bg-[#00FF9C]/[0.06]' : ''}`}><td className="px-4 py-3 font-mono font-bold text-white">{scenario.edge_exclusion_mm} mm {scenario.edge_exclusion_mm === baseline?.edge_exclusion_mm && <span className="ml-2 text-[10px] text-[#00FF9C]">baseline</span>}</td><td className="px-4 py-3 text-right font-mono">{scenario.included_dies.toLocaleString()}</td><td className="px-4 py-3 text-right font-mono text-neutral-400">{scenario.excluded_dies.toLocaleString()}</td><td className="px-4 py-3 text-right font-mono text-[#00FF9C]">{scenario.pass_dies.toLocaleString()}</td><td className="px-4 py-3 text-right font-mono text-[#FF5A52]">{scenario.fail_dies.toLocaleString()}</td><td className="px-4 py-3 text-right font-mono text-[#00E5FF]">{metric(scenario.yield_pct)}%</td></tr>)}</tbody></table></div></Section></div>;
}

function CrossDomainPanel({ analysis, onOpenIngestion }: { analysis: IngestionAnalysisResponse; onOpenIngestion: () => void }) {
  if (!analysis.wat.available && !analysis.kla.available) return <EmptyAnalysis title="Add WAT or KLA evidence" detail="Select matching WAT and/or KLA sources to extend CP analysis with retained metrology capability and coordinate-overlap information." action="Ingest supporting data" onAction={onOpenIngestion} />;
  const caveats = analysis.correlation_caveats ?? [];
  const reasons = analysis.correlation_reasons ?? [];
  return <div className="space-y-5"><div className="grid gap-3 sm:grid-cols-3"><Kpi label="WAT source" value={analysis.wat.available ? 'Loaded' : 'Not loaded'} detail={analysis.wat.available ? `${analysis.wat.coordinate_coverage.matched_die_count.toLocaleString()} direct CP die matches` : 'Optional'} tone={analysis.wat.available ? 'cyan' : 'neutral'} /><Kpi label="KLA source" value={analysis.kla.available ? 'Loaded' : 'Not loaded'} detail={analysis.kla.available ? `${analysis.kla.coordinate_coverage.matched_die_count.toLocaleString()} direct CP die matches` : 'Optional'} tone={analysis.kla.available ? 'bad' : 'neutral'} /><Kpi label="Screening readiness" value={analysis.correlation_ready ? 'Ready' : 'Not ready'} detail="Same LOT_ID/WAFER_ID plus direct DIE_X/DIE_Y overlap" tone={analysis.correlation_ready ? 'good' : 'amber'} /></div><div className="rounded-xl border border-[#FFAE00]/35 bg-[#FFAE00]/[0.06] p-4 text-xs leading-relaxed text-neutral-300"><div className="flex items-center gap-2 font-bold uppercase tracking-wider text-[#FFAE00]"><AlertTriangle className="h-4 w-4" />Coordinate-screening boundary</div>{reasons.map((reason) => <p key={reason} className="mt-2">{reason}</p>)}{caveats.map((caveat) => <p key={caveat} className="mt-2">{caveat}</p>)}</div>{analysis.wat.available && <Section title="WAT-to-CP coordinate-overlap screening" detail="Each parameter counts a CP die once per unique matched DIE_X/DIE_Y. WAT rows without a CP coordinate are excluded from pass/fail rates and shown as unmatched coverage." icon={FlaskConical}>{analysis.wat.coordinate_screening.length ? <div className="overflow-x-auto"><table className="w-full text-left text-xs"><thead className="bg-[#151515] font-mono text-[10px] uppercase text-neutral-500"><tr><th className="px-4 py-3">Parameter</th><th className="px-4 py-3 text-right">Mean</th><th className="px-4 py-3 text-right">Matched / source dies</th><th className="px-4 py-3 text-right">Unmatched</th><th className="px-4 py-3 text-right">CP fail dies</th><th className="px-4 py-3 text-right">CP failure rate</th><th className="px-4 py-3 text-right">OOS rows</th><th className="px-4 py-3">Bounded indicator</th></tr></thead><tbody>{analysis.wat.coordinate_screening.map((item) => <tr key={`${item.param_name}-${item.unit}`} className="border-t border-[#242424] text-neutral-300"><td className="px-4 py-3"><div className="font-medium text-white">{item.param_name}</div><div className="font-mono text-[10px] text-neutral-500">{item.unit || 'unit unavailable'} · {item.measurement_count.toLocaleString()} rows</div></td><td className="px-4 py-3 text-right font-mono text-[#00E5FF]">{metric(item.mean_wat_value, 6)}</td><td className="px-4 py-3 text-right font-mono">{item.matched_die_count.toLocaleString()} / {item.source_die_count.toLocaleString()} <span className="text-neutral-500">({metric(item.coordinate_coverage_pct)}%)</span></td><td className="px-4 py-3 text-right font-mono text-neutral-400">{item.unmatched_die_count.toLocaleString()}</td><td className="px-4 py-3 text-right font-mono text-[#FF5A52]">{item.cp_fail_die_count.toLocaleString()}</td><td className="px-4 py-3 text-right font-mono text-[#FFAE00]">{metric(item.cp_failure_rate_pct)}%</td><td className="px-4 py-3 text-right font-mono">{item.oos_measurement_count.toLocaleString()}</td><td className="px-4 py-3 font-mono text-[10px] text-neutral-400">{item.screening_indicator.replaceAll('_', ' ')}</td></tr>)}</tbody></table></div> : <p className="p-5 text-xs text-neutral-500">The selected WAT source contains no parameter rows to screen.</p>}</Section>}{analysis.kla.available && <Section title="KLA class coordinate-overlap screening" detail="Defect events and distinct affected dies remain separate. CP failure overlap counts unique matched CP die coordinates, not defect records." icon={Microscope}>{analysis.kla.correlations.length ? <div className="overflow-x-auto"><table className="w-full text-left text-xs"><thead className="bg-[#151515] font-mono text-[10px] uppercase text-neutral-500"><tr><th className="px-4 py-3">Defect class</th><th className="px-4 py-3 text-right">Events</th><th className="px-4 py-3 text-right">Affected dies</th><th className="px-4 py-3 text-right">Matched CP dies</th><th className="px-4 py-3 text-right">CP failure overlap</th><th className="px-4 py-3 text-right">Failure overlap rate</th></tr></thead><tbody>{analysis.kla.correlations.map((item) => <tr key={item.defect_class} className="border-t border-[#242424]"><td className="px-4 py-3 font-medium text-white">{item.defect_class}</td><td className="px-4 py-3 text-right font-mono text-neutral-300">{item.total_defects.toLocaleString()}</td><td className="px-4 py-3 text-right font-mono text-neutral-300">{item.distinct_affected_dies.toLocaleString()}</td><td className="px-4 py-3 text-right font-mono text-neutral-300">{item.matched_cp_dies.toLocaleString()}</td><td className="px-4 py-3 text-right font-mono text-[#FF5A52]">{item.killed_dies.toLocaleString()}</td><td className="px-4 py-3 text-right font-mono text-[#FFAE00]">{metric(item.kill_ratio_pct)}%</td></tr>)}</tbody></table></div> : <p className="p-5 text-xs text-neutral-500">The selected KLA source contains no defect-class rows to screen.</p>}</Section>}</div>;
}

function LineagePanel({ activeDatasets, onOpenLibrary }: { activeDatasets: Partial<Record<IngestedDataType, IngestedWaferData>>; onOpenLibrary: () => void }) {
  return <div className="space-y-5"><Section title="Active persisted source lineage" detail="Each active source retains normalized measurements, original source-file reference, validation counts, and import-run audit linkage. Analysis aggregates are calculated server-side." icon={Layers}><div className="grid gap-3 p-4 md:grid-cols-3 sm:p-5">{(['CP', 'WAT', 'KLA'] as IngestedDataType[]).map((sourceType) => { const data = activeDatasets[sourceType]; return <div key={sourceType} className={`rounded-lg border p-4 ${data ? 'border-[#333] bg-[#161616]' : 'border-dashed border-[#2a2a2a] bg-[#111]'}`}><div className="flex items-center justify-between"><span className="font-mono text-xs font-bold text-white">{sourceType}</span>{data ? <CheckCircle2 className="h-4 w-4 text-[#00FF9C]" /> : <span className="text-[10px] text-neutral-600">not loaded</span>}</div>{data && <><div className="mt-3 font-mono text-[10px] text-neutral-500">Dataset #{data.dataset.dataset_id}</div><div className="mt-1 truncate text-xs text-neutral-300" title={data.dataset.summary.source_filename}>{data.dataset.summary.source_filename}</div><div className="mt-3 text-[11px] text-neutral-400">{data.dataset.summary.valid_rows.toLocaleString()} validated rows · {data.dataset.summary.error_rows.toLocaleString()} rejected rows</div><div className="mt-2 font-mono text-[10px] text-[#00E5FF]">{data.dataset.summary.product_name}</div><div className="mt-1 font-mono text-[10px] text-neutral-500">{data.dataset.summary.lot_id} / {data.dataset.summary.wafer_id}</div></>}</div>; })}</div><div className="border-t border-[#242424] p-4 sm:px-5"><button type="button" onClick={onOpenLibrary} className="flex items-center gap-2 rounded-lg border border-[#00E5FF]/50 bg-[#00E5FF]/10 px-4 py-2 text-xs font-bold text-[#00E5FF] hover:bg-[#00E5FF]/20"><Database className="h-4 w-4" />Manage retained datasets</button></div></Section></div>;
}

function EmptyAnalysis({ title, detail, action, onAction }: { title: string; detail: string; action: string; onAction: () => void }) {
  return <div className="flex min-h-72 flex-col items-center justify-center rounded-xl border border-dashed border-[#353535] bg-[#121212] p-8 text-center"><Activity className="mb-3 h-8 w-8 text-neutral-600" /><h3 className="text-base font-bold text-white">{title}</h3><p className="mt-2 max-w-xl text-xs leading-relaxed text-neutral-400">{detail}</p><button type="button" onClick={onAction} className="mt-5 flex items-center gap-2 rounded-lg bg-[#00FF9C] px-4 py-2 text-xs font-bold text-black transition-colors hover:bg-[#00e58c]"><Upload className="h-4 w-4" />{action}</button></div>;
}

function JsonPreview({ report, onClose, onDownload }: { report: unknown; onClose: () => void; onDownload: () => void }) {
  return <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/85 p-5 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label="CP and YMS local session JSON preview"><section className="flex max-h-[88vh] w-full max-w-5xl flex-col overflow-hidden rounded-xl border border-[#303030] bg-[#101010] shadow-2xl"><header className="flex items-center justify-between border-b border-[#252525] px-5 py-3"><div><h3 className="flex items-center gap-2 text-sm font-bold text-white"><FileJson className="h-4 w-4 text-[#00E5FF]" />CP &amp; YMS local session preview</h3><p className="mt-0.5 text-[11px] text-neutral-500">Local JSON preview from the current source-backed aggregate response; it is not an official historical report.</p></div><button type="button" onClick={onClose} className="rounded p-1.5 text-neutral-400 hover:bg-neutral-800 hover:text-white" aria-label="Close local session preview"><X className="h-4 w-4" /></button></header><pre className="flex-1 overflow-auto bg-[#080808] p-5 font-mono text-[11px] leading-relaxed text-[#b7d9d1]">{JSON.stringify(report, null, 2)}</pre><footer className="flex justify-end gap-2 border-t border-[#252525] p-3"><button type="button" onClick={onClose} className="rounded border border-[#3a3a3a] px-3 py-2 text-xs text-neutral-300 hover:bg-neutral-800">Close</button><button type="button" onClick={onDownload} className="flex items-center gap-1.5 rounded border border-[#00E5FF]/45 bg-[#00E5FF]/10 px-3 py-2 text-xs font-bold text-[#00E5FF] hover:bg-[#00E5FF]/20"><CloudDownload className="h-3.5 w-3.5" />Download local preview</button></footer></section></div>;
}
