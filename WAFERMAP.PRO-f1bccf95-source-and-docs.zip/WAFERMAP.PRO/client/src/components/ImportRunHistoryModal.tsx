import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { AlertTriangle, CheckCircle2, Clock3, Database, FileArchive, FolderOpen, History, Loader2, RefreshCw, Upload, X } from 'lucide-react';
import {
  CpDieRecord,
  IngestedDataType,
  IngestedWaferData,
  IngestionDatasetResult,
  IngestionDatasetSummary,
  KlaDefectItem,
  PersistedImportRun,
  WatMeasurementItem,
} from '../types';

interface OverlayPayload {
  dataset: {
    id: number;
    source_type: IngestedDataType;
    wafer_id: string;
    lot_id: string;
    product_id: string;
    summary: IngestionDatasetSummary;
  };
  records?: unknown[];
  columns?: string[];
  rows?: unknown[][];
}

interface ImportRunHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenIngestion: () => void;
  onApply: (data: IngestedWaferData) => void;
}

const SOURCE_COLORS: Record<IngestedDataType, string> = {
  CP: '#00FF9C',
  WAT: '#00E5FF',
  KLA: '#FF5A52',
};

function asSourceType(value: unknown): IngestedDataType | null {
  return value === 'CP' || value === 'WAT' || value === 'KLA' ? value : null;
}

function formatTimestamp(value: string | null | undefined): string {
  if (!value) return 'Timestamp unavailable';
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? value : parsed.toLocaleString();
}

function formatBytes(value: number | undefined): string {
  if (!Number.isFinite(value) || !value || value < 0) return '—';
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KiB`;
  return `${(value / (1024 * 1024)).toFixed(1)} MiB`;
}

function unpackRecords(payload: OverlayPayload): Record<string, unknown>[] {
  if (Array.isArray(payload.records)) return payload.records as Record<string, unknown>[];
  if (!Array.isArray(payload.columns) || !Array.isArray(payload.rows)) return [];
  return payload.rows.map(row => Object.fromEntries(payload.columns!.map((column, index) => [column, row[index]])));
}

function normalizeRun(value: unknown): PersistedImportRun | null {
  if (!value || typeof value !== 'object') return null;
  const item = value as Record<string, unknown>;
  const sourceType = asSourceType(item.source_type);
  if (!sourceType || !Number.isInteger(Number(item.id)) || typeof item.status !== 'string' || typeof item.original_filename !== 'string') return null;
  const status = item.status === 'COMPLETED' || item.status === 'REJECTED' || item.status === 'PROCESSING' ? item.status : null;
  if (!status) return null;
  const rawDataset = item.dataset && typeof item.dataset === 'object' ? item.dataset as Record<string, unknown> : null;
  const dataset = rawDataset && Number.isInteger(Number(rawDataset.id)) ? {
    id: Number(rawDataset.id),
    lot_id: typeof rawDataset.lot_id === 'string' ? rawDataset.lot_id : null,
    wafer_id: typeof rawDataset.wafer_id === 'string' ? rawDataset.wafer_id : null,
    product_id: typeof rawDataset.product_id === 'string' ? rawDataset.product_id : null,
    total_rows: Number(rawDataset.total_rows || 0),
    valid_rows: Number(rawDataset.valid_rows || 0),
    error_rows: Number(rawDataset.error_rows || 0),
    byte_size: Number(rawDataset.byte_size || 0),
  } : null;
  const rawPartition = item.selected_partition && typeof item.selected_partition === 'object' ? item.selected_partition as Record<string, unknown> : null;
  const selectedPartition = rawPartition && typeof rawPartition.lot_id === 'string' && typeof rawPartition.wafer_id === 'string'
    ? { lot_id: rawPartition.lot_id, wafer_id: rawPartition.wafer_id }
    : null;
  const rawCounts = item.counts && typeof item.counts === 'object' ? item.counts as Record<string, unknown> : {};
  const diagnosticCodes = Array.isArray(item.diagnostic_codes)
    ? item.diagnostic_codes.filter(code => code && typeof code === 'object').slice(0, 10).map(code => {
      const value = code as Record<string, unknown>;
      return {
        ...(typeof value.code === 'string' ? { code: value.code } : {}),
        ...(typeof value.role === 'string' ? { role: value.role } : {}),
        ...(typeof value.severity === 'string' ? { severity: value.severity } : {}),
      };
    })
    : [];
  return {
    id: Number(item.id),
    source_type: sourceType,
    status,
    original_filename: item.original_filename,
    source_hash: typeof item.source_hash === 'string' ? item.source_hash : '',
    started_at: typeof item.started_at === 'string' ? item.started_at : null,
    completed_at: typeof item.completed_at === 'string' ? item.completed_at : null,
    operation: typeof item.operation === 'string' ? item.operation : 'SOURCE_IMPORT',
    selected_partition: selectedPartition,
    source_roles: Array.isArray(item.source_roles) ? item.source_roles.filter((role): role is string => typeof role === 'string').slice(0, 12) : [],
    counts: {
      ...(Number.isFinite(Number(rawCounts.valid_rows)) ? { valid_rows: Number(rawCounts.valid_rows) } : {}),
      ...(Number.isFinite(Number(rawCounts.error_rows)) ? { error_rows: Number(rawCounts.error_rows) } : {}),
      ...(Number.isFinite(Number(rawCounts.total_rows)) ? { total_rows: Number(rawCounts.total_rows) } : {}),
      ...(Number.isFinite(Number(rawCounts.source_package_partition_count)) ? { source_package_partition_count: Number(rawCounts.source_package_partition_count) } : {}),
    },
    diagnostic_codes: diagnosticCodes,
    error_type: typeof item.error_type === 'string' && item.error_type ? item.error_type : null,
    has_error: item.has_error === true,
    dataset,
  };
}

export function ImportRunHistoryModal({ isOpen, onClose, onOpenIngestion, onApply }: ImportRunHistoryModalProps) {
  const [runs, setRuns] = useState<PersistedImportRun[]>([]);
  const [loading, setLoading] = useState(false);
  const [openingDatasetId, setOpeningDatasetId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  const loadHistory = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/ingestion/import-runs?limit=50', { credentials: 'same-origin' });
      const body: unknown = await response.json().catch(() => null);
      if (!response.ok) {
        const message = body && typeof body === 'object' && typeof (body as { message?: unknown }).message === 'string'
          ? (body as { message: string }).message
          : 'The authenticated import history is unavailable.';
        throw new Error(message);
      }
      const rawRuns = body && typeof body === 'object' && Array.isArray((body as { import_runs?: unknown }).import_runs)
        ? (body as { import_runs: unknown[] }).import_runs
        : [];
      setRuns(rawRuns.map(normalizeRun).filter((run): run is PersistedImportRun => run !== null));
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Unable to load import history.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (isOpen) void loadHistory();
  }, [isOpen, loadHistory]);

  const completed = useMemo(() => runs.filter(run => run.status === 'COMPLETED').length, [runs]);
  const rejected = useMemo(() => runs.filter(run => run.status === 'REJECTED').length, [runs]);

  const reopenDataset = async (run: PersistedImportRun) => {
    if (!run.dataset) return;
    setOpeningDatasetId(run.dataset.id);
    setError(null);
    try {
      const response = await fetch(`/api/ingestion/datasets/${run.dataset.id}/overlay`, { credentials: 'same-origin' });
      const payload = await response.json() as OverlayPayload & { message?: string };
      if (!response.ok) throw new Error(payload.message || 'The retained dataset could not be reopened.');
      const sourceType = asSourceType(payload.dataset?.source_type);
      if (!sourceType || !payload.dataset?.summary) throw new Error('The retained dataset returned an unsupported overlay shape.');
      const dataset: IngestionDatasetResult = { dataset_id: Number(payload.dataset.id), source_type: sourceType, summary: payload.dataset.summary };
      const records = unpackRecords(payload);
      onApply({
        dataset,
        ...(sourceType === 'CP' ? { cpRecords: records as unknown as CpDieRecord[] } : {}),
        ...(sourceType === 'WAT' ? { watRecords: records as unknown as WatMeasurementItem[] } : {}),
        ...(sourceType === 'KLA' ? { klaRecords: records as unknown as KlaDefectItem[] } : {}),
      });
      onClose();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Unable to reopen this retained dataset.');
    } finally {
      setOpeningDatasetId(null);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-3 backdrop-blur-md sm:p-6" role="dialog" aria-modal="true" aria-label="Authenticated import history">
      <section className="flex max-h-[94vh] w-full max-w-6xl flex-col overflow-hidden rounded-xl border border-[#252525] bg-[#0e0e0e] text-[#ddd] shadow-2xl">
        <header className="flex items-center justify-between border-b border-[#242424] bg-[#141414] px-5 py-4 sm:px-6">
          <div className="flex min-w-0 items-center gap-3">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-[#00E5FF]/30 bg-[#00E5FF]/10 text-[#00E5FF]"><History className="h-5 w-5" /></div>
            <div className="min-w-0"><h2 className="text-base font-bold tracking-wide text-white sm:text-lg">OWNER-SCOPED IMPORT HISTORY</h2><p className="mt-0.5 text-xs text-neutral-400">Review safe package outcomes and reopen completed retained datasets without uploading again.</p></div>
          </div>
          <button type="button" onClick={onClose} className="rounded-lg p-2 text-neutral-400 transition-colors hover:bg-neutral-800 hover:text-white" aria-label="Close import history"><X className="h-5 w-5" /></button>
        </header>

        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#242424] bg-[#111] px-5 py-3 sm:px-6">
          <div className="flex items-center gap-3 font-mono text-[10px] uppercase"><span className="text-neutral-500">{runs.length} recorded</span><span className="text-[#00FF9C]">{completed} completed</span><span className="text-red-300">{rejected} rejected</span></div>
          <button type="button" onClick={() => void loadHistory()} disabled={loading} className="flex items-center gap-1.5 rounded border border-neutral-700 bg-neutral-900 px-3 py-1.5 text-xs text-neutral-300 transition-colors hover:bg-neutral-800 hover:text-white disabled:opacity-60"><RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />Refresh history</button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 sm:p-6">
          {error && <div role="alert" className="mb-4 flex items-start gap-2 rounded-lg border border-red-800 bg-red-950/40 p-3 text-xs text-red-300"><AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />{error}</div>}
          {loading && runs.length === 0 ? <div className="flex min-h-56 items-center justify-center gap-2 text-sm text-neutral-400"><Loader2 className="h-5 w-5 animate-spin text-[#00E5FF]" />Loading authenticated history…</div> : runs.length === 0 ? <div className="flex min-h-56 flex-col items-center justify-center rounded-xl border border-dashed border-[#313131] bg-[#121212] p-8 text-center"><FolderOpen className="mb-3 h-8 w-8 text-neutral-600" /><h3 className="text-sm font-bold text-white">No import runs recorded</h3><p className="mt-1 max-w-md text-xs leading-relaxed text-neutral-400">After sign-in, persisting a selected CP, WAT, or KLA source partition will create an owner-scoped audit record here.</p><button type="button" onClick={onOpenIngestion} className="mt-4 flex items-center gap-2 rounded-lg bg-[#00FF9C] px-4 py-2 text-xs font-bold text-black transition-colors hover:bg-[#00e58c]"><Upload className="h-4 w-4" />Open real data studio</button></div> : <div className="space-y-3">{runs.map(run => {
            const color = SOURCE_COLORS[run.source_type];
            const rows = run.dataset ?? run.counts;
            const identity = run.dataset ? { lot_id: run.dataset.lot_id, wafer_id: run.dataset.wafer_id, product_id: run.dataset.product_id } : run.selected_partition;
            return <article key={run.id} className="rounded-xl border border-[#2a2a2a] bg-[#121212] p-4 transition-colors hover:border-neutral-500">
              <div className="flex flex-wrap items-start justify-between gap-3"><div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><span className="rounded border px-2 py-0.5 font-mono text-[10px] font-bold" style={{ color, borderColor: `${color}77`, backgroundColor: `${color}12` }}>{run.source_type}</span><span className={`rounded border px-2 py-0.5 font-mono text-[10px] font-bold ${run.status === 'COMPLETED' ? 'border-[#00FF9C]/35 bg-[#00FF9C]/10 text-[#00FF9C]' : run.status === 'REJECTED' ? 'border-red-500/35 bg-red-500/10 text-red-300' : 'border-amber-400/35 bg-amber-400/10 text-amber-200'}`}>{run.status}</span><span className="font-mono text-[10px] text-neutral-500">Run #{run.id}</span></div><h3 className="mt-2 flex items-center gap-2 truncate text-sm font-bold text-white"><FileArchive className="h-4 w-4 shrink-0" style={{ color }} />{run.original_filename}</h3><p className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 font-mono text-[10px] text-neutral-500"><span><Clock3 className="mr-1 inline h-3 w-3" />{formatTimestamp(run.completed_at || run.started_at)}</span><span>{run.operation}</span>{run.source_roles.length > 0 && <span>roles: {run.source_roles.join(', ')}</span>}</p></div>{run.dataset && <button type="button" onClick={() => void reopenDataset(run)} disabled={openingDatasetId !== null} className="flex shrink-0 items-center gap-1.5 rounded border px-3 py-2 text-xs font-bold transition-colors disabled:cursor-wait disabled:opacity-60" style={{ borderColor: `${color}88`, color }}><Database className="h-3.5 w-3.5" />{openingDatasetId === run.dataset.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : 'Reopen dataset'}</button>}</div>
              <div className="mt-3 grid gap-2 border-t border-[#282828] pt-3 text-[11px] sm:grid-cols-4"><div><span className="block font-mono text-[9px] uppercase text-neutral-500">Lot / Wafer</span><strong className="block truncate font-mono text-neutral-200">{identity?.lot_id || '—'} / {identity?.wafer_id || '—'}</strong></div><div><span className="block font-mono text-[9px] uppercase text-neutral-500">Valid / errors</span><strong className="font-mono text-neutral-200">{Number(rows.valid_rows || 0).toLocaleString()} / {Number(rows.error_rows || 0).toLocaleString()}</strong></div><div><span className="block font-mono text-[9px] uppercase text-neutral-500">Source bytes</span><strong className="font-mono text-neutral-200">{run.dataset ? formatBytes(run.dataset.byte_size) : '—'}</strong></div><div><span className="block font-mono text-[9px] uppercase text-neutral-500">Product</span><strong className="block truncate font-mono text-neutral-200">{run.dataset?.product_id || 'Unavailable from source'}</strong></div></div>
              {(run.error_type || run.diagnostic_codes.length > 0 || run.has_error) && <div className="mt-3 flex flex-wrap items-center gap-2 rounded border border-amber-500/25 bg-amber-500/[0.05] p-2.5 font-mono text-[10px] text-amber-100"><AlertTriangle className="h-3.5 w-3.5 shrink-0 text-amber-300" />{run.error_type && <span>{run.error_type}</span>}{run.diagnostic_codes.map((code, index) => <span key={`${code.code || 'diagnostic'}-${index}`} className="rounded border border-amber-500/30 px-1.5 py-0.5">{[code.severity, code.role, code.code].filter(Boolean).join(' · ') || 'Diagnostic recorded'}</span>)}{run.has_error && !run.error_type && run.diagnostic_codes.length === 0 && <span>Safe rejection diagnostic recorded; review the original package locally before correction.</span>}</div>}
            </article>;
          })}</div>}
        </div>
        <footer className="flex items-center justify-between gap-3 border-t border-[#242424] bg-[#141414] px-5 py-4 sm:px-6"><span className="hidden items-center gap-2 text-[11px] text-neutral-500 sm:flex"><CheckCircle2 className="h-4 w-4 text-[#00FF9C]" />No source rows, object locations, or other-user records are displayed.</span><button type="button" onClick={onOpenIngestion} className="ml-auto flex items-center gap-2 rounded-lg bg-[#00FF9C] px-4 py-2 text-xs font-bold text-black transition-colors hover:bg-[#00e58c]"><Upload className="h-4 w-4" />Ingest real data</button></footer>
      </section>
    </div>
  );
}
