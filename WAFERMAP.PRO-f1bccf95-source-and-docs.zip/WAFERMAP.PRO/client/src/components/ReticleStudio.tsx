import React, { useState } from 'react';
import { CheckCircle2, Cpu, Grid, Minus, Plus, X } from 'lucide-react';
import { DieConfig, WaferMetadata } from '../types';
import { DIE_TYPE_COLORS } from '../utils/waferGeometry';

interface ReticleStudioProps {
  isOpen: boolean;
  onClose: () => void;
  dieConfig: DieConfig;
  setDieConfig: React.Dispatch<React.SetStateAction<DieConfig>>;
  metadata: WaferMetadata;
  highlightedCell: { row: number; col: number } | null;
  onHoverCell: (cell: { row: number; col: number } | null) => void;
}

export const ReticleStudio: React.FC<ReticleStudioProps> = ({
  isOpen,
  onClose,
  dieConfig,
  setDieConfig,
  metadata,
  highlightedCell,
  onHoverCell,
}) => {
  const [selectedCell, setSelectedCell] = useState<{ row: number; col: number } | null>(null);
  if (!isOpen) return null;

  const handleCellTypeChange = (newType: string) => {
    if (!selectedCell) return;
    const { row, col } = selectedCell;
    const next = dieConfig.die_type_matrix.map((cells) => [...cells]);
    if (next[row]?.[col] !== undefined) {
      next[row][col] = newType;
      setDieConfig((current) => ({ ...current, die_type_matrix: next }));
    }
  };

  const handleResizeReticle = (rows: number, cols: number) => {
    const validRows = Math.max(1, Math.min(6, rows));
    const validCols = Math.max(1, Math.min(8, cols));
    const matrix = Array.from({ length: validRows }, (_, row) =>
      Array.from({ length: validCols }, (_, col) => dieConfig.die_type_matrix[row]?.[col] ?? 'DIE')
    );
    setDieConfig((current) => ({ ...current, reticle_rows: validRows, reticle_cols: validCols, die_type_matrix: matrix }));
  };

  return (
    <div id="reticle-studio-modal" className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md">
      <section className="flex max-h-[90vh] w-full max-w-4xl flex-col overflow-hidden rounded-sm border border-[#222] bg-[#0C0C0C] text-[#E5E5E5] shadow-2xl">
        <header className="flex items-center justify-between border-b border-[#222] bg-[#111] px-6 py-4">
          <div className="flex items-center gap-3.5">
            <div className="rounded-sm border border-[#222] bg-[#080808] p-2 text-[#00FF9C]"><Cpu className="h-5 w-5" /></div>
            <div>
              <h2 className="flex items-center gap-2.5 text-base font-extrabold tracking-tight"><span>RETICLE.STUDIO</span><span className="rounded-xs border border-[#222] bg-[#080808] px-2 py-0.5 font-mono text-[10px] font-normal text-[#00FF9C]">GEOMETRY ONLY</span></h2>
              <p className="mt-1 font-mono text-[11px] text-[#666]">Editable field topology ({metadata.reticle_field_w_mm} × {metadata.reticle_field_h_mm} mm). No failure or physical-cause inference.</p>
            </div>
          </div>
          <button id="btn-close-reticle-studio" type="button" onClick={onClose} className="rounded p-1.5 text-[#666] hover:bg-[#1A1A1A] hover:text-white" aria-label="Close reticle studio"><X className="h-5 w-5" /></button>
        </header>

        <div className="grid flex-1 grid-cols-1 gap-6 overflow-y-auto p-6 lg:grid-cols-12">
          <div className="flex flex-col gap-4 lg:col-span-7">
            <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.2em] text-[#888]"><Grid className="h-4 w-4 text-[#00FF9C]" />Reticle exposure pattern</div>
            <div className="flex min-h-[330px] flex-col items-center justify-center rounded-sm border border-[#222] bg-[#080808] p-4 shadow-inner">
              <div className="mb-3 font-mono text-[10px] text-[#555]">Scribe lanes: X={dieConfig.scribe_x_mm * 1000}µm · Y={dieConfig.scribe_y_mm * 1000}µm</div>
              <div className="grid gap-2 rounded-sm border border-[#222] bg-[#111] p-3 shadow-xl" style={{ gridTemplateColumns: `repeat(${dieConfig.reticle_cols}, minmax(0, 1fr))` }}>
                {Array.from({ length: dieConfig.reticle_rows }, (_, row) =>
                  Array.from({ length: dieConfig.reticle_cols }, (_, col) => {
                    const dieType = dieConfig.die_type_matrix[row]?.[col] ?? 'DIE';
                    const typeInfo = DIE_TYPE_COLORS[dieType] ?? DIE_TYPE_COLORS.DIE;
                    const isSelected = selectedCell?.row === row && selectedCell.col === col;
                    const isHovered = highlightedCell?.row === row && highlightedCell.col === col;
                    return (
                      <button
                        type="button"
                        key={`${row}-${col}`}
                        onMouseEnter={() => onHoverCell({ row, col })}
                        onMouseLeave={() => onHoverCell(null)}
                        onClick={() => setSelectedCell({ row, col })}
                        className={`flex min-h-[76px] min-w-[76px] flex-col items-center justify-center rounded-sm border p-3 transition-all ${isSelected ? 'scale-105 border-[#00FF9C] bg-[#1a1a1a]' : isHovered ? 'border-[#00FF9C]/60 bg-[#161616]' : 'border-[#222] bg-[#0C0C0C] hover:border-[#444]'}`}
                      >
                        <span className="font-mono text-[10px] text-[#666]">R({row},{col})</span>
                        <span className="my-1 h-3 w-3 rounded-full" style={{ backgroundColor: typeInfo.bg }} />
                        <span className="max-w-[70px] truncate font-mono text-[10px] font-bold text-white">{typeInfo.code}</span>
                      </button>
                    );
                  })
                )}
              </div>
              <p className="mt-4 max-w-lg text-center font-mono text-[10px] leading-relaxed text-[#555]">Hover highlighting shows repeated geometric cell placement across {metadata.total_shots} computed shot fields. It is not repeater-defect evidence.</p>
            </div>
            <div className="flex items-center justify-between rounded-sm border border-[#222] bg-[#111] p-3 font-mono text-xs"><span className="text-[#666]">Field size <strong className="text-white">{metadata.reticle_field_w_mm} × {metadata.reticle_field_h_mm} mm</strong></span><span className="text-[#666]">Step pitch <strong className="text-[#00FF9C]">{metadata.shot_pitch_x_mm} × {metadata.shot_pitch_y_mm} mm</strong></span></div>
          </div>

          <div className="flex flex-col gap-4 lg:col-span-5">
            <div className="rounded-sm border border-[#222] bg-[#111] p-4">
              <h3 className="mb-3 text-[10px] font-bold uppercase tracking-[0.2em] text-[#888]">Reticle array layout</h3>
              <div className="grid grid-cols-2 gap-3">
                {([
                  ['Columns (X)', dieConfig.reticle_cols, (delta: number) => handleResizeReticle(dieConfig.reticle_rows, dieConfig.reticle_cols + delta)],
                  ['Rows (Y)', dieConfig.reticle_rows, (delta: number) => handleResizeReticle(dieConfig.reticle_rows + delta, dieConfig.reticle_cols)],
                ] as const).map(([label, value, update]) => <div key={label}><label className="mb-1 block font-mono text-[10px] uppercase text-[#666]">{label}</label><div className="flex items-center gap-1"><button type="button" onClick={() => update(-1)} className="rounded-xs border border-[#222] bg-[#080808] p-1.5 hover:bg-[#1A1A1A]"><Minus className="h-3.5 w-3.5" /></button><span className="flex-1 text-center font-mono font-bold">{value}</span><button type="button" onClick={() => update(1)} className="rounded-xs border border-[#222] bg-[#080808] p-1.5 hover:bg-[#1A1A1A]"><Plus className="h-3.5 w-3.5" /></button></div></div>)}
              </div>
            </div>

            <div className="flex-1 rounded-sm border border-[#222] bg-[#111] p-4">
              <h3 className="mb-2 text-[10px] font-bold uppercase tracking-[0.2em] text-[#888]">Cell geometry label</h3>
              {selectedCell ? <div><div className="mb-3 font-mono text-xs text-[#00FF9C]">Selected R({selectedCell.row},{selectedCell.col})</div><div className="flex flex-col gap-2">{Object.entries(DIE_TYPE_COLORS).map(([key, info]) => { const active = dieConfig.die_type_matrix[selectedCell.row]?.[selectedCell.col] === key; return <button type="button" key={key} onClick={() => handleCellTypeChange(key)} className={`flex items-center justify-between rounded-xs border px-3 py-2 text-left font-mono text-xs ${active ? 'border-[#00FF9C] bg-[#161616] text-[#00FF9C]' : 'border-[#222] bg-[#0C0C0C] text-[#888] hover:border-[#444] hover:text-white'}`}><span className="flex items-center gap-2.5"><span className="h-3 w-3 rounded-full" style={{ backgroundColor: info.bg }} />{info.name}</span>{active && <CheckCircle2 className="h-4 w-4" />}</button>; })}</div></div> : <p className="py-6 text-center font-mono text-xs italic text-[#555]">Select a cell to edit its non-measurement layout label.</p>}
            </div>
          </div>
        </div>

        <footer className="flex items-center justify-between border-t border-[#222] bg-[#111] px-6 py-3.5"><span className="font-mono text-xs text-[#666]">Template cells: {dieConfig.reticle_cols * dieConfig.reticle_rows}</span><button type="button" onClick={onClose} className="rounded-sm bg-[#E5E5E5] px-5 py-2 text-xs font-bold uppercase tracking-widest text-black hover:bg-[#00FF9C]">Apply geometry</button></footer>
      </section>
    </div>
  );
};
