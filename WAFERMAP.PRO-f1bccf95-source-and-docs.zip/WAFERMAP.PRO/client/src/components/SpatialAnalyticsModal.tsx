import React from 'react';
import { BarChart3, Database, ShieldCheck, X } from 'lucide-react';
import { IngestedDataType, IngestedWaferData } from '../types';

interface SpatialAnalyticsModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeDatasets: Partial<Record<IngestedDataType, IngestedWaferData>>;
  onOpenCpAnalysis: () => void;
}

export const SpatialAnalyticsModal: React.FC<SpatialAnalyticsModalProps> = ({
  isOpen,
  onClose,
  activeDatasets,
  onOpenCpAnalysis,
}) => {
  if (!isOpen) return null;
  const cpDataset = activeDatasets.CP;

  return (
    <div
      id="spatial-analytics-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md"
      role="dialog"
      aria-modal="true"
      aria-label="Spatial analytics availability"
    >
      <section className="w-full max-w-2xl overflow-hidden rounded-sm border border-[#222] bg-[#0C0C0C] text-[#E5E5E5] shadow-2xl">
        <header className="flex items-center justify-between border-b border-[#222] bg-[#111] px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="rounded-sm border border-[#222] bg-[#080808] p-2 text-[#00FF9C]"><BarChart3 className="h-5 w-5" /></div>
            <div>
              <h2 className="text-base font-extrabold tracking-tight">SOURCE-BACKED SPATIAL ANALYTICS</h2>
              <p className="mt-1 font-mono text-[11px] text-[#666]">No client-generated failure patterns, repeaters, or physical-cause diagnoses.</p>
            </div>
          </div>
          <button type="button" onClick={onClose} className="rounded p-1.5 text-[#666] hover:bg-[#1A1A1A] hover:text-white" aria-label="Close spatial analytics"><X className="h-5 w-5" /></button>
        </header>

        <div className="p-6">
          {cpDataset ? (
            <div className="rounded-sm border border-[#00FF9C]/30 bg-[#00FF9C]/[0.04] p-5">
              <div className="flex items-center gap-2 text-[#00FF9C]"><ShieldCheck className="h-5 w-5" /><h3 className="text-sm font-bold">Retained CP source available</h3></div>
              <dl className="mt-4 grid grid-cols-2 gap-3 font-mono text-xs">
                <div><dt className="text-[#666]">Dataset</dt><dd className="mt-1 text-white">#{cpDataset.dataset.dataset_id}</dd></div>
                <div><dt className="text-[#666]">Validated rows</dt><dd className="mt-1 text-white">{cpDataset.dataset.summary.valid_rows.toLocaleString()}</dd></div>
                <div><dt className="text-[#666]">Lot</dt><dd className="mt-1 truncate text-white">{cpDataset.dataset.summary.lot_id}</dd></div>
                <div><dt className="text-[#666]">Wafer</dt><dd className="mt-1 truncate text-white">{cpDataset.dataset.summary.wafer_id}</dd></div>
              </dl>
              <p className="mt-4 text-xs leading-relaxed text-[#999]">Open the CP &amp; YMS studio to request the retained source-backed analysis response. Spatial zones and connected failure components are displayed only after that response succeeds.</p>
              <button type="button" onClick={onOpenCpAnalysis} className="mt-5 rounded-sm bg-[#00FF9C] px-4 py-2 text-xs font-black uppercase tracking-wider text-black hover:bg-[#00e58c]">Open CP spatial analysis</button>
            </div>
          ) : (
            <div className="flex min-h-64 flex-col items-center justify-center rounded-sm border border-dashed border-[#333] bg-[#111] p-8 text-center">
              <Database className="h-9 w-9 text-[#00E5FF]" />
              <h3 className="mt-4 text-base font-bold">No real data loaded</h3>
              <p className="mt-2 max-w-lg text-xs leading-relaxed text-[#777]">The current wafer is geometry-only. Select or ingest a retained CP wafer-sort dataset before viewing yield zones, failure components, or any other spatial result.</p>
            </div>
          )}
        </div>

        <footer className="flex justify-end border-t border-[#222] bg-[#111] px-6 py-3.5">
          <button type="button" onClick={onClose} className="rounded-sm border border-[#222] bg-[#080808] px-5 py-2 text-xs font-bold uppercase tracking-widest text-[#888] hover:text-white">Close</button>
        </footer>
      </section>
    </div>
  );
};
