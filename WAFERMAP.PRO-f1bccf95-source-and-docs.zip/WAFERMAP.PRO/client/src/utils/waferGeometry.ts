/**
 * Deterministic client-side wafer geometry utilities.
 *
 * This module only computes physical placement, usability, and reticle/shot topology.
 * Manufacturing results must come from retained CP, WAT, or KLA records and are never
 * generated here.
 */

import { ColormapMode, DieConfig, DieInstance, ShotInstance, WaferConfig, WaferLayoutResponse } from '../types';

export function calculateGDPWFormula(
  diameterMm: number,
  edgeExclusionMm: number,
  dieWMm: number,
  dieHMm: number
): number {
  const rUsable = diameterMm / 2 - edgeExclusionMm;
  if (rUsable <= 0) return 0;
  const areaDie = dieWMm * dieHMm;
  if (areaDie <= 0) return 0;
  const term1 = (Math.PI * rUsable * rUsable) / areaDie;
  const term2 = (Math.PI * rUsable) / Math.sqrt(2.0 * areaDie);
  return Math.max(0, Math.floor(term1 - term2));
}

export function generateClientWaferLayout(
  waferCfg: WaferConfig,
  dieCfg: DieConfig
): WaferLayoutResponse {
  const rWafer = waferCfg.diameter_mm / 2.0;
  const rUsable = rWafer - waferCfg.edge_exclusion_mm;
  const reticleW =
    dieCfg.reticle_cols * dieCfg.width_mm +
    (dieCfg.reticle_cols - 1) * dieCfg.scribe_x_mm;
  const reticleH =
    dieCfg.reticle_rows * dieCfg.height_mm +
    (dieCfg.reticle_rows - 1) * dieCfg.scribe_y_mm;
  const pitchX = reticleW + dieCfg.scribe_x_mm;
  const pitchY = reticleH + dieCfg.scribe_y_mm;
  const dieStepX = dieCfg.width_mm + dieCfg.scribe_x_mm;
  const dieStepY = dieCfg.height_mm + dieCfg.scribe_y_mm;
  const maxShotCols = Math.ceil(rWafer / pitchX) + 2;
  const maxShotRows = Math.ceil(rWafer / pitchY) + 2;
  const dies: DieInstance[] = [];
  const shots: ShotInstance[] = [];
  let grossDieCount = 0;
  let partialDieCount = 0;

  for (let sRow = -maxShotRows; sRow <= maxShotRows; sRow++) {
    for (let sCol = -maxShotCols; sCol <= maxShotCols; sCol++) {
      const sCenterX = waferCfg.center_offset_x_mm + sCol * pitchX;
      const sCenterY = waferCfg.center_offset_y_mm + sRow * pitchY;
      const sHalfW = reticleW / 2.0;
      const sHalfH = reticleH / 2.0;
      const sMinDist =
        Math.sqrt(sCenterX * sCenterX + sCenterY * sCenterY) -
        Math.sqrt(sHalfW * sHalfW + sHalfH * sHalfH);
      if (sMinDist > rWafer) continue;

      const shotDies: DieInstance[] = [];
      for (let rRow = 0; rRow < dieCfg.reticle_rows; rRow++) {
        for (let rCol = 0; rCol < dieCfg.reticle_cols; rCol++) {
          const localX = -sHalfW + rCol * dieStepX + dieCfg.width_mm / 2.0;
          const localY = sHalfH - rRow * dieStepY - dieCfg.height_mm / 2.0;
          const dieXMm = sCenterX + localX;
          const dieYMm = sCenterY + localY;
          const globalDieX = sCol * dieCfg.reticle_cols + rCol;
          const globalDieY = sRow * dieCfg.reticle_rows + (dieCfg.reticle_rows - 1 - rRow);
          const dHalfW = dieCfg.width_mm / 2.0;
          const dHalfH = dieCfg.height_mm / 2.0;
          const corners = [
            [dieXMm - dHalfW, dieYMm - dHalfH],
            [dieXMm + dHalfW, dieYMm - dHalfH],
            [dieXMm + dHalfW, dieYMm + dHalfH],
            [dieXMm - dHalfW, dieYMm + dHalfH],
          ];
          const insideCount = corners.filter(([x, y]) => Math.hypot(x, y) <= rUsable).length;
          const centerDist = Math.hypot(dieXMm, dieYMm);
          const status = insideCount === 4 ? 'FULL' : insideCount > 0 || centerDist <= rUsable ? 'PARTIAL' : null;
          if (!status) continue;

          const isFullyInsideUsableArea = status === 'FULL';
          if (isFullyInsideUsableArea) grossDieCount++;
          else partialDieCount++;
          const angleDeg = ((Math.atan2(dieYMm, dieXMm) * 180) / Math.PI + 360) % 360;
          const dieType = dieCfg.die_type_matrix[rRow]?.[rCol] ?? 'DIE';
          const die: DieInstance = {
            die_uid: `geometry-S${sRow >= 0 ? '+' : ''}${sRow}_${sCol >= 0 ? '+' : ''}${sCol}-R${rRow}_${rCol}`,
            global_x: globalDieX,
            global_y: globalDieY,
            center_x_mm: +dieXMm.toFixed(4),
            center_y_mm: +dieYMm.toFixed(4),
            width_mm: +dieCfg.width_mm.toFixed(4),
            height_mm: +dieCfg.height_mm.toFixed(4),
            shot_row: sRow,
            shot_col: sCol,
            reticle_row: rRow,
            reticle_col: rCol,
            die_type: dieType,
            status,
            is_fully_inside_usable_area: isFullyInsideUsableArea,
            radial_dist_mm: +centerDist.toFixed(3),
            angle_deg: +angleDeg.toFixed(2),
          };
          dies.push(die);
          shotDies.push(die);
        }
      }

      if (shotDies.length > 0) {
        shots.push({
          shot_id: `S(${sRow >= 0 ? '+' : ''}${sRow},${sCol >= 0 ? '+' : ''}${sCol})`,
          shot_row: sRow,
          shot_col: sCol,
          center_x_mm: +sCenterX.toFixed(4),
          center_y_mm: +sCenterY.toFixed(4),
          width_mm: +reticleW.toFixed(4),
          height_mm: +reticleH.toFixed(4),
          status: shotDies.every((die) => die.status === 'FULL') ? 'FULL' : 'PARTIAL',
          total_dies: shotDies.length,
        });
      }
    }
  }

  return {
    metadata: {
      wafer_id: waferCfg.wafer_id,
      lot_id: waferCfg.lot_id,
      product_id: waferCfg.product_id,
      diameter_mm: waferCfg.diameter_mm,
      edge_exclusion_mm: waferCfg.edge_exclusion_mm,
      usable_radius_mm: +rUsable.toFixed(3),
      notch_angle_deg: waferCfg.notch_angle_deg,
      center_offset_x_mm: waferCfg.center_offset_x_mm,
      center_offset_y_mm: waferCfg.center_offset_y_mm,
      theoretical_gdpw: calculateGDPWFormula(
        waferCfg.diameter_mm,
        waferCfg.edge_exclusion_mm,
        dieCfg.width_mm,
        dieCfg.height_mm
      ),
      gross_die_count: grossDieCount,
      partial_die_count: partialDieCount,
      reticle_field_w_mm: +reticleW.toFixed(4),
      reticle_field_h_mm: +reticleH.toFixed(4),
      reticle_rows: dieCfg.reticle_rows,
      reticle_cols: dieCfg.reticle_cols,
      shot_pitch_x_mm: +pitchX.toFixed(4),
      shot_pitch_y_mm: +pitchY.toFixed(4),
      total_shots: shots.length,
    },
    dies,
    shots,
  };
}

export function getColormapColor(
  value: number,
  minVal: number,
  maxVal: number,
  colormap: ColormapMode = 'turbo'
): string {
  const t = Math.max(0, Math.min(1, (value - minVal) / (maxVal - minVal || 1)));
  if (colormap === 'turbo') {
    const r = Math.sin(t * Math.PI * 1.5 - 0.5) * 127 + 128;
    const g = Math.sin(t * Math.PI * 2.0 - 1.0) * 127 + 128;
    const b = Math.sin((1 - t) * Math.PI * 1.5 - 0.5) * 127 + 128;
    return `rgb(${Math.floor(r)}, ${Math.floor(g)}, ${Math.floor(b)})`;
  }
  if (colormap === 'viridis') {
    return `rgb(${Math.floor(68 + t * 185)}, ${Math.floor(1 + t * 230)}, ${Math.floor(84 + (1 - t) * 56)})`;
  }
  if (colormap === 'plasma') {
    return `rgb(${Math.floor(13 + t * 227)}, ${Math.floor(8 + t * 180)}, ${Math.floor(135 + (1 - t) * 90)})`;
  }
  if (colormap === 'coolwarm') {
    return `rgb(${Math.floor(59 + t * 121)}, ${Math.floor(76 + (1 - Math.abs(t - 0.5) * 2) * 100)}, ${Math.floor(192 - t * 132)})`;
  }
  return `rgb(${Math.floor(t * 252)}, ${Math.floor(t * t * 255)}, ${Math.floor(Math.pow(1 - t, 3) * 128)})`;
}

export const BIN_COLORS: Record<number, { bg: string; border: string }> = {
  1: { bg: '#10b981', border: '#059669' },
  2: { bg: '#ef4444', border: '#dc2626' },
  3: { bg: '#f97316', border: '#ea580c' },
  4: { bg: '#eab308', border: '#ca8a04' },
  5: { bg: '#8b5cf6', border: '#7c3aed' },
  6: { bg: '#ec4899', border: '#db2777' },
  7: { bg: '#06b6d4', border: '#0891b2' },
  99: { bg: '#334155', border: '#475569' },
};

export const DIE_TYPE_COLORS: Record<string, { bg: string; border: string; name: string; code: string }> = {
  DIE: { bg: '#6366f1', border: '#4f46e5', name: 'Display Die', code: 'DIE' },
  REFERENCE_DIE: { bg: '#06b6d4', border: '#0891b2', name: 'Reference Die', code: 'REF' },
  TEST_DIE: { bg: '#10b981', border: '#059669', name: 'Test Die', code: 'TEST' },
  EXCLUDED_DIE: { bg: '#64748b', border: '#475569', name: 'Excluded Die', code: 'EXCL' },
};
