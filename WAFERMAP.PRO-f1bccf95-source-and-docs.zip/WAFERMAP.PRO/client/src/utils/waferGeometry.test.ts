import { describe, expect, it } from 'vitest';
import { calculateGDPWFormula, generateClientWaferLayout } from './waferGeometry';

const waferConfig = {
  wafer_id: '',
  lot_id: '',
  product_id: '',
  diameter_mm: 300,
  edge_exclusion_mm: 3,
  notch_angle_deg: 270 as const,
  center_offset_x_mm: 0,
  center_offset_y_mm: 0,
};

const dieConfig = {
  width_mm: 8.5,
  height_mm: 10.2,
  scribe_x_mm: 0.08,
  scribe_y_mm: 0.08,
  reticle_cols: 3,
  reticle_rows: 2,
  die_type_matrix: [
    ['DIE', 'DIE', 'REFERENCE_DIE'],
    ['DIE', 'TEST_DIE', 'DIE'],
  ],
};

const manufacturingKeys = [
  'bin_code',
  'bin_name',
  'bin_quality',
  'parametric_val',
  'test_freq_ghz',
  'leakage_ua',
  'defect_count',
  'yield_pct',
  'pass_dies',
  'fail_dies',
];

describe('wafer geometry layout', () => {
  it('creates stable placement topology without manufacturing outcomes', () => {
    const first = generateClientWaferLayout(waferConfig, dieConfig);
    const second = generateClientWaferLayout(waferConfig, dieConfig);

    expect(first).toEqual(second);
    expect(first.metadata.diameter_mm).toBe(300);
    expect(first.metadata.gross_die_count).toBeGreaterThan(0);
    expect(first.metadata.total_shots).toBeGreaterThan(0);
    expect(first.dies.length).toBeGreaterThanOrEqual(first.metadata.gross_die_count);
    expect(first.dies.every((die) => manufacturingKeys.every((key) => !(key in die)))).toBe(true);
    expect(first.shots.every((shot) => manufacturingKeys.every((key) => !(key in shot)))).toBe(true);
    expect(manufacturingKeys.every((key) => !(key in first.metadata))).toBe(true);
  });

  it('changes only geometric placement when the center offset changes', () => {
    const baseline = generateClientWaferLayout(waferConfig, dieConfig);
    const shifted = generateClientWaferLayout(
      { ...waferConfig, center_offset_x_mm: 1.25, center_offset_y_mm: -0.75 },
      dieConfig,
    );

    expect(shifted.metadata.center_offset_x_mm).toBe(1.25);
    expect(shifted.metadata.center_offset_y_mm).toBe(-0.75);
    expect(shifted.dies[0]?.center_x_mm).not.toBe(baseline.dies[0]?.center_x_mm);
    expect(shifted.dies[0]?.center_y_mm).not.toBe(baseline.dies[0]?.center_y_mm);
  });

  it('computes the closed-form GDPW estimate from geometry only', () => {
    expect(calculateGDPWFormula(300, 3, 8.5, 10.2)).toBeGreaterThan(0);
    expect(calculateGDPWFormula(300, 151, 8.5, 10.2)).toBe(0);
    expect(calculateGDPWFormula(300, 3, 0, 10.2)).toBe(0);
  });
});
