import { IngestedDataType, PackageUploadSessionResponse } from '../types';

export interface StagedPackageFile {
  role: string;
  file: File;
}

export interface ActivePackageUploadSession {
  sessionId: string;
  uploadToken: string;
  sourceType: IngestedDataType;
  chunkBytes: number;
  expiresAt: number;
}

interface ApiFailure {
  error?: unknown;
  message?: unknown;
}

function errorMessage(body: unknown, fallback: string): string {
  if (body && typeof body === 'object') {
    const candidate = body as ApiFailure;
    if (typeof candidate.message === 'string' && candidate.message.trim()) return candidate.message;
    if (typeof candidate.error === 'string' && candidate.error.trim()) return candidate.error;
  }
  return fallback;
}

async function readJson(response: Response): Promise<unknown> {
  const text = await response.text();
  if (!text) return null;
  try {
    return JSON.parse(text) as unknown;
  } catch {
    return { message: response.status === 413 ? 'The upstream gateway rejected this request as too large.' : text.slice(0, 180) };
  }
}

async function requestJson(url: string, init: RequestInit, fallback: string): Promise<unknown> {
  let response: Response;
  try {
    response = await fetch(url, { ...init, credentials: 'same-origin' });
  } catch {
    throw new Error('The package upload connection was interrupted. The selected CSV files were not persisted.');
  }
  const body = await readJson(response);
  if (!response.ok) {
    const limitAdvice = response.status === 413
      ? ' The staged uploader uses small chunks; retry validation so the request can be sent safely.'
      : '';
    throw new Error(`${errorMessage(body, fallback)}${limitAdvice}`);
  }
  return body;
}

function tokenHeaders(session: ActivePackageUploadSession): HeadersInit {
  return { 'X-WaferMap-Upload-Token': session.uploadToken };
}

export async function createPackageUploadSession(
  sourceType: IngestedDataType,
  files: StagedPackageFile[],
): Promise<ActivePackageUploadSession> {
  const body = await requestJson('/api/ingestion/package-sessions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      source_type: sourceType,
      files: files.map(({ role, file }) => ({ role, filename: file.name, byte_size: file.size })),
    }),
  }, 'The staged upload session could not be created.');
  const session = body as Partial<PackageUploadSessionResponse>;
  if (typeof session.session_id !== 'string' || typeof session.upload_token !== 'string' || !Number.isFinite(session.chunk_bytes) || (session.chunk_bytes ?? 0) < 64 * 1024) {
    throw new Error('The package upload service returned an invalid session contract.');
  }
  return {
    sessionId: session.session_id,
    uploadToken: session.upload_token,
    sourceType,
    chunkBytes: Number(session.chunk_bytes),
    expiresAt: Number(session.expires_at ?? 0),
  };
}

export async function uploadPackageFiles(
  session: ActivePackageUploadSession,
  files: StagedPackageFile[],
  onProgress: (completedBytes: number, totalBytes: number, filename: string) => void,
  signal?: AbortSignal,
): Promise<void> {
  const totalBytes = files.reduce((sum, entry) => sum + entry.file.size, 0);
  let completedBytes = 0;
  for (const entry of files) {
    const totalChunks = Math.ceil(entry.file.size / session.chunkBytes);
    for (let chunkIndex = 0; chunkIndex < totalChunks; chunkIndex += 1) {
      if (signal?.aborted) throw new DOMException('The staged upload was cancelled.', 'AbortError');
      const start = chunkIndex * session.chunkBytes;
      const chunk = entry.file.slice(start, Math.min(start + session.chunkBytes, entry.file.size));
      const form = new FormData();
      form.append('role', entry.role);
      form.append('chunk_index', String(chunkIndex));
      form.append('total_chunks', String(totalChunks));
      form.append('chunk', chunk, entry.file.name);
      await requestJson(`/api/ingestion/package-sessions/${encodeURIComponent(session.sessionId)}/chunks`, {
        method: 'POST',
        headers: tokenHeaders(session),
        body: form,
        signal,
      }, `Chunk ${chunkIndex + 1} for ${entry.file.name} was rejected.`);
      completedBytes += chunk.size;
      onProgress(completedBytes, totalBytes, entry.file.name);
    }
  }
}

export async function validateStagedPackage(session: ActivePackageUploadSession): Promise<unknown> {
  let response: Response;
  try {
    response = await fetch(`/api/ingestion/package-sessions/${encodeURIComponent(session.sessionId)}/validate`, {
      method: 'POST',
      headers: tokenHeaders(session),
      credentials: 'same-origin',
    });
  } catch {
    throw new Error('The staged package validation connection was interrupted.');
  }
  const body = await readJson(response);
  if (response.status === 422 && body && typeof body === 'object' && typeof (body as { valid?: unknown }).valid === 'boolean') return body;
  if (!response.ok) throw new Error(errorMessage(body, 'The staged package validation service rejected the uploaded files.'));
  return body;
}

export async function persistStagedPackage(
  session: ActivePackageUploadSession,
  selectedLotId: string,
  selectedWaferId: string,
): Promise<unknown> {
  return requestJson(`/api/ingestion/package-sessions/${encodeURIComponent(session.sessionId)}/persist`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...tokenHeaders(session) },
    body: JSON.stringify({ selected_lot_id: selectedLotId, selected_wafer_id: selectedWaferId }),
  }, 'The staged package could not be persisted.');
}

export async function abandonStagedPackage(session: ActivePackageUploadSession | null): Promise<void> {
  if (!session) return;
  try {
    await fetch(`/api/ingestion/package-sessions/${encodeURIComponent(session.sessionId)}`, {
      method: 'DELETE',
      headers: tokenHeaders(session),
      credentials: 'same-origin',
    });
  } catch {
    // Expiration cleanup is server-side; nothing sensitive is retained in browser state after this call.
  }
}
