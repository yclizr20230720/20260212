import { describe, expect, it } from 'vitest';
import {
  createCsvTemplate,
  createPackageReadme,
  getPrimaryRoleIds,
  getRealDataFileRoles,
  REAL_DATA_FILE_ROLES,
} from './realDataPackageTemplates';

describe('real data package templates', () => {
  it('provides one header-only CSV contract per supported package role', () => {
    expect(REAL_DATA_FILE_ROLES).toHaveLength(11);

    for (const role of REAL_DATA_FILE_ROLES) {
      const template = createCsvTemplate(role);
      expect(template).toBe(`${role.headers.join(',')}\n`);
      expect(template.trim().split(/\r?\n/)).toHaveLength(1);
      expect(role.headers.length).toBeGreaterThan(0);
    }
  });

  it('maps each browser role to the real package-validator multipart field', () => {
    expect(REAL_DATA_FILE_ROLES.map((role) => role.multipartField)).toEqual([
      'cp_die', 'cp_summary', 'cp_bins', 'cp_limits',
      'wat_long', 'wat_wide', 'wat_summary', 'wat_specs',
      'kla_defects', 'kla_summary', 'kla_classes',
    ]);
  });

  it('models CP and KLA as one-primary packages and WAT as a long-or-wide choice', () => {
    expect(getPrimaryRoleIds('CP')).toEqual(['cp-die-primary']);
    expect(getPrimaryRoleIds('WAT')).toEqual(['wat-long-primary', 'wat-wide-primary']);
    expect(getPrimaryRoleIds('KLA')).toEqual(['kla-defect-primary']);
    expect(getRealDataFileRoles('WAT')).toHaveLength(4);
  });

  it('documents source identity and explicit selected-wafer persistence', () => {
    const readme = createPackageReadme('CP');
    expect(readme).toContain('Source identity rule');
    expect(readme).toContain('package-validation endpoint');
    expect(readme).toContain('explicitly select one LOT_ID + WAFER_ID');
    expect(readme).toContain('retains only that selected wafer');
    expect(readme).toContain('LOT_ID,WAFER_ID');
  });
});
