import { IngestedDataType } from '../types';

export type RealDataFileRoleId =
  | 'cp-die-primary'
  | 'cp-wafer-summary'
  | 'cp-bin-definitions'
  | 'cp-test-limits'
  | 'wat-long-primary'
  | 'wat-wide-primary'
  | 'wat-wafer-medians'
  | 'wat-spec-definitions'
  | 'kla-defect-primary'
  | 'kla-wafer-summary'
  | 'kla-class-definitions';

export type RealDataRoleRequirement = 'required' | 'optional' | 'choose-one-primary';

export interface RealDataFileRole {
  id: RealDataFileRoleId;
  sourceType: IngestedDataType;
  /** Multipart field name expected by POST /api/ingestion/packages/validate. */
  multipartField: 'cp_die' | 'cp_summary' | 'cp_bins' | 'cp_limits' | 'wat_long' | 'wat_wide' | 'wat_summary' | 'wat_specs' | 'kla_defects' | 'kla_summary' | 'kla_classes';
  label: string;
  role: 'Primary' | 'Summary' | 'Definition / spec';
  requirement: RealDataRoleRequirement;
  primary: boolean;
  description: string;
  filename: string;
  /** Minimum server contract for browser preflight; templates may include recommended optional lineage columns. */
  validationHeaders?: string[];
  headers: string[];
  dynamicColumnHint?: string;
}

const CP_DIE_PRIMARY_HEADERS = [
  'LOT_ID', 'WAFER_ID', 'WAFER_NO', 'SLOT_NO', 'PRODUCT_ID', 'DEVICE_ID', 'TECHNOLOGY', 'MASK_SET', 'FAB_ID', 'TEST_FLOOR', 'TESTER_ID', 'PROBER_ID', 'PROBE_CARD_ID', 'TEST_SITE', 'PROBE_TEMP_C', 'TOUCHDOWN_COUNT', 'TEST_PROGRAM', 'TEST_STAGE', 'PROBE_PASS', 'RETEST_FLAG', 'TEST_START_TIME', 'DIE_SEQ', 'DIE_X', 'DIE_Y', 'DIE_CENTER_X_MM', 'DIE_CENTER_Y_MM', 'RADIUS_MM', 'RADIUS_NORM', 'THETA_DEG', 'ZONE', 'RADIAL_RING', 'RETICLE_COL', 'RETICLE_ROW', 'RETICLE_SHOT_ID', 'DIE_IN_RETICLE_X', 'DIE_IN_RETICLE_Y', 'WAFER_SIZE_MM', 'NOTCH', 'EDGE_EXCLUSION_MM', 'SOFT_BIN', 'HARD_BIN', 'BIN_NAME', 'PASS_FAIL', 'VTH_NMOS_V', 'VTH_PMOS_V', 'IDDQ_UA', 'RON_OHM', 'FMAX_MHZ', 'VDD_MIN_V', 'CONT_RES_OHM', 'ICC_ACTIVE_MA',
];

const CP_WAFER_SUMMARY_HEADERS = [
  'LOT_ID', 'WAFER_ID', 'WAFER_NO', 'GROSS_DIE', 'PASS_DIE', 'YIELD_PCT', 'AVG_IDDQ_UA', 'MED_VTH_NMOS_V', 'MED_FMAX_MHZ', 'SB11_QTY', 'SB12_QTY', 'SB21_QTY', 'SB31_QTY', 'SB41_QTY', 'SB51_QTY', 'SB61_QTY', 'TEST_START',
];

const CP_BIN_DEFINITION_HEADERS = ['SOFT_BIN', 'BIN_NAME', 'HARD_BIN', 'PASS_FAIL', 'BIN_CATEGORY'];
const CP_TEST_LIMIT_HEADERS = ['TEST_NUM', 'TEST_NAME', 'UNIT', 'LOW_LIMIT', 'HIGH_LIMIT', 'FAIL_SOFT_BIN'];

const CP_DIE_REQUIRED_HEADERS = ['LOT_ID', 'WAFER_ID', 'PRODUCT_ID', 'DIE_X', 'DIE_Y', 'DIE_CENTER_X_MM', 'DIE_CENTER_Y_MM', 'HARD_BIN', 'SOFT_BIN', 'BIN_NAME', 'PASS_FAIL', 'VTH_NMOS_V', 'VTH_PMOS_V', 'IDDQ_UA', 'RON_OHM', 'FMAX_MHZ', 'VDD_MIN_V', 'CONT_RES_OHM', 'ICC_ACTIVE_MA'];
const CP_SUMMARY_REQUIRED_HEADERS = ['LOT_ID', 'WAFER_ID', 'GROSS_DIE', 'PASS_DIE', 'YIELD_PCT'];
const WAT_LONG_REQUIRED_HEADERS = ['LOT_ID', 'WAFER_ID', 'SITE_ID', 'SITE_NAME', 'SITE_X_MM', 'SITE_Y_MM', 'DIE_X', 'DIE_Y', 'PARAM_ID', 'PARAM_NAME', 'PARAM_GROUP', 'MODULE', 'TEST_STRUCTURE', 'CRITICALITY', 'UNIT', 'VALUE', 'TARGET', 'SPEC_LOW', 'SPEC_HIGH', 'OOS_FLAG'];
const WAT_WIDE_REQUIRED_HEADERS = ['LOT_ID', 'WAFER_ID', 'SITE_ID', 'SITE_NAME', 'SITE_X_MM', 'SITE_Y_MM', 'DIE_X', 'DIE_Y'];
const WAT_SUMMARY_REQUIRED_HEADERS = ['LOT_ID', 'WAFER_ID', 'OOS_SITE_PARAM_QTY'];
const WAT_SPEC_REQUIRED_HEADERS = ['PARAM_ID', 'PARAM_NAME', 'UNIT', 'TARGET', 'SPEC_LOW', 'SPEC_HIGH', 'MODULE', 'PARAM_GROUP', 'TEST_STRUCTURE', 'CRITICALITY'];
const KLA_DEFECT_REQUIRED_HEADERS = ['DEFECT_ID', 'LOT_ID', 'WAFER_ID', 'DIE_X', 'DIE_Y', 'XREL_UM', 'YREL_UM', 'DEFECT_SIZE_UM', 'CLASS_CODE', 'CLASS_NAME', 'CLASS_GROUP', 'KILLER_FLAG', 'INSPECTION_TOOL', 'INSPECTION_RECIPE', 'INSPECTION_STEP', 'LAYER', 'RETICLE_SHOT_ID'];
const KLA_SUMMARY_REQUIRED_HEADERS = ['LOT_ID', 'WAFER_ID', 'TOTAL_DEFECTS', 'KILLER_DEFECTS', 'TOP_CLASS', 'MEAN_SIZE_UM'];

const WAT_LONG_PRIMARY_HEADERS = [
  'LOT_ID', 'WAFER_ID', 'WAFER_NO', 'MEAS_TIME', 'WAT_TESTER', 'IMPLANT_TOOL', 'LITHO_TOOL', 'ETCH_TOOL', 'CMP_TOOL', 'DIFFUSION_TOOL', 'SITE_ID', 'SITE_NAME', 'SITE_X_MM', 'SITE_Y_MM', 'RADIUS_MM', 'RADIUS_NORM', 'THETA_DEG', 'ZONE', 'RADIAL_RING', 'DIE_X', 'DIE_Y', 'RETICLE_COL', 'RETICLE_ROW', 'RETICLE_SHOT_ID', 'SCRIBE_ORIENT', 'TEG_ID', 'TEST_STRUCTURE', 'PARAM_ID', 'PARAM_NAME', 'PARAM_GROUP', 'MODULE', 'CRITICALITY', 'UNIT', 'VALUE', 'TARGET', 'SPEC_LOW', 'SPEC_HIGH', 'SPEC_MARGIN_PCT', 'OOS_FLAG',
];

const WAT_WIDE_PRIMARY_METADATA_HEADERS = [
  'LOT_ID', 'WAFER_ID', 'WAFER_NO', 'SITE_ID', 'SITE_NAME', 'SITE_X_MM', 'SITE_Y_MM', 'RADIUS_MM', 'ZONE', 'DIE_X', 'DIE_Y', 'IMPLANT_TOOL', 'DIFFUSION_TOOL', 'CMP_TOOL', 'WAT_TESTER',
];

const WAT_WAFER_MEDIAN_HEADERS = ['LOT_ID', 'WAFER_ID', 'WAFER_NO', 'OOS_SITE_PARAM_QTY'];
const WAT_SPEC_DEFINITION_HEADERS = ['PARAM_ID', 'PARAM_NAME', 'UNIT', 'TARGET', 'SPEC_LOW', 'SPEC_HIGH', 'MODULE', 'PARAM_GROUP', 'TEST_STRUCTURE', 'USL_MINUS_LSL', 'CRITICALITY'];

const KLA_DEFECT_PRIMARY_HEADERS = [
  'DEFECT_ID', 'LOT_ID', 'WAFER_ID', 'WAFER_NO', 'INSPECTION_TOOL', 'INSPECTION_RECIPE', 'INSPECTION_STEP', 'LAYER', 'SAMPLING_PLAN', 'INSPECTION_TIME', 'WAFER_SIZE_MM', 'DIE_X', 'DIE_Y', 'DIE_CENTER_X_MM', 'DIE_CENTER_Y_MM', 'RADIUS_MM', 'RADIUS_NORM', 'THETA_DEG', 'ZONE', 'RADIAL_RING', 'RETICLE_COL', 'RETICLE_ROW', 'RETICLE_SHOT_ID', 'IN_RET_X', 'IN_RET_Y', 'XREL_UM', 'YREL_UM', 'XINDIE_UM', 'YINDIE_UM', 'DEFECT_SIZE_UM', 'DEFECT_AREA_UM2', 'POLARITY', 'CLASS_CODE', 'CLASS_NAME', 'CLASS_GROUP', 'DEFECT_SOURCE', 'ADC_CONFIDENCE_PCT', 'REVIEW_STATUS', 'KILLER_FLAG', 'SEM_IMAGE_ID',
];

const KLA_WAFER_SUMMARY_HEADERS = [
  'LOT_ID', 'WAFER_ID', 'WAFER_NO', 'INSPECTION_TOOL', 'LAYER', 'TOTAL_DEFECTS', 'KILLER_DEFECTS', 'TOP_CLASS', 'MEAN_SIZE_UM', 'DEFECT_DENSITY_PER_CM2', 'KILLER_DENSITY_PER_CM2', 'SCRATCH_QTY', 'PATTERN_BRIDGE_QTY', 'CMP_DISHING_QTY', 'CMP_RESIDUE_QTY',
];

const KLA_CLASS_DEFINITION_HEADERS = ['CLASS_CODE', 'CLASS_NAME', 'CLASS_GROUP', 'POLARITY', 'KILLER_DEFAULT'];

export const REAL_DATA_FILE_ROLES: RealDataFileRole[] = [
  {
    id: 'cp-die-primary', sourceType: 'CP', multipartField: 'cp_die', label: 'Die-level primary', role: 'Primary', requirement: 'required', primary: true,
    description: 'Per-die wafer-sort result, coordinates, bins, tester context, and measured CP telemetry.',
    validationHeaders: CP_DIE_REQUIRED_HEADERS,
    filename: 'wafermap-pro_cp_die_primary_template.csv', headers: CP_DIE_PRIMARY_HEADERS,
  },
  {
    id: 'cp-wafer-summary', sourceType: 'CP', multipartField: 'cp_summary', label: 'Wafer summary', role: 'Summary', requirement: 'optional', primary: false,
    description: 'Wafer-level die, yield, bin-quantity, and median test roll-up for reconciliation.',
    validationHeaders: CP_SUMMARY_REQUIRED_HEADERS,
    filename: 'wafermap-pro_cp_wafer_summary_template.csv', headers: CP_WAFER_SUMMARY_HEADERS,
  },
  {
    id: 'cp-bin-definitions', sourceType: 'CP', multipartField: 'cp_bins', label: 'Bin definition', role: 'Definition / spec', requirement: 'optional', primary: false,
    description: 'Soft/hard bin semantics, pass/fail designation, and bin category mapping.',
    validationHeaders: CP_BIN_DEFINITION_HEADERS,
    filename: 'wafermap-pro_cp_bin_definitions_template.csv', headers: CP_BIN_DEFINITION_HEADERS,
  },
  {
    id: 'cp-test-limits', sourceType: 'CP', multipartField: 'cp_limits', label: 'Test limits', role: 'Definition / spec', requirement: 'optional', primary: false,
    description: 'Test names, units, limits, and the failure soft-bin relationship.',
    validationHeaders: CP_TEST_LIMIT_HEADERS,
    filename: 'wafermap-pro_cp_test_limits_template.csv', headers: CP_TEST_LIMIT_HEADERS,
  },
  {
    id: 'wat-long-primary', sourceType: 'WAT', multipartField: 'wat_long', label: 'Site-level long primary', role: 'Primary', requirement: 'choose-one-primary', primary: true,
    description: 'One site/parameter measurement per row with tool lineage, coordinates, limits, and OOS status.',
    validationHeaders: WAT_LONG_REQUIRED_HEADERS,
    filename: 'wafermap-pro_wat_site_long_primary_template.csv', headers: WAT_LONG_PRIMARY_HEADERS,
  },
  {
    id: 'wat-wide-primary', sourceType: 'WAT', multipartField: 'wat_wide', label: 'Site-level wide primary', role: 'Primary', requirement: 'choose-one-primary', primary: true,
    description: 'One measurement site per row. Append one named parameter column for each parameter defined in the spec file.',
    validationHeaders: WAT_WIDE_REQUIRED_HEADERS,
    filename: 'wafermap-pro_wat_site_wide_primary_template.csv', headers: [...WAT_WIDE_PRIMARY_METADATA_HEADERS, 'PARAMETER_NAME_FROM_SPEC'],
    dynamicColumnHint: 'Replace PARAMETER_NAME_FROM_SPEC with named parameter columns from the parameter spec definition before filling data.',
  },
  {
    id: 'wat-wafer-medians', sourceType: 'WAT', multipartField: 'wat_summary', label: 'Wafer median summary', role: 'Summary', requirement: 'optional', primary: false,
    description: 'Wafer-level OOS count followed by median columns for the named parameters.',
    validationHeaders: WAT_SUMMARY_REQUIRED_HEADERS,
    filename: 'wafermap-pro_wat_wafer_medians_template.csv', headers: [...WAT_WAFER_MEDIAN_HEADERS, 'PARAMETER_MEDIAN_FROM_SPEC'],
    dynamicColumnHint: 'Replace PARAMETER_MEDIAN_FROM_SPEC with parameter-median columns whose names match the accompanying spec definition.',
  },
  {
    id: 'wat-spec-definitions', sourceType: 'WAT', multipartField: 'wat_specs', label: 'Parameter spec definition', role: 'Definition / spec', requirement: 'optional', primary: false,
    description: 'Parameter names, target and limits, module grouping, structure, spread, and criticality.',
    validationHeaders: WAT_SPEC_REQUIRED_HEADERS,
    filename: 'wafermap-pro_wat_parameter_spec_definition_template.csv', headers: WAT_SPEC_DEFINITION_HEADERS,
  },
  {
    id: 'kla-defect-primary', sourceType: 'KLA', multipartField: 'kla_defects', label: 'Defect-detail primary', role: 'Primary', requirement: 'required', primary: true,
    description: 'Defect coordinates, size, classification, inspection context, review status, and image identifier.',
    validationHeaders: KLA_DEFECT_REQUIRED_HEADERS,
    filename: 'wafermap-pro_kla_defect_detail_primary_template.csv', headers: KLA_DEFECT_PRIMARY_HEADERS,
  },
  {
    id: 'kla-wafer-summary', sourceType: 'KLA', multipartField: 'kla_summary', label: 'Wafer defect summary', role: 'Summary', requirement: 'optional', primary: false,
    description: 'Wafer/layer defect totals, densities, top class, and characteristic defect quantities.',
    validationHeaders: KLA_SUMMARY_REQUIRED_HEADERS,
    filename: 'wafermap-pro_kla_wafer_defect_summary_template.csv', headers: KLA_WAFER_SUMMARY_HEADERS,
  },
  {
    id: 'kla-class-definitions', sourceType: 'KLA', multipartField: 'kla_classes', label: 'Defect class definition', role: 'Definition / spec', requirement: 'optional', primary: false,
    description: 'Class names, groups, polarity, and default killer classification.',
    validationHeaders: KLA_CLASS_DEFINITION_HEADERS,
    filename: 'wafermap-pro_kla_defect_class_definition_template.csv', headers: KLA_CLASS_DEFINITION_HEADERS,
  },
];

export function getRealDataFileRoles(sourceType: IngestedDataType): RealDataFileRole[] {
  return REAL_DATA_FILE_ROLES.filter((role) => role.sourceType === sourceType);
}

export function getPrimaryRoleIds(sourceType: IngestedDataType): RealDataFileRoleId[] {
  return getRealDataFileRoles(sourceType).filter((role) => role.primary).map((role) => role.id);
}

export function createCsvTemplate(role: RealDataFileRole): string {
  return `${role.headers.join(',')}\n`;
}

export function createPackageReadme(sourceType: IngestedDataType): string {
  const roles = getRealDataFileRoles(sourceType);
  const primaryRequirement = sourceType === 'WAT'
    ? 'Attach exactly one site-level primary: long or wide.'
    : 'Attach the required primary file.';
  const roleGuide = roles.map((role) => {
    const requirement = role.requirement === 'choose-one-primary' ? 'REQUIRED — choose one primary' : role.requirement.toUpperCase();
    const dynamic = role.dynamicColumnHint ? `\n  Dynamic columns: ${role.dynamicColumnHint}` : '';
    return `- ${role.label} (${requirement})\n  ${role.description}\n  Headers: ${role.headers.join(',')}${dynamic}`;
  }).join('\n\n');

  return [
    `WAFERMAP.PRO ${sourceType} Real Data Package`,
    '',
    'This package guide describes empty, fill-in CSV templates. Do not add simulated wafer records to a template.',
    primaryRequirement,
    'Source identity rule: LOT_ID, WAFER_ID, and PRODUCT_ID (when provided by the source) remain the provenance record. Visualization presets never replace source identity.',
    '',
    'Current submission boundary:',
    'The Real Data Package workflow sends selected CSV roles to the package-validation endpoint after local role coverage and bounded header checks. After valid canonical partitions are returned, the operator must explicitly select one LOT_ID + WAFER_ID. Persistence revalidates the complete role package and retains only that selected wafer; no partition is selected automatically and companion roles are not flattened.',
    '',
    'Role contracts:',
    roleGuide,
    '',
  ].join('\n');
}
