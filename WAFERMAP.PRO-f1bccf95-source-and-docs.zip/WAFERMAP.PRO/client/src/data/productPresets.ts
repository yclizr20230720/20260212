import { DieConfig, NotchOrientation, WaferConfig } from '../types';

export interface IngestionProductPreset {
  id: string;
  label: string;
  dieWidthMm: number;
  dieHeightMm: number;
  scribeMm: number;
  reticleCols: number;
  reticleRows: number;
}

export const INGESTION_PRODUCT_PRESETS: IngestionProductPreset[] = [
  { id: 'DISPLAY_STANDARD', label: 'Standard grid', dieWidthMm: 8.5, dieHeightMm: 10.2, scribeMm: 0.08, reticleCols: 3, reticleRows: 2 },
  { id: 'DISPLAY_RECTANGULAR', label: 'Rectangular grid', dieWidthMm: 12, dieHeightMm: 14.5, scribeMm: 0.1, reticleCols: 2, reticleRows: 2 },
  { id: 'DISPLAY_LARGE_DIE', label: 'Large-die grid', dieWidthMm: 24, dieHeightMm: 20, scribeMm: 0.12, reticleCols: 1, reticleRows: 1 },
  { id: 'DISPLAY_DENSE', label: 'Dense grid', dieWidthMm: 2.6, dieHeightMm: 7.8, scribeMm: 0.04, reticleCols: 4, reticleRows: 3 },
  { id: 'DISPLAY_SQUARE', label: 'Square grid', dieWidthMm: 5.8, dieHeightMm: 5.2, scribeMm: 0.08, reticleCols: 4, reticleRows: 4 },
  { id: 'DISPLAY_MICRO', label: 'Micro-array grid', dieWidthMm: 0.8, dieHeightMm: 0.8, scribeMm: 0.01, reticleCols: 10, reticleRows: 10 },
];

export function getDefaultDisplayGeometry(): IngestionProductPreset {
  return INGESTION_PRODUCT_PRESETS[0];
}

export function configurationsFromPreset(preset: IngestionProductPreset, lotId: string, waferId: string): { waferConfig: WaferConfig; dieConfig: DieConfig } {
  const matrix = Array.from(
    { length: preset.reticleRows },
    () => Array.from({ length: preset.reticleCols }, () => 'DIE'),
  );
  return {
    waferConfig: { wafer_id: waferId, lot_id: lotId, product_id: preset.id, diameter_mm: 300, edge_exclusion_mm: 3, notch_angle_deg: 270 as NotchOrientation, center_offset_x_mm: 0, center_offset_y_mm: 0 },
    dieConfig: { width_mm: preset.dieWidthMm, height_mm: preset.dieHeightMm, scribe_x_mm: preset.scribeMm, scribe_y_mm: preset.scribeMm, reticle_cols: preset.reticleCols, reticle_rows: preset.reticleRows, die_type_matrix: matrix },
  };
}
