# WAFERMAP.PRO Real-Data Architecture and GUI Design

## Purpose

WAFERMAP.PRO is a **300 mm wafer intelligence workspace** for retained CP wafer-sort, WAT metrology, and KLA defect-inspection data. It preserves the dark industrial control-room visual language of the supplied reference while replacing static wafer figures, fictional tools, and unsupported root-cause statements with source-derived measurements, lineage, and bounded decision support.

> **Evidence rule:** A KPI, chart, wafer overlay, correlation row, or report value is available only when it can be calculated from a selected, persisted source dataset. Geometry-only mode shows wafer/reticle/die layout without manufacturing outcomes.

## Production topology

```mermaid
flowchart LR
    U[Authenticated operator] --> R[React + Vite control room]
    R --> N[Node public host]
    N -->|OAuth callback / signed session cookie| O[Manus OAuth]
    N -->|same-origin /api proxy| F[Flask source-data API]
    F --> Q[Request-driven durable analysis queue]
    F --> DB[(MySQL / TiDB)]
    F --> S[Managed object storage]
    DB --> D[Normalized CP, WAT, KLA records]
    Q --> A[Source-backed aggregates]
    A --> J[Timestamped JSON report]
    J --> S
    J --> R
```

| Layer | Responsibility | Integrity boundary |
|---|---|---|
| **React + Vite** | Industrial wafer Canvas, template download/upload, partition selection, data library, CP/YMS studio, job/report history | Never fabricates a manufacturing result; Canvas geometry is separate from source measurements. |
| **Node public host** | Static assets, Manus OAuth callback, secure `app_session_id` session cookie, same-origin API proxy | OAuth CSRF nonce binds the callback to the initiating browser. Flask remains private on loopback. |
| **Flask + Waitress** | CSV package validation, selected-wafer persistence, source aggregates, ownership checks, queue endpoints, report download | Receives a verified session JWT only; no client-supplied owner ID or identity header is trusted. |
| **MySQL / TiDB** | Dataset metadata, normalized CP/WAT/KLA measurements, import audit, queue state, report manifest/payload | Queries are owner-scoped; previous owner-less records are deliberately not adopted. |
| **Managed object storage** | Original package-role sources and generated JSON reports | Source file hashes, role mapping, selected partition, and report SHA-256 stay in the audit record. |

## Real-data intake contract

The **Real Data Package Studio** provides empty CSV templates instead of bundled records. The uploaded source roles correspond to the supplied production exports:

| Domain | Required primary role | Optional reconciliation / definitions | Normalized measurement basis |
|---|---|---|---|
| **CP** | Die-level wafer-sort result | Wafer summary, bin definition, test limits | `DIE_X`, `DIE_Y`, die-center coordinates, bins, pass/fail, and measured CP parameters |
| **WAT** | One site-level primary in long **or** wide form | Wafer medians, parameter specifications | `DIE_X`, `DIE_Y`, site/parameter values, limits, OOS status, module/structure context |
| **KLA** | Defect detail | Wafer defect summary, defect class definition | `DIE_X`, `DIE_Y`, class, size, inspection context, repeater/killer flags |

The workflow validates UTF-8 CSV role coverage, headers, identities, coordinate/row limits, schema diagnostics, and canonical partitions. It then requires the operator to explicitly select **one `LOT_ID` + `WAFER_ID`** before persistence. A multiple-wafer source file is not flattened into a global data set.

### Data identity and correlation

Cross-domain analysis accepts CP, WAT, and KLA datasets only when their retained **`LOT_ID` and `WAFER_ID` match**. A product identifier, if present, is preserved as provenance; missing `PRODUCT_ID` is a displayed caveat rather than an invented value or a block to same-wafer screening.

The first correlation stage is deliberately an **association screen**, not root-cause inference:

- **KLA → CP:** groups KLA defect events by class, separates event count from distinct affected die count, and calculates unique CP-failing `DIE_X/DIE_Y` overlaps.
- **WAT → CP:** groups WAT measurements by parameter, de-duplicates repeated WAT rows per die for CP pass/fail rates, reports source/matched/unmatched coordinate coverage, OOS count, mean, and CP failure rate at matching coordinates.
- **Caveats:** equality of LotID/WaferID permits source selection. It does not prove a physical coordinate-frame transform, lithography/tool causation, layer equivalence, or an ML root-cause assertion.

## Stage 1 statistical and spatial insight

The current release concentrates on reproducible first-principles analysis before any ML/DL feature:

| Area | Calculated from selected source rows | Not claimed without source evidence |
|---|---|---|
| **CP yield & Pareto** | Tested/pass/fail die counts, yield, bin volume, cumulative failure contribution | Theoretical GDPW, expected yield, repair recovery, or a fabricated detractor |
| **CP process window** | Parameter count, mean, standard deviation, min/max; imported limits where available | Inferred limits, Cp/Cpk when limits or variation are absent |
| **Spatial screen** | Radial zones, 8-neighbour failure components, die coordinates, Canvas bin/parameter overlays | Physical mechanism, reticle-repeat conclusion, or automatic process action |
| **WAT capability** | Mean, standard deviation, limits, Cp/Cpk only where imported values and valid limits exist | Capability for an unmeasured or unspecified parameter |
| **KLA inspection** | Defect class, event count, distinct die coverage, size, repeater/killer source flags | Tool/layer interpretation that was not in the source file |
| **Cross-domain screen** | Same-lot/wafer selected datasets and direct die-coordinate overlap | Causal correlation, production disposition, or a tool trace |

### Validation evidence from the supplied real CSV package

A retained integration test selected the same partition from the supplied files: **Lot `TW2600.1`, Wafer `TW2600.1-01`**. The values below document the test run, not a hard-coded product dashboard:

| Retained dataset | Normalized selected-row count | Source-derived observation |
|---|---:|---|
| CP dataset `390001` | 935 die results | 896 pass, 39 fail, observed yield 95.8289% |
| WAT dataset `390002` | 578 measurements | 34 parameter coordinate-screening groups |
| KLA dataset `390003` | 106 defect events | 8 class coordinate-screening groups |

The direct aggregate returned `correlation_ready: true` because same-lot/wafer data had direct `DIE_X/DIE_Y` overlap. For example, the system reports measurement and defect coverage distinctly from CP-failure overlap; it does not turn those rows into an AI root-cause conclusion.

## Resource-safe analysis jobs and historical JSON reports

Each user submits a bounded source-data job rather than running uncoordinated browser calculations. The queue is durable in MySQL and uses a global atomic claim:

1. The authenticated user selects owner-scoped CP and optional WAT/KLA dataset IDs.
2. The server validates owner, type, same LotID/WaferID, and measurement floors before enqueueing.
3. Global and per-user active-job caps protect the 1 vCPU / 512 MB runtime.
4. One request claims and completes **at most one** FIFO job. No detached in-container worker is required.
5. The aggregate payload is size-bounded, hashed, persisted, and written to managed storage.
6. The report history and download endpoint remain scoped to the requesting user.

Generated filenames follow the requested auditable convention:

```text
<sanitized-user-name>_<UTC timestamp>_WAFERMAP_PRO_analysis_<job-id>.json
```

For example, a successful real-data test produced a 32,975-byte JSON report named `yclizr_Lee_20260926T113548Z_WAFERMAP_PRO_analysis_1.json`. The generated payload carries source dataset IDs, hashes, selected identity, queue metadata, governance caveats, and aggregate results—never raw retained source rows.

## GUI design decision

The reference image establishes a strong industrial visual direction: monochrome foundation, mint/cyan instrument accents, dense top command rail, left-side configuration rail, a high-performance wafer workspace, and a deep analysis drawer. WAFERMAP.PRO keeps that hierarchy with these changes:

1. **Command rail:** `Real data`, `Sign in`, `Data criteria`, `Data library`, `CP analysis`, history, reticle, geometry, export, and view controls expose actual system state.
2. **No-data state:** Empty dashboards say **Geometry-only** or **retained source required** rather than showing a sample yield or fabricated die count.
3. **Data package workflow:** Tabbed CP/WAT/KLA cards provide role-specific empty templates, schema guidance, drop zones, validation diagnostics, selected-wafer confirmation, and explicit persistence.
4. **Wafer workspace:** Canvas supports pan, zoom, fit, finite transforms, device-pixel-ratio capping, bin filters, and sparse WAT/KLA overlays. It renders deterministic geometry independently from source outcomes.
5. **CP & YMS studio:** Source-tagged KPIs, Pareto, process statistics, spatial screen, WAT/KLA coordinate-screening tables, OCAP evidence, lineage, queue action, and JSON history replace simulated “AI root cause” panels.
6. **Trust treatment:** Every panel uses real data, an explicit empty state, or a declared caveat. A bright action color indicates an action the system can actually perform, not a predicted manufacturing improvement.

## Performance design

- **Upload:** 128 MB per source-file cap and 250,000-row cap; streamed hashing and bounded validation guard server memory.
- **Selected partitions:** large multi-wafer exports are persisted as one selected wafer’s normalized measurement rows, preserving package lineage while avoiding multi-wafer Canvas payloads.
- **Transport:** high-density CP overlays use a compact columnar response; analysis endpoints return aggregate tables rather than raw source rows.
- **Canvas:** direct 2D Canvas with finite viewport math, `ResizeObserver`, pointer capture, local-coordinate drag, device-pixel-ratio cap, and lazy specialist panels.
- **Concurrency:** durable global FIFO claim plus per-user/global active limits prevents overlapping expensive aggregates and produces deterministic history.
- **Next scale threshold:** when simultaneous visible dies or overlays exceed current Canvas comfortably, introduce server tiles or binary transport and WebGL2 instancing while keeping the existing Canvas fallback.

## ML / DL / AI roadmap

ML begins only after the Stage 1 data foundation is stable and independently validated.

| Gate | Required evidence before enabling a model | Candidate capability |
|---|---|---|
| **Coordinate gate** | Reviewed CP/WAT/KLA coordinate transform, orientation, and reticle/shot mapping | Spatial feature alignment |
| **Label gate** | Time-bounded, reviewable failure/disposition labels with class definitions | Supervised bin/defect risk ranking |
| **Lineage gate** | Versioned source roles, test-program revisions, equipment context, and data-drift monitoring | Batch-compatible feature store |
| **Validation gate** | Train/validation split by lot/wafer/time, baseline statistics, calibration, and false-positive review | Decision-support score with confidence and abstention |
| **Deployment gate** | Human approval workflow, model/version registry, rollback, explainability, and performance budget | Optional risk triage—not automatic process action |

Until those gates are met, WAFERMAP.PRO presents reproducible statistics and coordinate-overlap screening only. It does not present an LLM-generated root cause, a predictive yield-recovery number, or an automated engineering disposition.
