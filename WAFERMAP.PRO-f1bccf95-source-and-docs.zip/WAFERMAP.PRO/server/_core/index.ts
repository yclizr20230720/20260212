import "dotenv/config";
import express from "express";
import { createServer, request as httpRequest } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Vite middleware does not apply vite.config.ts proxy rules. In the custom
  // production image the Node host also owns Manus OAuth/static assets while a
  // local Flask process owns source ingestion and analysis. Keep only Flask
  // API namespaces on the internal proxy; OAuth/tRPC/storage stay on Node.
  const flaskPort = process.env.WAFERMAP_FLASK_PORT;
  if (process.env.NODE_ENV === "development" || flaskPort) {
    app.use(["/api/health", "/api/wafer", "/api/sessions", "/api/ingestion", "/api/analysis"], (req, res) => {
      const target = httpRequest(
        {
          hostname: "127.0.0.1",
          port: Number(flaskPort || "5501"),
          path: req.originalUrl,
          method: req.method,
          headers: { ...req.headers, host: "127.0.0.1" },
        },
        upstream => {
          res.writeHead(upstream.statusCode || 502, upstream.headers);
          upstream.pipe(res);
        }
      );
      target.on("error", () => {
        if (!res.headersSent) {
          res.status(503).json({ error: "calculation_service_unavailable", message: "Local Flask service is unavailable." });
        }
      });
      req.pipe(target);
    });
  }
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  registerStorageProxy(app);
  registerOAuthRoutes(app);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
